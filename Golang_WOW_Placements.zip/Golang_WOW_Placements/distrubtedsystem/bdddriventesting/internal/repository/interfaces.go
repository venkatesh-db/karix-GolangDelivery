package repository

import "github.com/venkatesh/bdddriventesting/internal/models"

type UserRepository interface {
	Save(user models.User) error
	FindByID(id int) (models.User, error)
}