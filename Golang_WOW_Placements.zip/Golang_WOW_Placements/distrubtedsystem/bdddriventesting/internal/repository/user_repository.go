package repository

import (
	"errors"
	"github.com/venkatesh/bdddriventesting/internal/models"
)

type UserRepositoryImpl struct {
	data map[int]models.User
}

func NewUserRepository() *UserRepositoryImpl {
	return &UserRepositoryImpl{data: make(map[int]models.User)}
}

func (r *UserRepositoryImpl) Save(user models.User) error {
	if _, exists := r.data[user.ID]; exists {
		return errors.New("user already exists")
	}
	r.data[user.ID] = user
	return nil
}

func (r *UserRepositoryImpl) FindByID(id int) (models.User, error) {
	user, exists := r.data[id]
	if !exists {
		return models.User{}, errors.New("user not found")
	}
	return user, nil
}