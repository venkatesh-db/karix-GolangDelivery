package service

import (
	"errors"

	"github.com/venkatesh/bdddriventesting/internal/models"
	"github.com/venkatesh/bdddriventesting/internal/repository"
)

type UserServiceImpl struct {
	repo repository.UserRepository
}

func NewUserService(repo repository.UserRepository) *UserServiceImpl {
	return &UserServiceImpl{repo: repo}
}

func (s *UserServiceImpl) CreateUser(name string) (models.User, error) {
	if name == "" {
		return models.User{}, errors.New("name cannot be empty")
	}
	user := models.User{ID: len(name), Name: name} // Simplified ID generation
	err := s.repo.Save(user)
	if err != nil {
		return models.User{}, err
	}
	return user, nil
}

func (s *UserServiceImpl) GetUser(id int) (models.User, error) {
	return s.repo.FindByID(id)
}
