package service

import "github.com/venkatesh/bdddriventesting/internal/models"

type UserService interface {
	CreateUser(name string) (models.User, error)
	GetUser(id int) (models.User, error)
}

