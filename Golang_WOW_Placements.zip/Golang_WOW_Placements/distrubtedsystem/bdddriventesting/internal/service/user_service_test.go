package service_test

import (
	"errors"
	"testing"

	"github.com/golang/mock/gomock"
	"github.com/onsi/ginkgo/v2"
	"github.com/onsi/gomega"
	"github.com/venkatesh/bdddriventesting/internal/models"
	"github.com/venkatesh/bdddriventesting/internal/repository/mocks"
	"github.com/venkatesh/bdddriventesting/internal/service"
)

func TestUserService(t *testing.T) {
	gomega.RegisterFailHandler(ginkgo.Fail)
	ginkgo.RunSpecs(t, "UserService Suite")
}

var _ = ginkgo.Describe("UserService", func() {
	var (
		mockCtrl    *gomock.Controller
		mockRepo    *mocks.MockUserRepository
		userService service.UserService
	)

	ginkgo.BeforeEach(func() {
		mockCtrl = gomock.NewController(ginkgo.GinkgoT())
		mockRepo = mocks.NewMockUserRepository(mockCtrl)
		userService = service.NewUserService(mockRepo)
	})

	ginkgo.AfterEach(func() {
		mockCtrl.Finish()
	})

	ginkgo.Context("CreateUser", func() {
		ginkgo.It("should create a user successfully", func() {
			mockRepo.EXPECT().Save(gomock.Any()).Return(nil)

			user, err := userService.CreateUser("John")
			gomega.Expect(err).To(gomega.BeNil())
			gomega.Expect(user.Name).To(gomega.Equal("John"))
		})

		ginkgo.It("should return an error if name is empty", func() {
			user, err := userService.CreateUser("")
			gomega.Expect(err).ToNot(gomega.BeNil())
			gomega.Expect(user).To(gomega.Equal(models.User{}))
		})
	})

	ginkgo.Context("GetUser", func() {
		ginkgo.It("should return a user successfully", func() {
			mockRepo.EXPECT().FindByID(1).Return(models.User{ID: 1, Name: "John"}, nil)

			user, err := userService.GetUser(1)
			gomega.Expect(err).To(gomega.BeNil())
			gomega.Expect(user.Name).To(gomega.Equal("John"))
		})

		ginkgo.It("should return an error if user not found", func() {
			mockRepo.EXPECT().FindByID(1).Return(models.User{}, errors.New("user not found"))

			user, err := userService.GetUser(1)
			gomega.Expect(err).ToNot(gomega.BeNil())
			gomega.Expect(user).To(gomega.Equal(models.User{}))
		})
	})
})