package main

import (
	"context"
	"flag"
	"log"

	"cloudnative-aws/pkg/awsconfig"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/glue"
)

func main() {
	var job string
	flag.StringVar(&job, "job", "", "Glue job name")
	flag.Parse()
	if job == "" { log.Fatal("--job is required") }

	ctx := context.Background()
	cfg, err := awsconfig.LoadDefault(ctx)
	if err != nil { log.Fatal(err) }
	gc := glue.NewFromConfig(cfg)

	_, err = gc.StartJobRun(ctx, &glue.StartJobRunInput{JobName: aws.String(job)})
	if err != nil { log.Fatal(err) }
}
package main

import (
    "context"
    "flag"
    "log"

    "cloudnative-aws/pkg/awsconfig"
    "github.com/aws/aws-sdk-go-v2/aws"
    "github.com/aws/aws-sdk-go-v2/service/glue"
)

func main() {
    var job string
    flag.StringVar(&job, "job", "", "Glue job name")
    flag.Parse()
    if job == "" { log.Fatal("--job is required") }

    ctx := context.Background()
    cfg, err := awsconfig.LoadDefault(ctx)
    if err != nil { log.Fatal(err) }
    gc := glue.NewFromConfig(cfg)

    _, err = gc.StartJobRun(ctx, &glue.StartJobRunInput{JobName: aws.String(job)})
    if err != nil { log.Fatal(err) }
}package main

import (
	"context"
	"flag"
	"log"

	"cloudnative-aws/pkg/awsconfig"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/glue"
)

func main() {
	var job string
	flag.StringVar(&job, "job", "", "Glue job name")
	flag.Parse()
	if job == "" { log.Fatal("--job is required") }

	ctx := context.Background()
	cfg, err := awsconfig.LoadDefault(ctx)
	if err != nil { log.Fatal(err) }
	gc := glue.NewFromConfig(cfg)

	_, err = gc.StartJobRun(ctx, &glue.StartJobRunInput{JobName: aws.String(job)})
	if err != nil { log.Fatal(err) }
}
package cmd
package main

import (
	"context"
	"flag"
	"log"

	"cloudnative-aws/pkg/awsconfig"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/glue"
)

func main() {
	var job string
	flag.StringVar(&job, "job", "", "Glue job name")











}	if err != nil { log.Fatal(err) }	_, err = gc.StartJobRun(ctx, &glue.StartJobRunInput{JobName: aws.String(job)})	gc := glue.NewFromConfig(cfg)	if err != nil { log.Fatal(err) }	cfg, err := awsconfig.LoadDefault(ctx)	ctx := context.Background()	if job == "" { log.Fatal("--job is required") }	flag.Parse()