# Cloud-Native AWS Projects in Go

This workspace includes small, runnable Go examples for core AWS services:

- DynamoDB: CRUD operations
- S3: upload and download files
- SQS: producer and consumer
- SNS: publish messages
- Lambda: simple handler
- IAM: caller identity and policy evaluation
- Kinesis: stream producer
- EventBridge: put custom events
- Glue: trigger a job
- API Gateway: call a REST API

## Prerequisites
- Go 1.22+
- AWS SDK for Go v2
- AWS credentials configured via `aws configure`, environment variables, or SSO.
- Set `AWS_REGION` (e.g., `export AWS_REGION=us-east-1`).

## Quick Start
Each project is standalone. Navigate into the folder and run the sample.

Example (S3):

```zsh
cd s3-files
go run ./cmd/upload --bucket my-bucket --file ./sample.txt --key sample.txt
```

See each project's `README.md` for usage.
