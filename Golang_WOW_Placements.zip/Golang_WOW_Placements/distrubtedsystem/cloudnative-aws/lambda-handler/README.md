# Lambda Handler (Go)

Minimal AWS Lambda function using the Go runtime.

## Build for Lambda
```zsh
cd lambda-handler
GOOS=linux GOARCH=amd64 go build -o bootstrap ./cmd
zip function.zip bootstrap
```

Deploy the zip to a Lambda function with `Runtime: provided.al2023` and `Handler: bootstrap`.
