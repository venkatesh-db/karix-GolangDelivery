package main

import (
	"context"
	"flag"
	"log"

	"cloudnative-aws/pkg/awsconfig"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/sns"
)

func main() {
	var topicArn, msg string
	flag.StringVar(&topicArn, "topic", "", "SNS topic ARN")
	flag.StringVar(&msg, "msg", "hello", "Message body")
	flag.Parse()
	if topicArn == "" { log.Fatal("--topic is required") }

	ctx := context.Background()
	cfg, err := awsconfig.LoadDefault(ctx)
	if err != nil { log.Fatal(err) }
	snsc := sns.NewFromConfig(cfg)

	_, err = snsc.Publish(ctx, &sns.PublishInput{TopicArn: aws.String(topicArn), Message: aws.String(msg)})
	if err != nil { log.Fatal(err) }
}
package main

import (
    "context"
    "flag"
    "log"

    "cloudnative-aws/pkg/awsconfig"
    "github.com/aws/aws-sdk-go-v2/aws"
    "github.com/aws/aws-sdk-go-v2/service/sns"
)

func main() {
    var topicArn, msg string
    flag.StringVar(&topicArn, "topic", "", "SNS topic ARN")
    flag.StringVar(&msg, "msg", "hello", "Message body")
    flag.Parse()
    if topicArn == "" { log.Fatal("--topic is required") }

    ctx := context.Background()
    cfg, err := awsconfig.LoadDefault(ctx)
    if err != nil { log.Fatal(err) }
    snsc := sns.NewFromConfig(cfg)

    _, err = snsc.Publish(ctx, &sns.PublishInput{TopicArn: aws.String(topicArn), Message: aws.String(msg)})
    if err != nil { log.Fatal(err) }
}package main

import (
	"context"
	"flag"
	"log"

	"cloudnative-aws/pkg/awsconfig"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/sns"
)

func main() {
	var topicArn, msg string
	flag.StringVar(&topicArn, "topic", "", "SNS topic ARN")
	flag.StringVar(&msg, "msg", "hello", "Message body")
	flag.Parse()
	if topicArn == "" { log.Fatal("--topic is required") }

	ctx := context.Background()
	cfg, err := awsconfig.LoadDefault(ctx)
	if err != nil { log.Fatal(err) }
	snsc := sns.NewFromConfig(cfg)

	_, err = snsc.Publish(ctx, &sns.PublishInput{TopicArn: aws.String(topicArn), Message: aws.String(msg)})
	if err != nil { log.Fatal(err) }
}
package cmd
package main

import (
	"context"
	"flag"
	"log"





















}	if err != nil { log.Fatal(err) }	_, err = snsc.Publish(ctx, &sns.PublishInput{TopicArn: aws.String(topicArn), Message: aws.String(msg)})	snsc := sns.NewFromConfig(cfg)	if err != nil { log.Fatal(err) }	cfg, err := awsconfig.LoadDefault(ctx)	ctx := context.Background()	if topicArn == "" { log.Fatal("--topic is required") }	flag.Parse()	flag.StringVar(&msg, "msg", "hello", "Message body")	flag.StringVar(&topicArn, "topic", "", "SNS topic ARN")	var topicArn, msg stringfunc main() {)	"github.com/aws/aws-sdk-go-v2/service/sns"	"github.com/aws/aws-sdk-go-v2/aws"	"cloudnative-aws/pkg/awsconfig"