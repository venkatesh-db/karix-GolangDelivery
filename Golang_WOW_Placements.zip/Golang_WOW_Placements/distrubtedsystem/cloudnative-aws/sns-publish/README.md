# SNS Publish (Go)

Publish a message to an SNS topic.

## Run
```zsh
cd sns-publish
go run ./cmd --topic arn:aws:sns:<region>:<account>:<name> --msg "hello"
```
