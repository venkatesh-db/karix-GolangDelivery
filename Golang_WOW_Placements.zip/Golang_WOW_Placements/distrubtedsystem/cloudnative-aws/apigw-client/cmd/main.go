package main

import (
    "flag"
    "io"
    "log"
    "net/http"
)

func main() {
    var url string
    flag.StringVar(&url, "url", "", "API Gateway URL")
    flag.Parse()
    if url == "" { log.Fatal("--url is required") }

    resp, err := http.Get(url)
    if err != nil { log.Fatal(err) }
    defer resp.Body.Close()
    b, _ := io.ReadAll(resp.Body)
    log.Printf("status: %d, body: %s", resp.StatusCode, string(b))
}
package main

import (
    "flag"
    "io"
    "log"
    "net/http"
)

func main() {
    var url string
    flag.StringVar(&url, "url", "", "API Gateway URL")
    flag.Parse()
    if url == "" { log.Fatal("--url is required") }

    resp, err := http.Get(url)
    if err != nil { log.Fatal(err) }
    defer resp.Body.Close()
    b, _ := io.ReadAll(resp.Body)
    log.Printf("status: %d, body: %s", resp.StatusCode, string(b))
}
package main

import (
    "flag"
    "io"
    "log"
    "net/http"
)

func main() {
    var url string
    flag.StringVar(&url, "url", "", "API Gateway URL")
    flag.Parse()
    if url == "" { log.Fatal("--url is required") }

    resp, err := http.Get(url)
    if err != nil { log.Fatal(err) }
    defer resp.Body.Close()
    b, _ := io.ReadAll(resp.Body)
    log.Printf("status: %d, body: %s", resp.StatusCode, string(b))
}package main

import (
    "flag"
    "io"
    "log"
    "net/http"
)

func main() {
    var url string
    flag.StringVar(&url, "url", "", "API Gateway URL")
    flag.Parse()
    if url == "" { log.Fatal("--url is required") }

    resp, err := http.Get(url)
    if err != nil { log.Fatal(err) }
    defer resp.Body.Close()
    b, _ := io.ReadAll(resp.Body)
    log.Printf("status: %d, body: %s", resp.StatusCode, string(b))
}




}	log.Printf("status: %d, body: %s", resp.StatusCode, string(b))	b, _ := io.ReadAll(resp.Body)	defer resp.Body.Close()	if err != nil { log.Fatal(err) }	resp, err := http.Get(url)	if url == "" { log.Fatal("--url is required") }	flag.Parse()	flag.StringVar(&url, "url", "", "API Gateway URL")	var url stringfunc main() {)	"net/http"	"log"