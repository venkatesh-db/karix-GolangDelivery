package main

import (
	"context"
	"flag"
	"log"

	"cloudnative-aws/pkg/awsconfig"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/kinesis"
)

func main() {
	var stream, data string
	flag.StringVar(&stream, "stream", "", "Kinesis stream name")
	flag.StringVar(&data, "data", "hello", "Data payload")
	flag.Parse()
	if stream == "" { log.Fatal("--stream is required") }

	ctx := context.Background()
	cfg, err := awsconfig.LoadDefault(ctx)
	if err != nil { log.Fatal(err) }
	kc := kinesis.NewFromConfig(cfg)

	_, err = kc.PutRecord(ctx, &kinesis.PutRecordInput{StreamName: aws.String(stream), Data: []byte(data), PartitionKey: aws.String("pk-1")})
	if err != nil { log.Fatal(err) }
}
package main

import (
    "context"
    "flag"
    "log"

    "cloudnative-aws/pkg/awsconfig"
    "github.com/aws/aws-sdk-go-v2/aws"
    "github.com/aws/aws-sdk-go-v2/service/kinesis"
)

func main() {
    var stream, data string
    flag.StringVar(&stream, "stream", "", "Kinesis stream name")
    flag.StringVar(&data, "data", "hello", "Data payload")
    flag.Parse()
    if stream == "" { log.Fatal("--stream is required") }

    ctx := context.Background()
    cfg, err := awsconfig.LoadDefault(ctx)
    if err != nil { log.Fatal(err) }
    kc := kinesis.NewFromConfig(cfg)

    _, err = kc.PutRecord(ctx, &kinesis.PutRecordInput{StreamName: aws.String(stream), Data: []byte(data), PartitionKey: aws.String("pk-1")})
    if err != nil { log.Fatal(err) }
}package main

import (
	"context"
	"flag"
	"log"

	"cloudnative-aws/pkg/awsconfig"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/kinesis"
)

func main() {
	var stream, data string
	flag.StringVar(&stream, "stream", "", "Kinesis stream name")
	flag.StringVar(&data, "data", "hello", "Data payload")
	flag.Parse()
	if stream == "" { log.Fatal("--stream is required") }

	ctx := context.Background()
	cfg, err := awsconfig.LoadDefault(ctx)
	if err != nil { log.Fatal(err) }
	kc := kinesis.NewFromConfig(cfg)

	_, err = kc.PutRecord(ctx, &kinesis.PutRecordInput{StreamName: aws.String(stream), Data: []byte(data), PartitionKey: aws.String("pk-1")})
	if err != nil { log.Fatal(err) }
}
package cmd
package main

import (
	"context"
	"flag"
	"log"





















}	if err != nil { log.Fatal(err) }	_, err = kc.PutRecord(ctx, &kinesis.PutRecordInput{StreamName: aws.String(stream), Data: []byte(data), PartitionKey: aws.String("pk-1")})	kc := kinesis.NewFromConfig(cfg)	if err != nil { log.Fatal(err) }	cfg, err := awsconfig.LoadDefault(ctx)	ctx := context.Background()	if stream == "" { log.Fatal("--stream is required") }	flag.Parse()	flag.StringVar(&data, "data", "hello", "Data payload")	flag.StringVar(&stream, "stream", "", "Kinesis stream name")	var stream, data stringfunc main() {)	"github.com/aws/aws-sdk-go-v2/service/kinesis"	"github.com/aws/aws-sdk-go-v2/aws"	"cloudnative-aws/pkg/awsconfig"