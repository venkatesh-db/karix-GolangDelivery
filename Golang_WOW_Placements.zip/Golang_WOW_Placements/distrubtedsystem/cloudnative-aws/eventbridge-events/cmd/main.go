package main

import (
    "context"
    "flag"
    "log"
    "time"

    "cloudnative-aws/pkg/awsconfig"
    "github.com/aws/aws-sdk-go-v2/aws"
    "github.com/aws/aws-sdk-go-v2/service/eventbridge"
)

func main() {
    var bus, source string
    flag.StringVar(&bus, "bus", "default", "Event bus name or ARN")
    flag.StringVar(&source, "source", "demo.app", "Event source")
    flag.Parse()

    ctx := context.Background()
    cfg, err := awsconfig.LoadDefault(ctx)
    if err != nil { log.Fatal(err) }
    eb := eventbridge.NewFromConfig(cfg)

    _, err = eb.PutEvents(ctx, &eventbridge.PutEventsInput{Entries: []eventbridge.PutEventsRequestEntry{
        {EventBusName: aws.String(bus), Source: aws.String(source), DetailType: aws.String("demo"), Time: aws.Time(time.Now()), Detail: aws.String("{\"message\":\"hello\"}")},
    }})
    if err != nil { log.Fatal(err) }
}
package main

import (
    "context"
    "flag"
    "log"
    "time"

    "cloudnative-aws/pkg/awsconfig"
    "github.com/aws/aws-sdk-go-v2/aws"
    "github.com/aws/aws-sdk-go-v2/service/eventbridge"
)

func main() {
    var bus, source string
    flag.StringVar(&bus, "bus", "default", "Event bus name or ARN")
    flag.StringVar(&source, "source", "demo.app", "Event source")
    flag.Parse()

    ctx := context.Background()
    cfg, err := awsconfig.LoadDefault(ctx)
    if err != nil { log.Fatal(err) }
    eb := eventbridge.NewFromConfig(cfg)

    _, err = eb.PutEvents(ctx, &eventbridge.PutEventsInput{Entries: []eventbridge.PutEventsRequestEntry{
        {EventBusName: aws.String(bus), Source: aws.String(source), DetailType: aws.String("demo"), Time: aws.Time(time.Now()), Detail: aws.String("{\"message\":\"hello\"}")},
    }})
    if err != nil { log.Fatal(err) }
}package main

import (
    "context"
    "flag"
    "log"
    "time"

    "cloudnative-aws/pkg/awsconfig"
    "github.com/aws/aws-sdk-go-v2/aws"
    "github.com/aws/aws-sdk-go-v2/service/eventbridge"
)

func main() {
    var bus, source string
    flag.StringVar(&bus, "bus", "default", "Event bus name or ARN")
    flag.StringVar(&source, "source", "demo.app", "Event source")
    flag.Parse()

    ctx := context.Background()
    cfg, err := awsconfig.LoadDefault(ctx)
    if err != nil { log.Fatal(err) }
    eb := eventbridge.NewFromConfig(cfg)

    _, err = eb.PutEvents(ctx, &eventbridge.PutEventsInput{Entries: []eventbridge.PutEventsRequestEntry{
        {EventBusName: aws.String(bus), Source: aws.String(source), DetailType: aws.String("demo"), Time: aws.Time(time.Now()), Detail: aws.String("{\"message\":\"hello\"}")},
    }})
    if err != nil { log.Fatal(err) }
}package main

import (
    "context"
    "flag"
    "log"
    "time"

    "cloudnative-aws/pkg/awsconfig"
    "github.com/aws/aws-sdk-go-v2/aws"
    "github.com/aws/aws-sdk-go-v2/service/eventbridge"
)

func main() {
    var bus, source string
    flag.StringVar(&bus, "bus", "default", "Event bus name or ARN")
    flag.StringVar(&source, "source", "demo.app", "Event source")
    flag.Parse()

    ctx := context.Background()
    cfg, err := awsconfig.LoadDefault(ctx)
    if err != nil { log.Fatal(err) }
    eb := eventbridge.NewFromConfig(cfg)

    _, err = eb.PutEvents(ctx, &eventbridge.PutEventsInput{Entries: []eventbridge.PutEventsRequestEntry{
        {EventBusName: aws.String(bus), Source: aws.String(source), DetailType: aws.String("demo"), Time: aws.Time(time.Now()), Detail: aws.String("{\"message\":\"hello\"}")},
    }})
    if err != nil { log.Fatal(err) }
}package cmd
package main

import (
	"context"
	"flag"
	"log"
	"time"






















}	if err != nil { log.Fatal(err) }	}})		{EventBusName: aws.String(bus), Source: aws.String(source), DetailType: aws.String("demo"), Time: aws.Time(time.Now()), Detail: aws.String("{\"message\":\"hello\"}")},	_, err = eb.PutEvents(ctx, &eventbridge.PutEventsInput{Entries: []eventbridge.PutEventsRequestEntry{	eb := eventbridge.NewFromConfig(cfg)	if err != nil { log.Fatal(err) }	cfg, err := awsconfig.LoadDefault(ctx)	ctx := context.Background()	flag.Parse()	flag.StringVar(&source, "source", "demo.app", "Event source")	flag.StringVar(&bus, "bus", "default", "Event bus name or ARN")	var bus, source stringfunc main() {)	"github.com/aws/aws-sdk-go-v2/service/eventbridge"	"github.com/aws/aws-sdk-go-v2/aws"	"cloudnative-aws/pkg/awsconfig"