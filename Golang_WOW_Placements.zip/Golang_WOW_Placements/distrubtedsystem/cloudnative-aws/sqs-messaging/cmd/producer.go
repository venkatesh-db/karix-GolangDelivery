package main

import (
	"context"
	"flag"
	"log"

	"cloudnative-aws/pkg/awsconfig"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/sqs"
)

func main() {
	var queueURL, msg string
	flag.StringVar(&queueURL, "queue", "", "SQS queue URL")
	flag.StringVar(&msg, "msg", "hello", "Message body")
	flag.Parse()
	if queueURL == "" { log.Fatal("--queue is required") }

	ctx := context.Background()
	cfg, err := awsconfig.LoadDefault(ctx)
	if err != nil { log.Fatal(err) }
	sqsc := sqs.NewFromConfig(cfg)

	_, err = sqsc.SendMessage(ctx, &sqs.SendMessageInput{QueueUrl: aws.String(queueURL), MessageBody: aws.String(msg)})
	if err != nil { log.Fatal(err) }
}
package main

import (
	"context"
	"flag"
	"log"

	"cloudnative-aws/pkg/awsconfig"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/sqs"
)

func main() {
	var queueURL, msg string
	flag.StringVar(&queueURL, "queue", "", "SQS queue URL")
	flag.StringVar(&msg, "msg", "hello", "Message body")
	flag.Parse()
	if queueURL == "" { log.Fatal("--queue is required") }

	ctx := context.Background()
	cfg, err := awsconfig.LoadDefault(ctx)
	if err != nil { log.Fatal(err) }
	sqsc := sqs.NewFromConfig(cfg)

	_, err = sqsc.SendMessage(ctx, &sqs.SendMessageInput{QueueUrl: aws.String(queueURL), MessageBody: aws.String(msg)})
	if err != nil { log.Fatal(err) }
}
package cmd
package main

import (
	"context"
	"flag"
	"log"

	"cloudnative-aws/pkg/awsconfig"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/sqs"
)
















}	if err != nil { log.Fatal(err) }	_, err = sqsc.SendMessage(ctx, &sqs.SendMessageInput{QueueUrl: aws.String(queueURL), MessageBody: aws.String(msg)})	sqsc := sqs.NewFromConfig(cfg)	if err != nil { log.Fatal(err) }	cfg, err := awsconfig.LoadDefault(ctx)	ctx := context.Background()	if queueURL == "" { log.Fatal("--queue is required") }	flag.Parse()	flag.StringVar(&msg, "msg", "hello", "Message body")	flag.StringVar(&queueURL, "queue", "", "SQS queue URL")	var queueURL, msg stringfunc main() {