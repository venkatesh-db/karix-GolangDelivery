package main

import (
	"context"
	"flag"
	"log"
	"time"

	"cloudnative-aws/pkg/awsconfig"
	"github.com/aws/aws-sdk-go-v2/service/sqs"
)

func main() {
	var queueURL string
	flag.StringVar(&queueURL, "queue", "", "SQS queue URL")
	flag.Parse()
	if queueURL == "" { log.Fatal("--queue is required") }

	ctx := context.Background()
	cfg, err := awsconfig.LoadDefault(ctx)
	if err != nil { log.Fatal(err) }
	sqsc := sqs.NewFromConfig(cfg)

	for {
		out, err := sqsc.ReceiveMessage(ctx, &sqs.ReceiveMessageInput{QueueUrl: &queueURL, MaxNumberOfMessages: 5, WaitTimeSeconds: 10})
		if err != nil { log.Fatal(err) }
		for _, m := range out.Messages {
			log.Printf("message: %s", *m.Body)
			_, _ = sqsc.DeleteMessage(ctx, &sqs.DeleteMessageInput{QueueUrl: &queueURL, ReceiptHandle: m.ReceiptHandle})
		}
		time.Sleep(1 * time.Second)
	}
}
