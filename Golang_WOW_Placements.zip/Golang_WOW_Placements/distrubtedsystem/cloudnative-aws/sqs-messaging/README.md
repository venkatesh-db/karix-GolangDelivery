# SQS Messaging (Go)

Producer and long-polling consumer.

## Run
```zsh
cd sqs-messaging
# produce
go run ./cmd/producer --queue https://sqs.<region>.amazonaws.com/<account>/<name> --msg "hello"
# consume
go run ./cmd/consumer --queue https://sqs.<region>.amazonaws.com/<account>/<name>
```
