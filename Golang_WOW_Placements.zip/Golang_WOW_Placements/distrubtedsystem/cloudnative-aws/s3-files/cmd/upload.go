package main

import (
	"context"
	"flag"
	"log"
	"os"

	"cloudnative-aws/pkg/awsconfig"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/s3"
)

func main() {
	var bucket, key, file string
	flag.StringVar(&bucket, "bucket", "", "S3 bucket name")
	flag.StringVar(&key, "key", "", "S3 object key")
	flag.StringVar(&file, "file", "", "Local file path")
	flag.Parse()
	if bucket == "" || key == "" || file == "" { log.Fatal("bucket, key and file are required") }

	ctx := context.Background()
	cfg, err := awsconfig.LoadDefault(ctx)
	if err != nil { log.Fatal(err) }
	s3c := s3.NewFromConfig(cfg)

	f, err := os.Open(file)
	if err != nil { log.Fatal(err) }
	defer f.Close()

	_, err = s3c.PutObject(ctx, &s3.PutObjectInput{Bucket: aws.String(bucket), Key: aws.String(key), Body: f})
	if err != nil { log.Fatal(err) }
}
package main

import (
    "context"
    "flag"
    "log"
    "os"

    "cloudnative-aws/pkg/awsconfig"
    "github.com/aws/aws-sdk-go-v2/aws"
    "github.com/aws/aws-sdk-go-v2/service/s3"
)

func main() {
    var bucket, key, file string
    flag.StringVar(&bucket, "bucket", "", "S3 bucket name")
    flag.StringVar(&key, "key", "", "S3 object key")
    flag.StringVar(&file, "file", "", "Local file path")
    flag.Parse()
    if bucket == "" || key == "" || file == "" { log.Fatal("bucket, key and file are required") }

    ctx := context.Background()
    cfg, err := awsconfig.LoadDefault(ctx)
    if err != nil { log.Fatal(err) }
    s3c := s3.NewFromConfig(cfg)

    f, err := os.Open(file)
    if err != nil { log.Fatal(err) }
    defer f.Close()

    _, err = s3c.PutObject(ctx, &s3.PutObjectInput{Bucket: aws.String(bucket), Key: aws.String(key), Body: f})
    if err != nil { log.Fatal(err) }
}package main

import (
	"context"
	"flag"
	"log"
	"os"

	"cloudnative-aws/pkg/awsconfig"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/s3"
)

func main() {
	var bucket, key, file string
	flag.StringVar(&bucket, "bucket", "", "S3 bucket name")
	flag.StringVar(&key, "key", "", "S3 object key")
	flag.StringVar(&file, "file", "", "Local file path")
	flag.Parse()
	if bucket == "" || key == "" || file == "" {
		log.Fatal("bucket, key and file are required")
	}

	ctx := context.Background()
	cfg, err := awsconfig.LoadDefault(ctx)
	if err != nil { log.Fatal(err) }
	s3c := s3.NewFromConfig(cfg)

	f, err := os.Open(file)
	if err != nil { log.Fatal(err) }
	defer f.Close()

	_, err = s3c.PutObject(ctx, &s3.PutObjectInput{Bucket: aws.String(bucket), Key: aws.String(key), Body: f})
	if err != nil { log.Fatal(err) }
}
package cmd
package main

import (
	"context"
	"flag"
	"log"
	"os"




























}	if err != nil { log.Fatal(err) }	_, err = s3c.PutObject(ctx, &s3.PutObjectInput{Bucket: aws.String(bucket), Key: aws.String(key), Body: f})	defer f.Close()	if err != nil { log.Fatal(err) }	f, err := os.Open(file)	s3c := s3.NewFromConfig(cfg)	if err != nil { log.Fatal(err) }	cfg, err := awsconfig.LoadDefault(ctx)	ctx := context.Background()	}		log.Fatal("bucket, key and file are required")	if bucket == "" || key == "" || file == "" {	flag.Parse()	flag.StringVar(&file, "file", "", "Local file path")	flag.StringVar(&key, "key", "", "S3 object key")	flag.StringVar(&bucket, "bucket", "", "S3 bucket name")	var bucket, key, file stringfunc main() {)	"github.com/aws/aws-sdk-go-v2/service/s3"	"github.com/aws/aws-sdk-go-v2/aws"	"cloudnative-aws/pkg/awsconfig"