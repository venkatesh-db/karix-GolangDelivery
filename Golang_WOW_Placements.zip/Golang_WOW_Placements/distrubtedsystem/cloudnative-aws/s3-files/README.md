# S3 Files (Go)

Upload a file to S3.

## Run
```zsh
cd s3-files
go run ./cmd/upload --bucket my-bucket --file ./sample.txt --key sample.txt
```
