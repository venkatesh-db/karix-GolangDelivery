package awsconfig

import (
	"context"
	"testing"
)

func TestLoadDefault(t *testing.T) {
	cfg, err := LoadDefault(context.Background())
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if cfg.Region == "" {
		t.Fatalf("region should not be empty")
	}
}
