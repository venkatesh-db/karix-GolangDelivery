package awsconfig

import (
	"context"
	"os"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
)

// LoadDefault loads AWS configuration from environment and shared config.
// Honors AWS_REGION or defaults to us-east-1 if unset.
func LoadDefault(ctx context.Context) (aws.Config, error) {
	region := os.Getenv("AWS_REGION")
	if region == "" {
		region = "us-east-1"
	}
	return config.LoadDefaultConfig(ctx, config.WithRegion(region))
}
