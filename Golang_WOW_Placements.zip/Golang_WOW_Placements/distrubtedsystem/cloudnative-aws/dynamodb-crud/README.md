# DynamoDB CRUD (Go)

Minimal CRUD example with a partition key `id`.

## Setup
- Create a table `DemoItems` with partition key `id` (String).
- Ensure `AWS_REGION` is set.

## Run
```zsh
cd dynamodb-crud
go run ./cmd --table DemoItems
```
