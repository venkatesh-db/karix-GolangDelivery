package store

import (
	"context"
	"errors"

	"cloudnative-aws/pkg/awsconfig"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
)

type Client struct { db *dynamodb.Client }

func NewClient(ctx context.Context) (*Client, error) {
	cfg, err := awsconfig.LoadDefault(ctx)
	if err != nil { return nil, err }
	return &Client{db: dynamodb.NewFromConfig(cfg)}, nil
}

func (c *Client) PutItem(ctx context.Context, table, id string, attrs map[string]string) error {
	item := map[string]types.AttributeValue{"id": &types.AttributeValueMemberS{Value: id}}
	for k, v := range attrs { item[k] = &types.AttributeValueMemberS{Value: v} }
	_, err := c.db.PutItem(ctx, &dynamodb.PutItemInput{TableName: aws.String(table), Item: item})
	return err
}

func (c *Client) GetItem(ctx context.Context, table, id string) (map[string]string, error) {
	out, err := c.db.GetItem(ctx, &dynamodb.GetItemInput{
		TableName: aws.String(table),
		Key: map[string]types.AttributeValue{"id": &types.AttributeValueMemberS{Value: id}},
	})
	if err != nil { return nil, err }
	if out.Item == nil { return nil, errors.New("not found") }
	var m map[string]string
	if err := attributevalue.UnmarshalMap(out.Item, &m); err != nil { return nil, err }
	return m, nil
}

func (c *Client) DeleteItem(ctx context.Context, table, id string) error {
	_, err := c.db.DeleteItem(ctx, &dynamodb.DeleteItemInput{
		TableName: aws.String(table),
		Key: map[string]types.AttributeValue{"id": &types.AttributeValueMemberS{Value: id}},
	})
	return err
}
package store

import (
    "context"
    "errors"

    "cloudnative-aws/pkg/awsconfig"
    "github.com/aws/aws-sdk-go-v2/aws"
    "github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
    "github.com/aws/aws-sdk-go-v2/service/dynamodb"
    "github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
)

type Client struct { db *dynamodb.Client }

func NewClient(ctx context.Context) (*Client, error) {
    cfg, err := awsconfig.LoadDefault(ctx)
    if err != nil { return nil, err }
    return &Client{db: dynamodb.NewFromConfig(cfg)}, nil
}

func (c *Client) PutItem(ctx context.Context, table, id string, attrs map[string]string) error {
    item := map[string]types.AttributeValue{
        "id": &types.AttributeValueMemberS{Value: id},
    }
    for k, v := range attrs { item[k] = &types.AttributeValueMemberS{Value: v} }
    _, err := c.db.PutItem(ctx, &dynamodb.PutItemInput{TableName: aws.String(table), Item: item})
    return err
}

func (c *Client) GetItem(ctx context.Context, table, id string) (map[string]string, error) {
    out, err := c.db.GetItem(ctx, &dynamodb.GetItemInput{
        TableName: aws.String(table),
        Key: map[string]types.AttributeValue{"id": &types.AttributeValueMemberS{Value: id}},
    })
    if err != nil { return nil, err }
    if out.Item == nil { return nil, errors.New("not found") }
    var m map[string]string
    if err := attributevalue.UnmarshalMap(out.Item, &m); err != nil { return nil, err }
    return m, nil
}

func (c *Client) DeleteItem(ctx context.Context, table, id string) error {
    _, err := c.db.DeleteItem(ctx, &dynamodb.DeleteItemInput{
        TableName: aws.String(table),
        Key: map[string]types.AttributeValue{"id": &types.AttributeValueMemberS{Value: id}},
    })
    return err
}package store

import (
	"context"
	"errors"

	"cloudnative-aws/pkg/awsconfig"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
)

type Client struct {
	db *dynamodb.Client
}

func NewClient(ctx context.Context) (*Client, error) {
	cfg, err := awsconfig.LoadDefault(ctx)
	if err != nil {
		return nil, err
	}
	return &Client{db: dynamodb.NewFromConfig(cfg)}, nil
}

func (c *Client) PutItem(ctx context.Context, table, id string, attrs map[string]string) error {
	item := map[string]types.AttributeValue{
		"id": &types.AttributeValueMemberS{Value: id},
	}
	for k, v := range attrs {
		item[k] = &types.AttributeValueMemberS{Value: v}
	}
	_, err := c.db.PutItem(ctx, &dynamodb.PutItemInput{TableName: aws.String(table), Item: item})
	return err
}

func (c *Client) GetItem(ctx context.Context, table, id string) (map[string]string, error) {
	out, err := c.db.GetItem(ctx, &dynamodb.GetItemInput{
		TableName: aws.String(table),
		Key: map[string]types.AttributeValue{"id": &types.AttributeValueMemberS{Value: id}},
	})
	if err != nil {
		return nil, err
	}
	if out.Item == nil {
		return nil, errors.New("not found")
	}
	var m map[string]string
	if err := attributevalue.UnmarshalMap(out.Item, &m); err != nil {
		return nil, err
	}
	return m, nil
}

func (c *Client) DeleteItem(ctx context.Context, table, id string) error {
	_, err := c.db.DeleteItem(ctx, &dynamodb.DeleteItemInput{
		TableName: aws.String(table),
		Key: map[string]types.AttributeValue{"id": &types.AttributeValueMemberS{Value: id}},
	})
	return err
}
package store
package store

import (
	"context"
	"errors"
























































}	return err	})		Key: map[string]types.AttributeValue{"id": &types.AttributeValueMemberS{Value: id}},		TableName: aws.String(table),	_, err := c.db.DeleteItem(ctx, &dynamodb.DeleteItemInput{func (c *Client) DeleteItem(ctx context.Context, table, id string) error {}	return m, nil	}		return nil, err	if err := attributevalue.UnmarshalMap(out.Item, &m); err != nil {	var m map[string]string	}		return nil, errors.New("not found")	if out.Item == nil {	}		return nil, err	if err != nil {	})		Key: map[string]types.AttributeValue{"id": &types.AttributeValueMemberS{Value: id}},		TableName: aws.String(table),	out, err := c.db.GetItem(ctx, &dynamodb.GetItemInput{func (c *Client) GetItem(ctx context.Context, table, id string) (map[string]string, error) {}	return err	_, err := c.db.PutItem(ctx, &dynamodb.PutItemInput{TableName: aws.String(table), Item: item})	}		item[k] = &types.AttributeValueMemberS{Value: v}	for k, v := range attrs {	}		"id": &types.AttributeValueMemberS{Value: id},	item := map[string]types.AttributeValue{func (c *Client) PutItem(ctx context.Context, table, id string, attrs map[string]string) error {}	return &Client{db: dynamodb.NewFromConfig(cfg)}, nil	}		return nil, err	if err != nil {	cfg, err := awsconfig.LoadDefault(ctx)func NewClient(ctx context.Context) (*Client, error) {}	db *dynamodb.Clienttype Client struct {)	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"	"github.com/aws/aws-sdk-go-v2/service/dynamodb"	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"	"github.com/aws/aws-sdk-go-v2/aws"	"cloudnative-aws/pkg/awsconfig"