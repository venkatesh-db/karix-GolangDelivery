package main

import (
	"context"
	"flag"
	"fmt"
	"log"

	"cloudnative-aws/dynamodb-crud/internal/store"
)

func main() {
	var table string
	flag.StringVar(&table, "table", "DemoItems", "DynamoDB table name")
	flag.Parse()

	ctx := context.Background()
	client, err := store.NewClient(ctx)
	if err != nil { log.Fatal(err) }

	id := "item-1"
	if err := client.PutItem(ctx, table, id, map[string]string{"name": "example", "status": "active"}); err != nil { log.Fatal(err) }
	fmt.Println("PutItem ok")

	item, err := client.GetItem(ctx, table, id)
	if err != nil { log.Fatal(err) }
	fmt.Printf("GetItem: %#v\n", item)

	if err := client.DeleteItem(ctx, table, id); err != nil { log.Fatal(err) }
	fmt.Println("DeleteItem ok")
}
package main

import (
    "context"
    "flag"
    "fmt"
    "log"

    "cloudnative-aws/dynamodb-crud/internal/store"
)

func main() {
    var table string
    flag.StringVar(&table, "table", "DemoItems", "DynamoDB table name")
    flag.Parse()

    ctx := context.Background()
    client, err := store.NewClient(ctx)
    if err != nil {
        log.Fatal(err)
    }

    id := "item-1"
    if err := client.PutItem(ctx, table, id, map[string]string{"name": "example", "status": "active"}); err != nil {
        log.Fatal(err)
    }
    fmt.Println("PutItem ok")

    item, err := client.GetItem(ctx, table, id)
    if err != nil { log.Fatal(err) }
    fmt.Printf("GetItem: %#v\n", item)

    if err := client.DeleteItem(ctx, table, id); err != nil { log.Fatal(err) }
    fmt.Println("DeleteItem ok")
}package main

import (
	"context"
	"flag"
	"fmt"
	"log"

	"cloudnative-aws/dynamodb-crud/internal/store"
)

func main() {
	var table string
	flag.StringVar(&table, "table", "DemoItems", "DynamoDB table name")
	flag.Parse()

	ctx := context.Background()
	client, err := store.NewClient(ctx)
	if err != nil {
		log.Fatal(err)
	}

	// Put an item
	id := "item-1"
	if err := client.PutItem(ctx, table, id, map[string]string{"name": "example", "status": "active"}); err != nil {
		log.Fatal(err)
	}
	fmt.Println("PutItem ok")

	// Get it back
	item, err := client.GetItem(ctx, table, id)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("GetItem: %#v\n", item)

	// Delete
	if err := client.DeleteItem(ctx, table, id); err != nil {
		log.Fatal(err)
	}
	fmt.Println("DeleteItem ok")
}
package cmd
package main

import (
	"context"
	"flag"
	"fmt"
	"log"



































}	fmt.Println("DeleteItem ok")	}		log.Fatal(err)	if err := client.DeleteItem(ctx, table, id); err != nil {	// Delete	fmt.Printf("GetItem: %#v\n", item)	}		log.Fatal(err)	if err != nil {	item, err := client.GetItem(ctx, table, id)	// Get it back	fmt.Println("PutItem ok")	}		log.Fatal(err)	if err := client.PutItem(ctx, table, id, map[string]string{"name": "example", "status": "active"}); err != nil {	id := "item-1"	// Put an item	}		log.Fatal(err)	if err != nil {	client, err := store.NewClient(ctx)	ctx := context.Background()	flag.Parse()	flag.StringVar(&table, "table", "DemoItems", "DynamoDB table name")	var table stringfunc main() {)	"cloudnative-aws/dynamodb-crud/internal/store"