package main

import (
	"context"
	"log"

	"cloudnative-aws/pkg/awsconfig"
	"github.com/aws/aws-sdk-go-v2/service/sts"
)

func main() {
	ctx := context.Background()
	cfg, err := awsconfig.LoadDefault(ctx)
	if err != nil { log.Fatal(err) }
	client := sts.NewFromConfig(cfg)
	out, err := client.GetCallerIdentity(ctx, &sts.GetCallerIdentityInput{})
	if err != nil { log.Fatal(err) }
	log.Printf("Account: %s, Arn: %s", *out.Account, *out.Arn)
}
package main

import (
    "context"
    "log"

    "cloudnative-aws/pkg/awsconfig"
    "github.com/aws/aws-sdk-go-v2/service/sts"
)

func main() {
    ctx := context.Background()
    cfg, err := awsconfig.LoadDefault(ctx)
    if err != nil { log.Fatal(err) }
    client := sts.NewFromConfig(cfg)
    out, err := client.GetCallerIdentity(ctx, &sts.GetCallerIdentityInput{})
    if err != nil { log.Fatal(err) }
    log.Printf("Account: %s, Arn: %s", *out.Account, *out.Arn)
}package main

import (
	"context"
	"log"

	"cloudnative-aws/pkg/awsconfig"
	"github.com/aws/aws-sdk-go-v2/service/sts"
)

func main() {
	ctx := context.Background()
	cfg, err := awsconfig.LoadDefault(ctx)
	if err != nil { log.Fatal(err) }
	client := sts.NewFromConfig(cfg)
	out, err := client.GetCallerIdentity(ctx, &sts.GetCallerIdentityInput{})
	if err != nil { log.Fatal(err) }
	log.Printf("Account: %s, Arn: %s", *out.Account, *out.Arn)
}
package cmd
package main

import (
	"context"
	"log"














}	log.Printf("Account: %s, Arn: %s", *out.Account, *out.Arn)	if err != nil { log.Fatal(err) }	out, err := client.GetCallerIdentity(ctx, &sts.GetCallerIdentityInput{})	client := sts.NewFromConfig(cfg)	if err != nil { log.Fatal(err) }	cfg, err := awsconfig.LoadDefault(ctx)	ctx := context.Background()func main() {)	"github.com/aws/aws-sdk-go-v2/service/sts"	"cloudnative-aws/pkg/awsconfig"