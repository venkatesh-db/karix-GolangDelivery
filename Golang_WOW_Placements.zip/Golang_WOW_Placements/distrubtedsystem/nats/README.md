# 🚀 Event-Driven Distributed Systems with NATS + JetStream

A comprehensive, production-ready Golang project demonstrating distributed systems patterns using NATS and NATS JetStream.

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Quick Start](#quick-start)
3. [Project Structure](#project-structure)
4. [NATS Ecosystem Examples](#nats-ecosystem-examples)
5. [JetStream Streaming Examples](#jetstream-streaming-examples)
6. [Microservices Architecture](#microservices-architecture)
7. [JetStream Key-Value Store](#jetstream-key-value-store)
8. [Testing](#testing)
9. [Troubleshooting](#troubleshooting)

## Prerequisites

- **Go 1.21+** installed
- **Docker & Docker Compose** installed
- Basic understanding of event-driven architecture

## Quick Start

### 1. Start NATS Server

```bash
docker-compose up -d
```

Verify NATS is running:
```bash
curl http://localhost:8222/varz
```

### 2. Initialize Go Modules

```bash
# Initialize all modules
cd examples/01-basic-nats && go mod tidy && cd ../..
cd examples/02-jetstream && go mod tidy && cd ../..
cd examples/03-jetstream-kv && go mod tidy && cd ../..
cd microservices/order-service && go mod tidy && cd ../..
cd microservices/inventory-service && go mod tidy && cd ../..
cd microservices/billing-service && go mod tidy && cd ../..
cd microservices/orchestrator && go mod tidy && cd ../..
```

### 3. Run Basic Examples

```bash
# Run NATS basic examples
cd examples/01-basic-nats
go run main.go

# Run JetStream examples
cd ../02-jetstream
go run main.go

# Run KV Store examples
cd ../03-jetstream-kv
go run main.go
```

### 4. Run Microservices

Open 4 terminal windows and run each service:

```bash
# Terminal 1: Order Service
cd microservices/order-service
go run main.go

# Terminal 2: Inventory Service
cd microservices/inventory-service
go run main.go

# Terminal 3: Billing Service
cd microservices/billing-service
go run main.go

# Terminal 4: Orchestrator
cd microservices/orchestrator
go run main.go
```

### 5. Test the Microservices

```bash
# Create an order (triggers the entire workflow)
curl -X POST http://localhost:8081/order \
  -H "Content-Type: application/json" \
  -d '{
    "order_id": "order-001",
    "customer_id": "customer-123",
    "items": [
      {"product_id": "prod-1", "quantity": 2},
      {"product_id": "prod-2", "quantity": 1}
    ],
    "total_amount": 150.00
  }'

# Check health endpoints
curl http://localhost:8081/health  # Order Service
curl http://localhost:8082/health  # Inventory Service
curl http://localhost:8083/health  # Billing Service
curl http://localhost:8084/health  # Orchestrator
```

## Project Structure

```
nats/
├── docker-compose.yml           # NATS server configuration
├── README.md                    # This file
├── .github/
│   └── copilot-instructions.md
├── examples/
│   ├── 01-basic-nats/
│   │   ├── main.go             # Basic NATS patterns
│   │   └── go.mod
│   ├── 02-jetstream/
│   │   ├── main.go             # JetStream streaming examples
│   │   └── go.mod
│   └── 03-jetstream-kv/
│       ├── main.go             # KV Store examples
│       └── go.mod
├── microservices/
│   ├── order-service/
│   │   ├── main.go             # Creates orders, publishes events
│   │   └── go.mod
│   ├── inventory-service/
│   │   ├── main.go             # Reserves inventory
│   │   └── go.mod
│   ├── billing-service/
│   │   ├── main.go             # Processes billing
│   │   └── go.mod
│   └── orchestrator/
│       ├── main.go             # Event monitoring & orchestration
│       └── go.mod
└── shared/
    ├── models/
    │   └── events.go           # Event definitions
    ├── logger/
    │   └── logger.go           # Structured logging
    └── config/
        └── config.go           # Configuration management
```

## NATS Ecosystem Examples

### What You'll Learn

- **Connection Management**: Connect to NATS with retry logic
- **Pub/Sub Pattern**: Basic publish and subscribe
- **Queue Groups**: Load balancing across subscribers
- **Request/Reply**: Synchronous request-response pattern
- **Graceful Shutdown**: Clean connection closure

### Running the Examples

```bash
cd examples/01-basic-nats
go run main.go
```

Each example is self-contained and demonstrates a specific pattern.

## JetStream Streaming Examples

### What You'll Learn

- **Stream Management**: Create, update, and configure streams
- **Producer Patterns**: Publishing with acknowledgments and metadata
- **Pull Consumers**: Fetch messages in batches with manual ack
- **Push Consumers**: Durable and ephemeral consumers
- **Ordered Consumers**: Guaranteed ordering with recovery

### Running the Examples

```bash
cd examples/02-jetstream
go run main.go
```

## Microservices Architecture

### Architecture Overview

```
Order Service → [ORDERS Stream] → Inventory Service
                                         ↓
                               [INVENTORY Stream]
                                         ↓
                                  Billing Service
                                         ↓
                                [BILLING Stream]
                                         ↓
                                   Orchestrator
                              (monitors all events)
```

### Event Flow

1. **Order Created**: User creates an order via REST API
2. **Inventory Reserved**: Inventory service reserves items
3. **Billing Completed**: Billing service processes payment
4. **Orchestrator**: Monitors and logs entire workflow

### Features

- ✅ Durable consumers with manual acknowledgment
- ✅ Dead letter queue (DLQ) handling
- ✅ Retry with exponential backoff
- ✅ Correlation ID tracking
- ✅ Structured logging with slog
- ✅ Graceful shutdown
- ✅ Health check endpoints

### Service Ports

- Order Service: `8081`
- Inventory Service: `8082`
- Billing Service: `8083`
- Orchestrator: `8084`

## JetStream Key-Value Store

### What You'll Learn

- **Bucket Management**: Create KV buckets with TTL and history
- **CRUD Operations**: Put, Get, Delete with revision control
- **Watchers**: Monitor key changes in real-time
- **Config Store Pattern**: Dynamic configuration management

### Running the Examples

```bash
cd examples/03-jetstream-kv
go run main.go
```

### Use Cases

- Configuration management
- Feature flags
- Distributed locks
- Session storage
- Cache layer

## Testing

### Manual Testing with cURL

```bash
# Create multiple orders
for i in {1..5}; do
  curl -X POST http://localhost:8081/order \
    -H "Content-Type: application/json" \
    -d "{
      \"order_id\": \"order-$i\",
      \"customer_id\": \"customer-$i\",
      \"items\": [{\"product_id\": \"prod-1\", \"quantity\": $i}],
      \"total_amount\": $((i * 50)).00
    }"
  sleep 1
done
```

### Load Testing

```bash
# Install hey (HTTP load testing tool)
go install github.com/rakyll/hey@latest

# Run load test
hey -n 100 -c 10 -m POST \
  -H "Content-Type: application/json" \
  -d '{"order_id":"order-load-test","customer_id":"cust-123","items":[{"product_id":"prod-1","quantity":1}],"total_amount":50.00}' \
  http://localhost:8081/order
```

### Monitoring NATS

```bash
# View NATS server stats
curl http://localhost:8222/varz | jq

# View JetStream info
curl http://localhost:8222/jsz | jq

# View specific stream
curl http://localhost:8222/jsz?stream=ORDERS | jq
```

## Troubleshooting

### NATS Server Not Starting

```bash
# Check if port 4222 is already in use
lsof -i :4222

# Restart Docker containers
docker-compose down -v
docker-compose up -d
```

### Connection Refused Errors

```bash
# Verify NATS is running
docker-compose ps

# Check NATS logs
docker-compose logs nats
```

### Messages Not Being Consumed

1. Check if streams exist:
   ```bash
   curl http://localhost:8222/jsz?streams=true | jq
   ```

2. Check consumer status:
   ```bash
   curl http://localhost:8222/jsz?consumers=true | jq
   ```

3. Check service logs for errors

### Module Import Issues

```bash
# Clean module cache
go clean -modcache

# Reinstall dependencies
go mod tidy
go mod download
```

## Key Concepts Explained

### Pull vs Push Consumers

**Pull Consumer**: Your application fetches messages when ready
- Better for batch processing
- Full control over rate limiting
- Recommended for most use cases

**Push Consumer**: NATS pushes messages to your application
- Lower latency
- Good for real-time processing
- Requires careful backpressure handling

### Acknowledgment Modes

- **Ack**: Message processed successfully
- **Nak**: Message processing failed, redeliver
- **Term**: Permanently terminate message (send to DLQ)
- **InProgress**: Extend processing time

### Retention Policies

- **Limits**: Keep messages up to max count/size/age
- **Interest**: Keep messages while consumers are active
- **WorkQueue**: Messages removed after acknowledged

## Advanced Features

### Horizontal Scaling

Run multiple instances of any service:

```bash
# Run 3 instances of inventory service
cd microservices/inventory-service
PORT=8082 go run main.go &
PORT=8092 go run main.go &
PORT=8093 go run main.go &
```

Queue groups ensure load balancing automatically.

### Circuit Breaker Pattern

Each service includes basic circuit breaker logic for external calls.

### Distributed Tracing

All events include `correlation_id` for end-to-end tracing.

## Production Considerations

### Security

- Enable TLS for NATS connections
- Use authentication tokens or JWT
- Implement proper secret management

### Monitoring

- Integrate with Prometheus for metrics
- Set up alerts for consumer lag
- Monitor JetStream storage usage

### High Availability

- Run NATS cluster (3+ nodes)
- Configure stream replication factor
- Use multiple availability zones

## Resources

- [NATS Documentation](https://docs.nats.io/)
- [JetStream Guide](https://docs.nats.io/nats-concepts/jetstream)
- [nats.go Client](https://github.com/nats-io/nats.go)
- [NATS by Example](https://natsbyexample.com/)

## License

MIT License - feel free to use this code for learning and production projects.

## Contributing

Contributions welcome! Please open an issue or PR for improvements.

---

**Built with ❤️ using NATS and Go**
