package main

import (
	"context"
	"fmt"
	"log"
	"time"

	"github.com/nats-io/nats.go"
	"github.com/nats-io/nats.go/jetstream"
)

const natsURL = "nats://localhost:4222"

func main() {
	fmt.Println("🚀 NATS JetStream Examples - Distributed Streaming")
	fmt.Println("=" + string(make([]byte, 60)) + "=")

	// Run all JetStream examples
	runExample("1. Creating JetStream Context & Streams", exampleJetStreamSetup)
	runExample("2. JetStream Producer (Publishing with Acks)", exampleProducer)
	runExample("3. Pull Consumer (Fetch & Ack)", examplePullConsumer)
	runExample("4. Push Consumer (Durable)", examplePushConsumer)
	runExample("5. Ordered Consumer (Guaranteed Ordering)", exampleOrderedConsumer)

	fmt.Println("\n✅ All JetStream examples completed successfully!")
}

func runExample(name string, fn func()) {
	fmt.Printf("\n\n📌 %s\n", name)
	fmt.Println("-----------------------------------------------------------")
	fn()
	time.Sleep(1 * time.Second)
}

// =============================================================================
// EXAMPLE 1: Creating JetStream Context & Stream Management
// =============================================================================
func exampleJetStreamSetup() {
	// Connect to NATS
	nc, err := nats.Connect(natsURL)
	if err != nil {
		log.Fatalf("❌ Failed to connect: %v", err)
	}
	defer nc.Close()

	// Create JetStream context
	js, err := jetstream.New(nc)
	if err != nil {
		log.Fatalf("❌ Failed to create JetStream context: %v", err)
	}

	fmt.Println("✅ JetStream context created")

	// Stream configuration
	streamName := "DEMO_STREAM"
	streamConfig := jetstream.StreamConfig{
		Name:        streamName,
		Description: "Demo stream for JetStream examples",
		Subjects:    []string{"demo.>"},
		Retention:   jetstream.LimitsPolicy,
		MaxMsgs:     1000,
		MaxBytes:    1024 * 1024, // 1MB
		MaxAge:      24 * time.Hour,
		Storage:     jetstream.FileStorage,
		Replicas:    1,
		Discard:     jetstream.DiscardOld,
	}

	// Create or update stream
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	stream, err := js.CreateStream(ctx, streamConfig)
	if err != nil {
		// If stream exists, update it
		stream, err = js.UpdateStream(ctx, streamConfig)
		if err != nil {
			log.Fatalf("❌ Failed to create/update stream: %v", err)
		}
		fmt.Printf("♻️  Updated existing stream: %s\n", streamName)
	} else {
		fmt.Printf("✅ Created new stream: %s\n", streamName)
	}

	// Get stream info
	info, err := stream.Info(ctx)
	if err != nil {
		log.Printf("❌ Failed to get stream info: %v", err)
		return
	}

	fmt.Printf("\n📊 Stream Information:\n")
	fmt.Printf("   Name: %s\n", info.Config.Name)
	fmt.Printf("   Subjects: %v\n", info.Config.Subjects)
	fmt.Printf("   Messages: %d\n", info.State.Msgs)
	fmt.Printf("   Bytes: %d\n", info.State.Bytes)
	fmt.Printf("   First Seq: %d\n", info.State.FirstSeq)
	fmt.Printf("   Last Seq: %d\n", info.State.LastSeq)
}

// =============================================================================
// EXAMPLE 2: JetStream Producer - Publishing with Acknowledgments
// =============================================================================
func exampleProducer() {
	nc, err := nats.Connect(natsURL)
	if err != nil {
		log.Fatalf("❌ Failed to connect: %v", err)
	}
	defer nc.Close()

	js, err := jetstream.New(nc)
	if err != nil {
		log.Fatalf("❌ Failed to create JetStream context: %v", err)
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// Ensure stream exists
	_, err = js.CreateOrUpdateStream(ctx, jetstream.StreamConfig{
		Name:     "DEMO_STREAM",
		Subjects: []string{"demo.>"},
	})
	if err != nil {
		log.Fatalf("❌ Failed to create stream: %v", err)
	}

	// Publish messages with different options
	messages := []struct {
		subject string
		data    string
		msgID   string
	}{
		{"demo.orders", "Order #1: Laptop", "msg-001"},
		{"demo.orders", "Order #2: Mouse", "msg-002"},
		{"demo.events", "User logged in", "msg-003"},
		{"demo.events", "User clicked button", "msg-004"},
	}

	for i, msg := range messages {
		// Publish with metadata and deduplication
		pubAck, err := js.Publish(ctx, msg.subject, []byte(msg.data),
			jetstream.WithMsgID(msg.msgID), // Message deduplication
			jetstream.WithExpectStream("DEMO_STREAM"),
		)
		if err != nil {
			log.Printf("❌ Publish failed: %v", err)
			continue
		}

		fmt.Printf("📤 Published message #%d:\n", i+1)
		fmt.Printf("   Subject: %s\n", msg.subject)
		fmt.Printf("   Data: %s\n", msg.data)
		fmt.Printf("   Stream: %s\n", pubAck.Stream)
		fmt.Printf("   Sequence: %d\n", pubAck.Sequence)
		fmt.Printf("   Duplicate: %v\n\n", pubAck.Duplicate)

		time.Sleep(200 * time.Millisecond)
	}

	// Test deduplication - republish same message
	fmt.Println("🧪 Testing deduplication (republishing msg-001)...")
	pubAck, err := js.Publish(ctx, "demo.orders", []byte("Order #1: Laptop"),
		jetstream.WithMsgID("msg-001"),
	)
	if err != nil {
		log.Printf("❌ Publish failed: %v", err)
	} else {
		fmt.Printf("✅ Duplicate detected: %v (Sequence: %d)\n", pubAck.Duplicate, pubAck.Sequence)
	}
}

// Additional examples for Pull Consumer, Push Consumer, and Ordered Consumer would follow here...
