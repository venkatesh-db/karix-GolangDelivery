package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"

	"github.com/nats-io/nats.go"
)

const natsURL = "nats://localhost:4222"

func main() {
	fmt.Println("🚀 NATS Ecosystem Examples - Demonstrating Core Patterns")
	fmt.Println("=" + string(make([]byte, 60)) + "=")

	// Run all examples sequentially
	runExample("1. Connection Management", exampleConnection)
	runExample("2. Basic Publish/Subscribe", examplePubSub)
	runExample("3. Queue Groups (Load Balancing)", exampleQueueGroups)
	runExample("4. Request/Reply Pattern", exampleRequestReply)
	runExample("5. Graceful Shutdown", exampleGracefulShutdown)

	fmt.Println("\n✅ All NATS examples completed successfully!")
}

func runExample(name string, fn func()) {
	fmt.Printf("\n\n📌 %s\n", name)
	fmt.Println("-----------------------------------------------------------")
	fn()
	time.Sleep(1 * time.Second) // Small delay between examples
}

// =============================================================================
// EXAMPLE 1: Connection Management with Retry Logic
// =============================================================================
func exampleConnection() {
	fmt.Println("Connecting to NATS server...")

	// Connect with options
	opts := []nats.Option{
		nats.Name("NATS-Example-Client"),
		nats.MaxReconnects(10),
		nats.ReconnectWait(2 * time.Second),
		nats.DisconnectErrHandler(func(nc *nats.Conn, err error) {
			if err != nil {
				log.Printf("⚠️  Disconnected: %v", err)
			}
		}),
		nats.ReconnectHandler(func(nc *nats.Conn) {
			log.Printf("✅ Reconnected to %s", nc.ConnectedUrl())
		}),
		nats.ClosedHandler(func(nc *nats.Conn) {
			log.Printf("🔒 Connection closed")
		}),
	}

	nc, err := nats.Connect(natsURL, opts...)
	if err != nil {
		log.Fatalf("❌ Failed to connect: %v", err)
	}
	defer nc.Close()

	fmt.Printf("✅ Connected to NATS server: %s\n", nc.ConnectedUrl())
	fmt.Printf("   Server ID: %s\n", nc.ConnectedServerId())
	fmt.Printf("   Connection Status: %s\n", nc.Status())
}

// =============================================================================
// EXAMPLE 2: Basic Publish/Subscribe Pattern
// =============================================================================
func examplePubSub() {
	nc, err := nats.Connect(natsURL)
	if err != nil {
		log.Fatalf("❌ Connection failed: %v", err)
	}
	defer nc.Close()

	subject := "demo.basic"
	receivedCount := 0
	var mu sync.Mutex

	// Subscribe to subject
	sub, err := nc.Subscribe(subject, func(msg *nats.Msg) {
		mu.Lock()
		receivedCount++
		count := receivedCount
		mu.Unlock()

		fmt.Printf("📨 Received message #%d: %s\n", count, string(msg.Data))
	})
	if err != nil {
		log.Fatalf("❌ Subscribe failed: %v", err)
	}
	defer sub.Unsubscribe()

	// Give subscriber time to register
	time.Sleep(100 * time.Millisecond)

	// Publish messages
	messages := []string{
		"Hello NATS!",
		"Event-driven architecture",
		"Publish/Subscribe pattern",
	}

	for i, msg := range messages {
		err := nc.Publish(subject, []byte(msg))
		if err != nil {
			log.Printf("❌ Publish failed: %v", err)
			continue
		}
		fmt.Printf("📤 Published message #%d: %s\n", i+1, msg)
		time.Sleep(200 * time.Millisecond)
	}

	// Flush to ensure all messages are sent
	nc.Flush()
	time.Sleep(500 * time.Millisecond)

	fmt.Printf("\n✅ Pub/Sub complete. Sent: %d, Received: %d\n", len(messages), receivedCount)
}

// =============================================================================
// EXAMPLE 3: Queue Groups for Load Balancing
// =============================================================================
func exampleQueueGroups() {
	nc, err := nats.Connect(natsURL)
	if err != nil {
		log.Fatalf("❌ Connection failed: %v", err)
	}
	defer nc.Close()

	subject := "demo.queue"
	queueGroup := "workers"
	workerCount := 3
	messageCount := 10

	// Track which worker handled which message
	workerStats := make(map[string]int)
	var mu sync.Mutex

	// Create multiple workers in the same queue group
	var wg sync.WaitGroup
	for i := 1; i <= workerCount; i++ {
		workerID := fmt.Sprintf("worker-%d", i)
		wg.Add(1)

		// Queue subscription - only one worker in the group receives each message
		_, err := nc.QueueSubscribe(subject, queueGroup, func(msg *nats.Msg) {
			mu.Lock()
			workerStats[workerID]++
			count := workerStats[workerID]
			mu.Unlock()

			fmt.Printf("👷 %s processed message: %s (total: %d)\n",
				workerID, string(msg.Data), count)

			// Simulate processing time
			time.Sleep(100 * time.Millisecond)
		})
		if err != nil {
			log.Printf("❌ QueueSubscribe failed for %s: %v", workerID, err)
		}
	}

	// Wait for subscriptions to be ready
	time.Sleep(200 * time.Millisecond)

	// Publish messages - they will be distributed across workers
	fmt.Printf("\n📤 Publishing %d messages to queue group '%s'...\n\n", messageCount, queueGroup)
	for i := 1; i <= messageCount; i++ {
		msg := fmt.Sprintf("Task #%d", i)
		err := nc.Publish(subject, []byte(msg))
		if err != nil {
			log.Printf("❌ Publish failed: %v", err)
		}
		time.Sleep(50 * time.Millisecond)
	}

	nc.Flush()
	time.Sleep(2 * time.Second)

	// Show distribution statistics
	fmt.Println("\n📊 Message Distribution:")
	mu.Lock()
	for worker, count := range workerStats {
		fmt.Printf("   %s: %d messages (%.1f%%)\n",
			worker, count, float64(count)/float64(messageCount)*100)
	}
	mu.Unlock()
}

// =============================================================================
// EXAMPLE 4: Request/Reply Pattern with Timeout
// =============================================================================
func exampleRequestReply() {
	nc, err := nats.Connect(natsURL)
	if err != nil {
		log.Fatalf("❌ Connection failed: %v", err)
	}
	defer nc.Close()

	subject := "demo.service"

	// Create a service that responds to requests
	_, err = nc.Subscribe(subject, func(msg *nats.Msg) {
		request := string(msg.Data)
		fmt.Printf("🔔 Service received request: %s\n", request)

		// Simulate processing
		time.Sleep(100 * time.Millisecond)

		// Send response
		response := fmt.Sprintf("Processed: %s", request)
		err := msg.Respond([]byte(response))
		if err != nil {
			log.Printf("❌ Failed to send response: %v", err)
		}
		fmt.Printf("📨 Service sent response: %s\n", response)
	})
	if err != nil {
		log.Fatalf("❌ Subscribe failed: %v", err)
	}

	// Wait for service to be ready
	time.Sleep(200 * time.Millisecond)

	// Make requests with timeout
	requests := []string{"Calculate sum", "Fetch user data", "Process order"}

	for i, req := range requests {
		fmt.Printf("\n🔵 Client sending request #%d: %s\n", i+1, req)

		// Send request and wait for response (with timeout)
		msg, err := nc.Request(subject, []byte(req), 2*time.Second)
		if err != nil {
			log.Printf("❌ Request failed: %v", err)
			continue
		}

		fmt.Printf("✅ Client received response: %s\n", string(msg.Data))
	}

	// Test timeout scenario
	fmt.Println("\n🧪 Testing timeout scenario...")
	slowSubject := "demo.slow-service"

	// Create slow service (doesn't respond in time)
	_, err = nc.Subscribe(slowSubject, func(msg *nats.Msg) {
		fmt.Println("😴 Slow service received request but taking too long...")
		time.Sleep(5 * time.Second) // Intentionally slow
		msg.Respond([]byte("Too late!"))
	})
	if err != nil {
		log.Printf("❌ Subscribe failed: %v", err)
	}

	time.Sleep(100 * time.Millisecond)

	_, err = nc.Request(slowSubject, []byte("urgent request"), 1*time.Second)
	if err != nil {
		fmt.Printf("⏰ Expected timeout occurred: %v\n", err)
	}
}

// =============================================================================
// EXAMPLE 5: Graceful Shutdown with Context
// =============================================================================
func exampleGracefulShutdown() {
	nc, err := nats.Connect(natsURL)
	if err != nil {
		log.Fatalf("❌ Connection failed: %v", err)
	}

	subject := "demo.shutdown"
	ctx, cancel := context.WithCancel(context.Background())
	var wg sync.WaitGroup

	// Subscriber with graceful shutdown
	wg.Add(1)
	go func() {
		defer wg.Done()

		sub, err := nc.Subscribe(subject, func(msg *nats.Msg) {
			fmt.Printf("📨 Received: %s\n", string(msg.Data))
		})
		if err != nil {
			log.Printf("❌ Subscribe failed: %v", err)
			return
		}

		fmt.Println("✅ Subscriber running, waiting for shutdown signal...")

		// Wait for shutdown signal
		<-ctx.Done()

		fmt.Println("🛑 Shutdown signal received, cleaning up...")

		// Drain subscription (process pending messages, then unsubscribe)
		if err := sub.Drain(); err != nil {
			log.Printf("❌ Drain failed: %v", err)
		}

		fmt.Println("✅ Subscriber shutdown complete")
	}()

	// Wait for subscriber to be ready
	time.Sleep(200 * time.Millisecond)

	// Publish some messages
	for i := 1; i <= 5; i++ {
		msg := fmt.Sprintf("Message #%d", i)
		nc.Publish(subject, []byte(msg))
		fmt.Printf("📤 Published: %s\n", msg)
		time.Sleep(100 * time.Millisecond)
	}

	// Simulate graceful shutdown after 1 second
	time.Sleep(1 * time.Second)

	fmt.Println("\n🔔 Initiating graceful shutdown...")
	cancel() // Signal shutdown

	// Wait for graceful cleanup
	wg.Wait()

	// Drain connection (flush pending messages)
	if err := nc.Drain(); err != nil {
		log.Printf("❌ Connection drain failed: %v", err)
	}

	fmt.Println("✅ Connection drained and closed gracefully")
}

// =============================================================================
// BONUS: Signal-based Graceful Shutdown Pattern
// =============================================================================
func setupGracefulShutdown(cleanup func()) {
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, os.Interrupt, syscall.SIGTERM)

	go func() {
		sig := <-sigChan
		fmt.Printf("\n🛑 Received signal: %v\n", sig)
		fmt.Println("⏳ Performing graceful shutdown...")

		cleanup()

		fmt.Println("✅ Shutdown complete")
		os.Exit(0)
	}()
}
