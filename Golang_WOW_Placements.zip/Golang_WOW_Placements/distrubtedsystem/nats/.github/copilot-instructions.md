# NATS JetStream Distributed Systems Project

This project demonstrates event-driven distributed systems and microservices with NATS and NATS JetStream.

## Project Structure
- `/examples` - Basic NATS and JetStream examples
- `/microservices` - Full microservices architecture
- `/shared` - Common utilities and models
- `docker-compose.yml` - NATS server setup
