package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/nats-io/nats.go"
	"github.com/nats-io/nats.go/jetstream"
)

const (
	natsURL      = "nats://localhost:4222"
	streamName   = "ORDERS"
	orderSubject = "order.created"
)

func main() {
	log.Println("🚀 Starting Order Service...")

	// Connect to NATS
	nc, err := nats.Connect(natsURL)
	if err != nil {
		log.Fatalf("❌ Failed to connect to NATS: %v", err)
	}
	defer nc.Close()

	// Create JetStream context
	js, err := jetstream.New(nc)
	if err != nil {
		log.Fatalf("❌ Failed to create JetStream context: %v", err)
	}

	// Ensure stream exists
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	_, err = js.CreateOrUpdateStream(ctx, jetstream.StreamConfig{
		Name:     streamName,
		Subjects: []string{orderSubject},
	})
	if err != nil {
		log.Fatalf("❌ Failed to create stream: %v", err)
	}

	log.Printf("✅ Stream '%s' is ready\n", streamName)

	// Start HTTP server for health check and order creation
	http.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("OK"))
	})

	http.HandleFunc("/order", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			w.WriteHeader(http.StatusMethodNotAllowed)
			return
		}

		// Simulate order creation
		orderID := fmt.Sprintf("order-%d", time.Now().UnixNano())
		log.Printf("📦 Creating order: %s\n", orderID)

		// Publish order.created event
		_, err := js.Publish(ctx, orderSubject, []byte(orderID))
		if err != nil {
			log.Printf("❌ Failed to publish order: %v", err)
			w.WriteHeader(http.StatusInternalServerError)
			return
		}

		log.Printf("✅ Published order.created event: %s\n", orderID)
		w.WriteHeader(http.StatusCreated)
		w.Write([]byte(orderID))
	})

	// Add REST API endpoint for health check
	http.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("Order Service is healthy"))
	})

	go func() {
		if err := http.ListenAndServe(":8080", nil); err != nil {
			log.Fatalf("❌ Failed to start HTTP server: %v", err)
		}
	}()

	// Publish an 'order.created' event
	go func() {
		for {
			time.Sleep(5 * time.Second) // Simulate order creation every 5 seconds
			msg := nats.NewMsg(orderSubject)
			msg.Header.Set("event_id", fmt.Sprintf("order-%d", time.Now().UnixNano()))
			msg.Data = []byte("{\"order_id\": \"12345\", \"status\": \"created\"}")

			if _, err := js.PublishMsg(msg); err != nil {
				log.Printf("❌ Failed to publish message: %v", err)
			} else {
				log.Println("✅ Published 'order.created' event")
			}
		}
	}()

	// Graceful shutdown handling
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
	<-stop
	log.Println("🚦 Shutting down Order Service...")
}
