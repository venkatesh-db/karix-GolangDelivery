package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/nats-io/nats.go"
	"github.com/nats-io/nats.go/jetstream"
)

const (
	natsURL          = "nats://localhost:4222"
	streamName       = "INVENTORY"
	orderCreatedSubj = "order.created"
	inventorySubj    = "inventory.reserved"
)

func main() {
	log.Println("🚀 Starting Inventory Service...")

	// Connect to NATS
	nc, err := nats.Connect(natsURL)
	if err != nil {
		log.Fatalf("❌ Failed to connect to NATS: %v", err)
	}
	defer nc.Close()

	// Create JetStream context
	js, err := jetstream.New(nc)
	if err != nil {
		log.Fatalf("❌ Failed to create JetStream context: %v", err)
	}

	// Ensure stream exists
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	_, err = js.CreateOrUpdateStream(ctx, jetstream.StreamConfig{
		Name:     streamName,
		Subjects: []string{inventorySubj},
	})
	if err != nil {
		log.Fatalf("❌ Failed to create stream: %v", err)
	}

	log.Printf("✅ Stream '%s' is ready\n", streamName)

	// Subscribe to order.created events
	sub, err := js.Subscribe(orderCreatedSubj, func(msg *nats.Msg) {
		log.Printf("📥 Received order.created event: %s\n", string(msg.Data))

		// Simulate inventory reservation
		reservedEvent := fmt.Sprintf("Inventory reserved for %s", string(msg.Data))
		_, err := js.Publish(ctx, inventorySubj, []byte(reservedEvent))
		if err != nil {
			log.Printf("❌ Failed to publish inventory.reserved: %v", err)
			return
		}

		log.Printf("✅ Published inventory.reserved event: %s\n", reservedEvent)
		msg.Ack()
	}, jetstream.Durable("inventory-service"), jetstream.ManualAck())
	if err != nil {
		log.Fatalf("❌ Failed to subscribe to %s: %v", orderCreatedSubj, err)
	}
	defer sub.Unsubscribe()

	// Add REST API endpoint for health check
	http.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("Inventory Service is healthy"))
	})

	go func() {
		if err := http.ListenAndServe(":8081", nil); err != nil {
			log.Fatalf("❌ Failed to start HTTP server: %v", err)
		}
	}()

	// Graceful shutdown handling
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
	<-stop
	log.Println("🚦 Shutting down Inventory Service...")
}
