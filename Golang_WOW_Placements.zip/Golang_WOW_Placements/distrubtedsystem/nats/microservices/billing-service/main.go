package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"

	"github.com/nats-io/nats.go"
	"github.com/nats-io/nats.go/jetstream"
)

const (
	natsURL          = "nats://localhost:4222"
	streamName       = "BILLING"
	inventorySubj    = "inventory.reserved"
	billingCompleted = "billing.completed"
)

func main() {
	log.Println("🚀 Starting Billing Service...")

	// Connect to NATS
	nc, err := nats.Connect(natsURL)
	if err != nil {
		log.Fatalf("❌ Failed to connect to NATS: %v", err)
	}
	defer nc.Close()

	// Create JetStream context
	js, err := jetstream.New(nc)
	if err != nil {
		log.Fatalf("❌ Failed to create JetStream context: %v", err)
	}

	// Add REST API endpoint for health check
	http.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("Billing Service is healthy"))
	})

	go func() {
		if err := http.ListenAndServe(":8082", nil); err != nil {
			log.Fatalf("❌ Failed to start HTTP server: %v", err)
		}
	}()

	// Ensure 'BILLING' stream exists
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	_, err = js.CreateOrUpdateStream(ctx, jetstream.StreamConfig{
		Name:     streamName,
		Subjects: []string{billingCompleted},
	})
	if err != nil {
		log.Fatalf("❌ Failed to create stream: %v", err)
	}

	// Subscribe to 'inventory.reserved' and process events
	sub, err := js.Subscribe(inventorySubj, func(msg *nats.Msg) {
		log.Printf("📥 Received message on '%s': %s", msg.Subject, string(msg.Data))

		// Simulate processing
		time.Sleep(2 * time.Second)

		// Publish 'billing.completed' event
		response := nats.NewMsg(billingCompleted)
		response.Header.Set("event_id", fmt.Sprintf("billing-%d", time.Now().UnixNano()))
		response.Data = []byte("{\"billing_id\": \"98765\", \"status\": \"completed\"}")

		if _, err := js.PublishMsg(response); err != nil {
			log.Printf("❌ Failed to publish message: %v", err)
		} else {
			log.Println("✅ Published 'billing.completed' event")
		}

		msg.Ack()
	}, nats.ManualAck())
	if err != nil {
		log.Fatalf("❌ Failed to subscribe: %v", err)
	}
	defer sub.Unsubscribe()

	// Graceful shutdown handling
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
	<-stop
	log.Println("🚦 Shutting down Billing Service...")
}

log.Println("✅ Billing Service shut down gracefully")