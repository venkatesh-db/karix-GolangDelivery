
/*


export KAFKA_BROKERS="localhost:9092"
go run highthroughoutput.go -mode=producer

export KAFKA_BROKERS="localhost:9092"
go run highthroughoutput.go -mode=consumer


*/




package main

import (
	"context"
	"flag"
	"log"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"sync/atomic"
	"syscall"
	"time"

	"github.com/segmentio/kafka-go"
)

//
// ========================== CONFIG ==========================
//

type Config struct {
	Brokers     []string
	Topic       string
	MsgCount    int
	BatchSize   int
	PayloadSize int
	Mode        string
}

func loadConfig() Config {
	cfg := Config{}

	brokerEnv := os.Getenv("KAFKA_BROKERS")
	if brokerEnv == "" {
		brokerEnv = "localhost:9092"
	}

	flag.StringVar(&cfg.Topic, "topic", getEnv("KAFKA_TOPIC", "bench_highspeed"), "Kafka topic")
	flag.StringVar(&cfg.Mode, "mode", getEnv("MODE", ""), "producer or consumer")
	flag.IntVar(&cfg.MsgCount, "msg-count", getEnvInt("MSG_COUNT", 1_000_000), "number of messages")
	flag.IntVar(&cfg.BatchSize, "batch", getEnvInt("BATCH_SIZE", 1000), "producer batch size")
	flag.IntVar(&cfg.PayloadSize, "payload-size", getEnvInt("PAYLOAD_SIZE", 3500), "payload size in bytes")
	flag.Parse()

	cfg.Brokers = strings.Split(brokerEnv, ",")

	if cfg.Mode == "" {
		log.Fatal("MODE is required: producer or consumer")
	}

	return cfg
}

//
// ============================ MAIN ===========================
//

func main() {
	cfg := loadConfig()

	ctx, cancel := context.WithCancel(context.Background())

	// CTRL+C graceful shutdown
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		<-sig
		log.Println("Shutting down…")
		cancel()
	}()

	switch cfg.Mode {
	case "producer":
		runProducer(ctx, cfg)
	case "consumer":
		runConsumer(ctx, cfg)
	default:
		log.Fatalf("Unknown MODE: %s", cfg.Mode)
	}
}

//
// ========================= PRODUCER ==========================
//

func runProducer(ctx context.Context, cfg Config) {
	log.Printf("Starting OPTIMIZED Producer (payload=%d bytes)", cfg.PayloadSize)

	writer := kafka.NewWriter(kafka.WriterConfig{
		Brokers:      cfg.Brokers,
		Topic:        cfg.Topic,
		BatchSize:    cfg.BatchSize,
		BatchTimeout: 5 * time.Millisecond,
		Async:        true,
		Balancer:     &kafka.Murmur2Balancer{},
	})
	defer writer.Close()

	// Preallocate a heavy payload (3.5 KB default)
	payload := make([]byte, cfg.PayloadSize)
	// Optional: fill with some pattern (skipped to avoid extra CPU)

	sent := 0
	start := time.Now()

	for sent < cfg.MsgCount {
		if ctx.Err() != nil {
			break
		}

		n := cfg.BatchSize
		remaining := cfg.MsgCount - sent
		if remaining < n {
			n = remaining
		}

		batch := make([]kafka.Message, n)
		for i := 0; i < n; i++ {
			batch[i] = kafka.Message{Value: payload}
		}

		if err := writer.WriteMessages(ctx, batch...); err != nil {
			log.Printf("Producer error: %v", err)
			break
		}

		sent += n
	}

	duration := time.Since(start)
	if duration <= 0 {
		duration = time.Millisecond
	}
	msgPerSec := float64(sent) / duration.Seconds()
	mbPerSec := (float64(sent*cfg.PayloadSize) / (1024 * 1024)) / duration.Seconds()

	log.Printf("Produced %d messages in %v (%.2f msg/s, %.2f MB/s)",
		sent, duration, msgPerSec, mbPerSec)
}

//
// ========================== CONSUMER ==========================
//

func runConsumer(ctx context.Context, cfg Config) {
	log.Println("Starting FINAL Partition Consumer (Always Reads All Messages)")

	// Fetch partitions
	conn, err := kafka.Dial("tcp", cfg.Brokers[0])
	if err != nil {
		log.Fatalf("Failed to connect to Kafka: %v", err)
	}
	partitions, err := conn.ReadPartitions(cfg.Topic)
	_ = conn.Close()
	if err != nil {
		log.Fatalf("Failed to read partitions: %v", err)
	}

	var consumed int64
	start := time.Now()
	done := make(chan struct{})

	for _, p := range partitions {
		partitionID := p.ID

		go func(part int) {
			reader := kafka.NewReader(kafka.ReaderConfig{
				Brokers:     cfg.Brokers,
				Topic:       cfg.Topic,
				Partition:   part,
				StartOffset: kafka.FirstOffset,
				MinBytes:    1,
				MaxBytes:    10e6,
			})
			defer reader.Close()

			for {
				if ctx.Err() != nil {
					close(done)
					return
				}

				_, err := reader.ReadMessage(ctx)
				if err != nil {
					close(done)
					return
				}

				if atomic.AddInt64(&consumed, 1) >= int64(cfg.MsgCount) {
					close(done)
					return
				}
			}
		}(partitionID)
	}

	<-done

	duration := time.Since(start)
	if duration <= 0 {
		duration = time.Millisecond
	}
	msgPerSec := float64(consumed) / duration.Seconds()
	mbPerSec := (float64(consumed*int64(cfg.PayloadSize)) / (1024 * 1024)) / duration.Seconds()

	log.Printf("Consumed %d messages in %v (%.2f msg/s, %.2f MB/s)",
		consumed, duration, msgPerSec, mbPerSec)
}

//
// ============================ UTILS ==========================
//

func getEnv(key, def string) string {
	v := os.Getenv(key)
	if v == "" {
		return def
	}
	return v
}

func getEnvInt(key string, def int) int {
	v := os.Getenv(key)
	if v == "" {
		return def
	}
	x, err := strconv.Atoi(v)
	if err != nil {
		return def
	}
	return x
}
