package cmd

import (
	"fmt"
	"os"

	"github.com/spf13/cobra"
)

var (
	environment  string
	outputFormat string
)

var rootCmd = &cobra.Command{
	Use:   "teleop",
	Short: "Operator-grade telecom CLI",
	Long:  "teleop bundles operator workflows for planning, subscriber care, and network ops in a single CLI.",
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println("Telecom operator CLI – run with --help to see available workflows.")
	},
}

// Execute wires cobra root command to main.go.
func Execute() {
	if err := rootCmd.Execute(); err != nil {
		os.Exit(1)
	}
}

func init() {
	rootCmd.PersistentFlags().StringVar(&environment, "environment", "lab", "Named environment such as lab, staging, or production")
	rootCmd.PersistentFlags().StringVarP(&outputFormat, "output", "o", "table", "Output style: table|json")
}
