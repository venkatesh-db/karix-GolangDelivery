package cmd

import (
	"encoding/json"
	"fmt"
	"math"
	"strings"

	"github.com/AlecAivazis/survey/v2"
	"github.com/spf13/cobra"

	"telecomcli/internal/telecom"
)

type planAnswers struct {
	Segment        string
	DataUsage      float64
	VoiceMinutes   int
	International  bool
	RoamingRegions []string
	Priority       string
	DeviceType     string
}

var (
	planNoPrompt          bool
	planSegmentFlag       string
	planDataFlag          float64
	planVoiceFlag         int
	planInternationalFlag bool
	planRoamingFlag       []string
	planPriorityFlag      string
	planDeviceFlag        string
)

var planRecommendCmd = &cobra.Command{
	Use:   "plan",
	Short: "Interactively recommend commercial plans",
	Long:  "Collect subscriber intent and usage forecasts to rank-fit mobility plans and add-ons.",
	RunE: func(cmd *cobra.Command, args []string) error {
		answers, err := collectPlanAnswers()
		if err != nil {
			return err
		}

		profile := telecom.PlanProfile{
			Segment:       answers.Segment,
			DataUsageGB:   answers.DataUsage,
			VoiceMinutes:  answers.VoiceMinutes,
			International: answers.International,
			RoamingZones:  answers.RoamingRegions,
			Priority:      answers.Priority,
			DeviceType:    answers.DeviceType,
		}

		recommendations := telecom.RecommendPlans(profile)

		if outputFormat == "json" {
			payload, err := json.MarshalIndent(recommendations, "", "  ")
			if err != nil {
				return err
			}
			fmt.Println(string(payload))
			return nil
		}

		fmt.Printf("\nTop %d plan matches for %s segment (%s env)\n", int(math.Min(3, float64(len(recommendations)))), profile.Segment, environment)
		fmt.Println("--------------------------------------------------------------------------")
		fmt.Printf("%-20s %-10s %-10s %-8s %-6s\n", "Plan", "Data(GB)", "Voice", "Score", "Price")
		fmt.Println("--------------------------------------------------------------------------")
		for i, rec := range recommendations {
			if i >= 5 {
				break
			}
			fmt.Printf("%-20s %-10d %-10d %-8.2f $%-6.2f\n", rec.Plan.Name, rec.Plan.DataCapGB, rec.Plan.VoiceMinutes, rec.Score, rec.Plan.Price)
			if len(rec.Notes) > 0 {
				fmt.Printf("   Notes: %s\n", rec.Notes)
			}
		}

		return nil
	},
}

func init() {
	rootCmd.AddCommand(planRecommendCmd)

	planRecommendCmd.Flags().BoolVar(&planNoPrompt, "no-prompt", false, "Use flag values instead of interactive prompts")
	planRecommendCmd.Flags().StringVar(&planSegmentFlag, "segment", "consumer", "Subscriber segment (consumer|prosumer|enterprise)")
	planRecommendCmd.Flags().Float64Var(&planDataFlag, "data", 50, "Projected monthly data usage in GB")
	planRecommendCmd.Flags().IntVar(&planVoiceFlag, "voice", 500, "Voice minutes per month")
	planRecommendCmd.Flags().BoolVar(&planInternationalFlag, "international", false, "Requires international calling")
	planRecommendCmd.Flags().StringSliceVar(&planRoamingFlag, "roaming", nil, "Roaming regions such as NA,EU,APAC (repeat flag)")
	planRecommendCmd.Flags().StringVar(&planPriorityFlag, "priority", "balanced", "Priority weighting (lowest-cost|balanced|premium)")
	planRecommendCmd.Flags().StringVar(&planDeviceFlag, "device", "smartphone", "Primary device (smartphone|tablet|iot)")
}

var (
	planSegmentOptions  = []string{"consumer", "prosumer", "enterprise"}
	planPriorityOptions = []string{"lowest-cost", "balanced", "premium"}
	planDeviceOptions   = []string{"smartphone", "tablet", "iot"}
	planRoamingOptions  = []string{"NA", "EU", "APAC", "LATAM", "MEA"}
)

func collectPlanAnswers() (planAnswers, error) {
	if planNoPrompt {
		copyRoaming := append([]string(nil), planRoamingFlag...)
		answers := planAnswers{
			Segment:        planSegmentFlag,
			DataUsage:      planDataFlag,
			VoiceMinutes:   planVoiceFlag,
			International:  planInternationalFlag,
			RoamingRegions: copyRoaming,
			Priority:       planPriorityFlag,
			DeviceType:     planDeviceFlag,
		}
		return answers, answers.validate()
	}

	answers := planAnswers{}
	questions := []*survey.Question{
		{
			Name:   "segment",
			Prompt: &survey.Select{Message: "Subscriber segment", Options: planSegmentOptions, Default: planSegmentOptions[0]},
		},
		{
			Name:   "dataUsage",
			Prompt: &survey.Input{Message: "Projected monthly data (GB)", Default: fmt.Sprintf("%g", planDataFlag)},
			Validate: survey.ComposeValidators(survey.Required, func(ans interface{}) error {
				var value float64
				_, err := fmt.Sscan(ans.(string), &value)
				if err != nil || value <= 0 {
					return fmt.Errorf("enter a positive number")
				}
				return nil
			}),
		},
		{
			Name:   "voiceMinutes",
			Prompt: &survey.Input{Message: "Voice minutes per month", Default: fmt.Sprintf("%d", planVoiceFlag)},
			Validate: survey.ComposeValidators(survey.Required, func(ans interface{}) error {
				var value int
				_, err := fmt.Sscan(ans.(string), &value)
				if err != nil || value < 0 {
					return fmt.Errorf("enter a non-negative integer")
				}
				return nil
			}),
		},
		{
			Name:   "international",
			Prompt: &survey.Confirm{Message: "Needs international calling?", Default: planInternationalFlag},
		},
		{
			Name:   "roaming",
			Prompt: &survey.MultiSelect{Message: "Top roaming regions", Options: planRoamingOptions},
		},
		{
			Name:   "priority",
			Prompt: &survey.Select{Message: "Primary priority", Options: planPriorityOptions, Default: planPriorityOptions[1]},
		},
		{
			Name:   "device",
			Prompt: &survey.Select{Message: "Primary device class", Options: planDeviceOptions, Default: planDeviceOptions[0]},
		},
	}

	if err := survey.Ask(questions, &answers); err != nil {
		return planAnswers{}, err
	}
	return answers, answers.validate()
}

func (a planAnswers) validate() error {
	if !containsString(planSegmentOptions, a.Segment) {
		return fmt.Errorf("segment must be one of %s", strings.Join(planSegmentOptions, ", "))
	}
	if a.DataUsage <= 0 {
		return fmt.Errorf("data usage must be greater than zero")
	}
	if a.VoiceMinutes < 0 {
		return fmt.Errorf("voice minutes cannot be negative")
	}
	if !containsString(planPriorityOptions, a.Priority) {
		return fmt.Errorf("priority must be one of %s", strings.Join(planPriorityOptions, ", "))
	}
	if !containsString(planDeviceOptions, a.DeviceType) {
		return fmt.Errorf("device must be one of %s", strings.Join(planDeviceOptions, ", "))
	}
	for _, zone := range a.RoamingRegions {
		if zone == "" {
			continue
		}
		if !containsString(planRoamingOptions, zone) {
			return fmt.Errorf("roaming region %q is invalid; expected values: %s", zone, strings.Join(planRoamingOptions, ", "))
		}
	}
	return nil
}

func containsString(list []string, target string) bool {
	for _, item := range list {
		if item == target {
			return true
		}
	}
	return false
}
