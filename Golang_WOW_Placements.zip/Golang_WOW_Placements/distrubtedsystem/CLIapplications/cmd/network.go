package cmd

import (
	"encoding/json"
	"fmt"

	"github.com/AlecAivazis/survey/v2"
	"github.com/spf13/cobra"

	"telecomcli/internal/telecom"
)

var networkSnapshotCmd = &cobra.Command{
	Use:   "network",
	Short: "Inspect network readiness KPIs",
	Long:  "Surfaced KPIs cover RAN utilization, spectrum pressure, NOC alarms, and customer experience probes.",
	RunE: func(cmd *cobra.Command, args []string) error {
		region, _ := cmd.Flags().GetString("region")
		layer, _ := cmd.Flags().GetString("layer")
		interactive, _ := cmd.Flags().GetBool("interactive")

		if interactive || region == "" {
			selector := struct {
				Region string `survey:"region"`
				Layer  string `survey:"layer"`
			}{}

			questions := []*survey.Question{
				{
					Name:   "region",
					Prompt: &survey.Select{Message: "Region", Options: []string{"metro-east", "metro-west", "north-cluster", "south-cluster"}, Default: "metro-east"},
				},
				{
					Name:   "layer",
					Prompt: &survey.Select{Message: "Layer", Options: []string{"5g", "lte", "enterprise-fixed"}, Default: "5g"},
				},
			}

			if err := survey.Ask(questions, &selector); err != nil {
				return err
			}
			region = selector.Region
			layer = selector.Layer
		}

		snapshot := telecom.NetworkSnapshot(region, layer)

		if outputFormat == "json" {
			payload, err := json.MarshalIndent(snapshot, "", "  ")
			if err != nil {
				return err
			}
			fmt.Println(string(payload))
			return nil
		}

		fmt.Printf("Network KPIs for %s/%s (%s env)\n", region, layer, environment)
		fmt.Println("--------------------------------------------------------------")
		fmt.Printf("Utilization: %.1f%%\n", snapshot.Utilization*100)
		fmt.Printf("Spectrum Pressure: %.1f%%\n", snapshot.SpectrumPressure*100)
		fmt.Printf("Customer NPS: %.1f\n", snapshot.CustomerNPS)
		fmt.Printf("Mean Throughput: %.1f Mbps\n", snapshot.ThroughputMbps)
		fmt.Printf("Fiber Backhaul Load: %.1f%%\n", snapshot.BackhaulLoad*100)
		fmt.Println("Top Risks:")
		for _, risk := range snapshot.Risks {
			fmt.Printf("  - %s\n", risk)
		}
		fmt.Println("Automations queued:")
		for _, play := range snapshot.Playbooks {
			fmt.Printf("  - %s\n", play)
		}
		return nil
	},
}

func init() {
	networkSnapshotCmd.Flags().String("region", "", "Region identifier, e.g. metro-west")
	networkSnapshotCmd.Flags().String("layer", "5g", "Network layer: 5g|lte|enterprise-fixed")
	networkSnapshotCmd.Flags().Bool("interactive", false, "Use prompts to pick region/layer")
	rootCmd.AddCommand(networkSnapshotCmd)
}
