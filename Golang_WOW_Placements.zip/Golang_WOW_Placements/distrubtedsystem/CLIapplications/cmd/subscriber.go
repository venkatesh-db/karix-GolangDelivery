package cmd

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/AlecAivazis/survey/v2"
	"github.com/spf13/cobra"

	"telecomcli/internal/telecom"
)

type subscriberAnswers struct {
	FullName     string
	IDType       string
	Segment      string
	Devices      []string
	NeedsESIM    bool
	ContractTerm int
	Payment      string
	UseCase      string
}

var (
	subscriberNoPrompt  bool
	subscriberFullName  string
	subscriberIDType    string
	subscriberSegment   string
	subscriberDevices   []string
	subscriberNeedsESIM bool
	subscriberContract  int
	subscriberPayment   string
	subscriberUseCase   string
)

var subscriberOnboardCmd = &cobra.Command{
	Use:   "subscriber",
	Short: "Interactive subscriber onboarding workflow",
	Long:  "Captures KYC, fulfillment, and network activation tasks for new lines or migrations.",
	RunE: func(cmd *cobra.Command, args []string) error {
		answers, err := collectSubscriberAnswers()
		if err != nil {
			return err
		}
		profile := telecom.SubscriberProfile{
			FullName:       answers.FullName,
			IDType:         answers.IDType,
			Segment:        answers.Segment,
			Devices:        answers.Devices,
			NeedsESIM:      answers.NeedsESIM,
			ContractMonths: answers.ContractTerm,
			PaymentMethod:  answers.Payment,
			PrimaryUseCase: answers.UseCase,
		}

		plan := telecom.GenerateOnboardingPlan(profile)

		if outputFormat == "json" {
			blob, err := json.MarshalIndent(plan, "", "  ")
			if err != nil {
				return err
			}
			fmt.Println(string(blob))
			return nil
		}

		fmt.Printf("\nOnboarding playbook for %s (%s env)\n", profile.FullName, environment)
		fmt.Println("Checklist:")
		for i, step := range plan.Checklist {
			fmt.Printf("  %d. %s\n", i+1, step)
		}
		if len(plan.Integrations) > 0 {
			fmt.Println("Integrations:")
			for _, sys := range plan.Integrations {
				fmt.Printf("  - %s\n", sys)
			}
		}
		fmt.Println("Activation Window:", plan.ActivationWindow)
		fmt.Println("Fallback Plans:")
		for _, fallback := range plan.FallbackOptions {
			fmt.Printf("  - %s\n", fallback)
		}
		return nil
	},
}

func init() {
	rootCmd.AddCommand(subscriberOnboardCmd)

	subscriberOnboardCmd.Flags().BoolVar(&subscriberNoPrompt, "no-prompt", false, "Use flag values instead of interactive prompts")
	subscriberOnboardCmd.Flags().StringVar(&subscriberFullName, "full-name", "", "Subscriber legal name (required when --no-prompt)")
	subscriberOnboardCmd.Flags().StringVar(&subscriberIDType, "id-type", "passport", "Primary ID type (passport|national-id|driver-license|tax-id)")
	subscriberOnboardCmd.Flags().StringVar(&subscriberSegment, "segment", "consumer", "Account segment (consumer|family|smb|enterprise)")
	subscriberOnboardCmd.Flags().StringSliceVar(&subscriberDevices, "device", []string{"handset"}, "Device to activate (repeat flag)")
	subscriberOnboardCmd.Flags().BoolVar(&subscriberNeedsESIM, "esim", true, "Provision eSIM profile")
	subscriberOnboardCmd.Flags().IntVar(&subscriberContract, "contract", 24, "Contract term in months")
	subscriberOnboardCmd.Flags().StringVar(&subscriberPayment, "payment", "credit-card", "Payment instrument (credit-card|ach|wallet|invoice)")
	subscriberOnboardCmd.Flags().StringVar(&subscriberUseCase, "use-case", "personal", "Primary use case (personal|hybrid-work|fleet|fixed-wireless)")
}

var (
	subscriberIDOptions      = []string{"passport", "national-id", "driver-license", "tax-id"}
	subscriberSegmentOptions = []string{"consumer", "family", "smb", "enterprise"}
	subscriberDeviceOptions  = []string{"handset", "tablet", "iot-sensor", "router"}
	subscriberPaymentOptions = []string{"credit-card", "ach", "wallet", "invoice"}
	subscriberUseCaseOptions = []string{"personal", "hybrid-work", "fleet", "fixed-wireless"}
)

func collectSubscriberAnswers() (subscriberAnswers, error) {
	if subscriberNoPrompt {
		answers := subscriberAnswers{
			FullName:     subscriberFullName,
			IDType:       subscriberIDType,
			Segment:      subscriberSegment,
			Devices:      append([]string{}, subscriberDevices...),
			NeedsESIM:    subscriberNeedsESIM,
			ContractTerm: subscriberContract,
			Payment:      subscriberPayment,
			UseCase:      subscriberUseCase,
		}
		return answers, answers.validate()
	}

	answers := subscriberAnswers{}
	questions := []*survey.Question{
		{
			Name:   "fullName",
			Prompt: &survey.Input{Message: "Subscriber legal name"},
			Validate: survey.ComposeValidators(survey.Required, func(ans interface{}) error {
				if len(strings.Fields(ans.(string))) < 2 {
					return fmt.Errorf("enter first and last name")
				}
				return nil
			}),
		},
		{
			Name:   "idType",
			Prompt: &survey.Select{Message: "Primary ID type", Options: subscriberIDOptions, Default: subscriberIDOptions[0]},
		},
		{
			Name:   "segment",
			Prompt: &survey.Select{Message: "Account segment", Options: subscriberSegmentOptions, Default: subscriberSegmentOptions[0]},
		},
		{
			Name:   "devices",
			Prompt: &survey.MultiSelect{Message: "Devices to activate", Options: subscriberDeviceOptions, Default: []string{subscriberDeviceOptions[0]}},
		},
		{
			Name:   "esim",
			Prompt: &survey.Confirm{Message: "eSIM profile required?", Default: true},
		},
		{
			Name:   "contract",
			Prompt: &survey.Input{Message: "Contract term (months)", Default: fmt.Sprintf("%d", subscriberContract)},
			Validate: survey.ComposeValidators(survey.Required, func(ans interface{}) error {
				var months int
				_, err := fmt.Sscan(ans.(string), &months)
				if err != nil || months <= 0 {
					return fmt.Errorf("enter positive months")
				}
				return nil
			}),
		},
		{
			Name:   "payment",
			Prompt: &survey.Select{Message: "Payment instrument", Options: subscriberPaymentOptions, Default: subscriberPaymentOptions[0]},
		},
		{
			Name:   "useCase",
			Prompt: &survey.Select{Message: "Primary use case", Options: subscriberUseCaseOptions, Default: subscriberUseCaseOptions[0]},
		},
	}

	if err := survey.Ask(questions, &answers); err != nil {
		return subscriberAnswers{}, err
	}
	return answers, answers.validate()
}

func (a subscriberAnswers) validate() error {
	if len(strings.Fields(a.FullName)) < 2 {
		return fmt.Errorf("full name must include first and last name")
	}
	if !containsString(subscriberIDOptions, a.IDType) {
		return fmt.Errorf("id-type must be one of %s", strings.Join(subscriberIDOptions, ", "))
	}
	if !containsString(subscriberSegmentOptions, a.Segment) {
		return fmt.Errorf("segment must be one of %s", strings.Join(subscriberSegmentOptions, ", "))
	}
	if a.ContractTerm <= 0 {
		return fmt.Errorf("contract term must be positive")
	}
	if len(a.Devices) == 0 {
		return fmt.Errorf("specify at least one device")
	}
	for _, device := range a.Devices {
		if !containsString(subscriberDeviceOptions, device) {
			return fmt.Errorf("device %q must be one of %s", device, strings.Join(subscriberDeviceOptions, ", "))
		}
	}
	if !containsString(subscriberPaymentOptions, a.Payment) {
		return fmt.Errorf("payment must be one of %s", strings.Join(subscriberPaymentOptions, ", "))
	}
	if !containsString(subscriberUseCaseOptions, a.UseCase) {
		return fmt.Errorf("use-case must be one of %s", strings.Join(subscriberUseCaseOptions, ", "))
	}
	return nil
}
