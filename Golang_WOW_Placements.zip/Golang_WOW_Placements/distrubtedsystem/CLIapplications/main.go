package main

import "telecomcli/cmd"

func main() {
	cmd.Execute()
}
