# teleop – Telecom Operator CLI

`teleop` is a sample Go CLI tailored for telco operator workflows. It uses [Cobra](https://github.com/spf13/cobra) for command routing and [survey](https://github.com/AlecAivazis/survey) for rich terminal prompts.

## Features
- **Plan intelligence** – capture demand signals and surface best-fit plan SKUs with scored recommendations.
- **Subscriber onboarding** – run an interactive checklist for KYC, provisioning, and integration handoffs.
- **Network KPIs** – inspect synthesized OSS/NOC snapshots by region and technology layer.
- **Dual output** – switch between table and JSON layouts via `-o json`.

## Getting Started
```bash
# from the project root
$ go run . --help
```

### Recommend a plan
```bash
$ go run . plan
```
Follow the prompts for segment, usage, and roaming needs. Output defaults to a ranked table; add `-o json` for machine-readable results.

Headless pipelines can skip prompts:
```bash
$ go run . plan --no-prompt \
	--segment consumer --data 80 --voice 600 \
	--international --roaming NA --priority balanced --device smartphone
```

### Onboard a subscriber
```bash
$ go run . subscriber -o json
```
Collects KYC, devices, fulfillment needs, and prints a prescriptive checklist.

Non-interactive alternative:
```bash
$ go run . subscriber --no-prompt \
	--full-name "Asha Rao" --id-type passport --segment smb \
	--device handset --device router --esim --contract 36 \
	--payment invoice --use-case hybrid-work -o json
```

### Inspect network KPIs
```bash
$ go run . network --interactive
```
Pick a region/layer interactively, or pass `--region metro-west --layer 5g` to skip prompts.

## Building
```bash
$ go build -o teleop
$ ./teleop subscriber
```

## Project Layout
```
cmd/            Cobra commands (root, plan, subscriber, network)
internal/telecom domain logic for plans, onboarding, and network data
```

## Extending
- Add new commands under `cmd/` and wire them in `init()` like the existing ones.
- Extend catalog data or ingestion logic inside `internal/telecom` and keep the CLI thin.
- Replace the static data models with real APIs, OSS feeds, or BSS integrations when available.
