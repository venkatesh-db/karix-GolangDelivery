package telecom

// Snapshot captures a subset of OSS/NOC telemetry for a region/layer pair.
type Snapshot struct {
	Region           string   `json:"region"`
	Layer            string   `json:"layer"`
	Utilization      float64  `json:"utilization"`
	SpectrumPressure float64  `json:"spectrumPressure"`
	ThroughputMbps   float64  `json:"throughputMbps"`
	BackhaulLoad     float64  `json:"backhaulLoad"`
	CustomerNPS      float64  `json:"customerNps"`
	Risks            []string `json:"risks"`
	Playbooks        []string `json:"playbooks"`
}

var kpiMatrix = map[string]map[string]Snapshot{
	"metro-east": {
		"5g": {
			Region:           "metro-east",
			Layer:            "5g",
			Utilization:      0.71,
			SpectrumPressure: 0.63,
			ThroughputMbps:   780,
			BackhaulLoad:     0.54,
			CustomerNPS:      52,
			Risks:            []string{"Backhaul jitter spike", "OSS ticket aging > 12h"},
			Playbooks:        []string{"Scale DU slice", "Rebalance mmWave carriers"},
		},
		"lte": {
			Region:           "metro-east",
			Layer:            "lte",
			Utilization:      0.82,
			SpectrumPressure: 0.74,
			ThroughputMbps:   110,
			BackhaulLoad:     0.68,
			CustomerNPS:      47,
			Risks:            []string{"Legacy EPC congestion", "VoLTE drop rates elevated"},
			Playbooks:        []string{"Trigger SON optimization", "Enable carrier aggregation policy"},
		},
	},
	"metro-west": {
		"5g": {
			Region:           "metro-west",
			Layer:            "5g",
			Utilization:      0.64,
			SpectrumPressure: 0.58,
			ThroughputMbps:   690,
			BackhaulLoad:     0.49,
			CustomerNPS:      66,
			Risks:            []string{"Small cell power alarms"},
			Playbooks:        []string{"Dispatch field engineer", "Recalibrate massive MIMO weights"},
		},
	},
	"north-cluster": {
		"enterprise-fixed": {
			Region:           "north-cluster",
			Layer:            "enterprise-fixed",
			Utilization:      0.57,
			SpectrumPressure: 0.21,
			ThroughputMbps:   940,
			BackhaulLoad:     0.39,
			CustomerNPS:      71,
			Risks:            []string{"Fiber cut probability high"},
			Playbooks:        []string{"Pre-stage splicing crew", "Issue proactive credits"},
		},
	},
	"south-cluster": {
		"lte": {
			Region:           "south-cluster",
			Layer:            "lte",
			Utilization:      0.49,
			SpectrumPressure: 0.33,
			ThroughputMbps:   125,
			BackhaulLoad:     0.42,
			CustomerNPS:      58,
			Risks:            []string{"Weather-related micro-cuts"},
			Playbooks:        []string{"Enable storm hardening profile"},
		},
	},
}

// NetworkSnapshot fetches KPIs for the provided region/layer, defaulting to metro-east/5g.
func NetworkSnapshot(region, layer string) Snapshot {
	if regionKPIs, ok := kpiMatrix[region]; ok {
		if snapshot, ok := regionKPIs[layer]; ok {
			return snapshot
		}
	}
	return kpiMatrix["metro-east"]["5g"]
}
