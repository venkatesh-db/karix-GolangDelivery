package telecom

import (
	"fmt"
	"strings"
)

// SubscriberProfile holds onboarding context captured via CLI prompts.
type SubscriberProfile struct {
	FullName       string
	IDType         string
	Segment        string
	Devices        []string
	NeedsESIM      bool
	ContractMonths int
	PaymentMethod  string
	PrimaryUseCase string
}

// OnboardingPlan summarizes fulfillment and activation steps.
type OnboardingPlan struct {
	Profile          SubscriberProfile
	RecommendedPlan  Plan
	Checklist        []string
	Integrations     []string
	ActivationWindow string
	FallbackOptions  []string
}

// GenerateOnboardingPlan builds a prescriptive plan from answers.
func GenerateOnboardingPlan(profile SubscriberProfile) OnboardingPlan {
	planProfile := PlanProfile{
		Segment:       normalizeSegment(profile.Segment),
		DataUsageGB:   usageFromUseCase(profile.PrimaryUseCase),
		VoiceMinutes:  voiceFromUseCase(profile.PrimaryUseCase),
		International: profile.PrimaryUseCase == "hybrid-work",
		Priority:      priorityFromSegment(profile.Segment),
		DeviceType:    inferDevice(profile.Devices),
	}

	recs := RecommendPlans(planProfile)
	selected := Plan{}
	if len(recs) > 0 {
		selected = recs[0].Plan
	}

	checklist := []string{
		fmt.Sprintf("KYC validation using %s for %s", strings.ToUpper(profile.IDType), profile.FullName),
		"Create CRM lead and link to billing account",
		fmt.Sprintf("Generate %d-month service agreement", profile.ContractMonths),
		"Trigger credit profile soft check",
		"Issue SIM/eSIM and associate with inventory lot",
		"Push provisioning tasks to HLR/HSS/UDM",
	}

	if profile.NeedsESIM {
		checklist = append(checklist, "Deliver QR activation email and monitor download telemetry")
	}
	if contains(profile.Devices, "iot-sensor") {
		checklist = append(checklist, "Allocate private APN credential for IoT sensor fleet")
	}

	integrations := []string{"Salesforce-CRM", "NetCracker-Billing", "NWF-Activation"}
	if profile.PaymentMethod == "invoice" {
		integrations = append(integrations, "Oracle-Finance")
	}

	fallback := []string{"Downgrade to Everyday Saver", "Escalate to retention desk"}
	if profile.PrimaryUseCase == "fleet" {
		fallback = append(fallback, "Switch to FleetSense IoT shared bundle")
	}

	return OnboardingPlan{
		Profile:          profile,
		RecommendedPlan:  selected,
		Checklist:        checklist,
		Integrations:     integrations,
		ActivationWindow: "Provision within 4 business hours",
		FallbackOptions:  fallback,
	}
}

func normalizeSegment(segment string) string {
	switch segment {
	case "smb":
		return "prosumer"
	case "enterprise":
		return "enterprise"
	default:
		return "consumer"
	}
}

func usageFromUseCase(useCase string) float64 {
	switch useCase {
	case "hybrid-work":
		return 180
	case "fleet":
		return 30
	case "fixed-wireless":
		return 400
	default:
		return 60
	}
}

func voiceFromUseCase(useCase string) int {
	switch useCase {
	case "fleet":
		return 200
	case "hybrid-work":
		return 800
	default:
		return 500
	}
}

func priorityFromSegment(segment string) string {
	if segment == "enterprise" || segment == "smb" {
		return "premium"
	}
	return "balanced"
}

func inferDevice(devices []string) string {
	for _, d := range devices {
		if strings.Contains(d, "iot") {
			return "iot"
		}
	}
	return "smartphone"
}
