package telecom

import (
	"math"
	"sort"
	"strconv"
	"strings"
)

// Plan describes a commercial product the operator can offer.
type Plan struct {
	Name         string
	Segment      string
	DataCapGB    int
	VoiceMinutes int
	Price        float64
	AddOns       []string
}

// PlanProfile captures desired behaviors for a recommendation run.
type PlanProfile struct {
	Segment       string
	DataUsageGB   float64
	VoiceMinutes  int
	International bool
	RoamingZones  []string
	Priority      string
	DeviceType    string
}

// PlanRecommendation is the scored output surfaced back to the CLI.
type PlanRecommendation struct {
	Plan  Plan
	Score float64
	Notes []string
}

var planCatalog = []Plan{
	{Name: "Infinity Go 5G", Segment: "consumer", DataCapGB: 60, VoiceMinutes: 800, Price: 65, AddOns: []string{"5g-priority", "hotspot"}},
	{Name: "Edge Pro Unlimited", Segment: "prosumer", DataCapGB: 200, VoiceMinutes: 1200, Price: 95, AddOns: []string{"intl-roaming", "security-pack"}},
	{Name: "FleetSense IoT", Segment: "enterprise", DataCapGB: 30, VoiceMinutes: 200, Price: 18, AddOns: []string{"iot-core", "private-apn"}},
	{Name: "Unified Biz Flex", Segment: "enterprise", DataCapGB: 500, VoiceMinutes: 3000, Price: 140, AddOns: []string{"priority-support", "sd-wan-lite"}},
	{Name: "Everyday Saver", Segment: "consumer", DataCapGB: 25, VoiceMinutes: 600, Price: 45, AddOns: []string{"family-share"}},
	{Name: "Roam Global Max", Segment: "prosumer", DataCapGB: 150, VoiceMinutes: 2000, Price: 120, AddOns: []string{"intl-roaming", "wifi-calling"}},
}

// RecommendPlans produces a sorted list by score.
func RecommendPlans(profile PlanProfile) []PlanRecommendation {
	recommendations := make([]PlanRecommendation, 0, len(planCatalog))

	for _, plan := range planCatalog {
		score := baselineScore(profile, plan)
		notes := make([]string, 0, 4)

		if plan.Segment == profile.Segment {
			score += 20
		} else if profile.Segment == "enterprise" && plan.Segment == "prosumer" {
			score -= 10
		}

		usageRatio := profile.DataUsageGB / float64(plan.DataCapGB)
		if usageRatio <= 0.7 {
			score += 15
		} else if usageRatio > 1.2 {
			score -= 25
			notes = append(notes, "Usage exceeds data cap by "+formatPercent(usageRatio-1))
		}

		voiceRatio := float64(profile.VoiceMinutes) / float64(plan.VoiceMinutes)
		if voiceRatio <= 1 {
			score += 5
		} else {
			score -= 5
		}

		if profile.International && contains(plan.AddOns, "intl-roaming") {
			score += 10
		} else if profile.International {
			notes = append(notes, "Needs international pack")
			score -= 15
		}

		if profile.Priority == "premium" && contains(plan.AddOns, "priority-support") {
			score += 5
		}

		recommendations = append(recommendations, PlanRecommendation{Plan: plan, Score: score, Notes: notes})
	}

	sort.SliceStable(recommendations, func(i, j int) bool {
		return recommendations[i].Score > recommendations[j].Score
	})

	return recommendations
}

func baselineScore(profile PlanProfile, plan Plan) float64 {
	score := 50.0
	if profile.Priority == "lowest-cost" {
		score += math.Max(0, 60-plan.Price)
	} else if profile.Priority == "premium" {
		score += plan.Price / 2
	}

	if profile.DeviceType == "iot" && strings.Contains(strings.Join(plan.AddOns, ","), "iot") {
		score += 8
	}

	return score
}

func contains(slice []string, target string) bool {
	for _, item := range slice {
		if item == target {
			return true
		}
	}
	return false
}

func formatPercent(value float64) string {
	return strconv.FormatFloat(value*100, 'f', 1, 64) + "%"
}
