# Netflix Event Demo

This project demonstrates an event-driven architecture using Go. It consists of multiple services that communicate via NATS for real-time event streaming.

## Services Overview

### 1. Video Service
The Video Service is responsible for publishing events when a video is started. It acts as the entry point for user interactions.

### 2. History Service
The History Service subscribes to video events and maintains a history of user interactions with videos.

### 3. Analytics Service
The Analytics Service processes video events to generate insights and analytics about user behavior and video performance.

### 4. Recommendation Service
The Recommendation Service tracks user behavior and provides personalized video recommendations based on their interaction history.

## How to Run

1. Ensure you have Go installed on your system.
2. Navigate to the root directory of the project.
3. Run each service individually by navigating to its folder and executing:
   ```bash
   go run main.go
   ```

## Dependencies

- [NATS](https://nats.io): A lightweight messaging system for real-time event streaming.

## Project Structure

- `video-service/`: Contains the Video Service.
- `history-service/`: Contains the History Service.
- `analytics-service/`: Contains the Analytics Service.
- `recommendationservice/`: Contains the Recommendation Service.

## License

This project is licensed under the MIT License.