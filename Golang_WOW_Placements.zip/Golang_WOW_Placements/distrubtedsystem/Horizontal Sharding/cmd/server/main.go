package main

import (
	"context"
	"flag"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/example/horizontal-sharding/internal/api"
	"github.com/example/horizontal-sharding/internal/shard"
	"github.com/example/horizontal-sharding/internal/store"
)

func main() {
	cfgPath := flag.String("config", "config/shards.yaml", "path to shard config")
	addr := flag.String("addr", ":8080", "listen address")
	flag.Parse()

	cfg, err := shard.LoadConfig(*cfgPath)
	if err != nil {
		log.Fatalf("load config: %v", err)
	}

	router, err := shard.NewRouter(cfg)
	if err != nil {
		log.Fatalf("init router: %v", err)
	}
	defer router.Close()

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := store.EnsureSchema(ctx, router); err != nil {
		log.Fatalf("ensure schema: %v", err)
	}

	srv := &http.Server{
		Addr:    *addr,
		Handler: api.New(router),
	}

	go func() {
		log.Printf("server listening on %s", *addr)
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("http server: %v", err)
		}
	}()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	<-sigCh
	log.Println("shutting down")

	shutdownCtx, cancelShutdown := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancelShutdown()
	if err := srv.Shutdown(shutdownCtx); err != nil {
		log.Printf("server shutdown error: %v", err)
	}
}
