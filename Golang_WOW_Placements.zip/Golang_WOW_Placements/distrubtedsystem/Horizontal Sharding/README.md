# Horizontal Sharding With SQLite (Go)

This repo demonstrates a lightweight production-style pattern for horizontally sharding data over multiple SQLite primaries with read replicas. The sample exposes a minimal HTTP API that hashes each user ID to a shard, writes to the shard's primary, and serves reads from its replicas once they are caught up.

## Layout

- `cmd/server`: bootstrap binary that loads shard metadata, warms schemas, and runs the HTTP server.
- `internal/shard`: shard config parser plus router that keeps SQLite handles for each primary/replica set.
- `internal/store`: simple DAL that runs schema migrations per shard and exposes helper methods.
- `internal/api`: demo REST surface for creating and fetching users.
- `config/shards.yaml`: declarative shard registry (can be swapped with etcd/Consul in production).

## Running Locally

1. Create empty SQLite files for each primary/replica listed in `config/shards.yaml` or update the DSNs to match your environment. The DSN format `file:/path/to/db` works well for local NVMe or tmpfs.
2. Enable WAL mode replication (Litestream, LiteFS, rqlite, etc.) for every primary so replicas can tail changes. For example, Litestream:
   ```bash
   litestream replicate /tmp/shard0-primary.db s3://prod-shards/shard0
   ```
3. Start the API:
   ```bash
   go run ./cmd/server -config=config/shards.yaml -addr=:8080
   ```
4. Exercise the service:
   ```bash
   curl -X POST http://localhost:8080/users \
     -d '{"id":"user-123","name":"Ada","email":"ada@example.com"}' \
     -H 'Content-Type: application/json'

   curl http://localhost:8080/users/user-123
   ```

## Operational Notes

- The router keeps shard metadata in memory; in production feed it via a control plane (etcd/Consul/Postgres) with watches, and reload gracefully when shards move.
- Each shard is independent: add shards by updating the config, creating new SQLite files, copying schema, and rebalancing keys.
- Health check primaries and replicas separately. Promote replicas by updating the registry so the router immediately directs writes to the new primary.
- `store.EnsureSchema` currently creates tables directly on primaries; in production, wire in migrations via Atlas, Flyway, or goose per shard.
- Wrap this API behind a stateless layer (NGINX, Envoy, or Go reverse proxy) so the hashing logic is shared by worker pools and background jobs.

## Next Steps

- Implement a registry watcher that atomically swaps router state when new shards are introduced.
- Add background verification to ensure replica lag stays under an acceptable SLA before serving read traffic.
- Extend the DAL with cross-shard fan-out queries routed through worker pools or analytics pipelines (never on the request path).
