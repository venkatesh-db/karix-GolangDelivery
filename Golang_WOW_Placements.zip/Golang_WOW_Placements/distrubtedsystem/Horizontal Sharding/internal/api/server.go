package api

import (
	"database/sql"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"strings"

	"github.com/example/horizontal-sharding/internal/shard"
	"github.com/example/horizontal-sharding/internal/store"
)

// Server exposes a minimal HTTP API for demonstration.
type Server struct {
	router *shard.Router
	mux    *http.ServeMux
}

// New creates a Server wired to the provided Router.
func New(r *shard.Router) *Server {
	s := &Server{router: r, mux: http.NewServeMux()}
	s.routes()
	return s
}

func (s *Server) routes() {
	s.mux.HandleFunc("/users", s.handleUsers)
	s.mux.HandleFunc("/users/", s.handleUser)
}

// ServeHTTP satisfies http.Handler.
func (s *Server) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	s.mux.ServeHTTP(w, r)
}

func (s *Server) handleUsers(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var u store.User
	if err := decodeJSON(r.Body, &u); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	if u.ID == "" || u.Name == "" || u.Email == "" {
		http.Error(w, "id, name, and email are required", http.StatusBadRequest)
		return
	}
	if err := store.InsertUser(r.Context(), s.router, u); err != nil {
		status := http.StatusInternalServerError
		if errors.Is(err, store.ErrConflict) {
			status = http.StatusConflict
		}
		http.Error(w, err.Error(), status)
		return
	}
	writeJSON(w, http.StatusCreated, u)
}

func (s *Server) handleUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	id := strings.TrimPrefix(r.URL.Path, "/users/")
	if id == "" {
		http.Error(w, "missing user id", http.StatusBadRequest)
		return
	}
	u, err := store.GetUser(r.Context(), s.router, id)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			http.Error(w, "user not found", http.StatusNotFound)
			return
		}
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	writeJSON(w, http.StatusOK, u)
}

func decodeJSON(body io.ReadCloser, v any) error {
	defer body.Close()
	dec := json.NewDecoder(body)
	return dec.Decode(v)
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
