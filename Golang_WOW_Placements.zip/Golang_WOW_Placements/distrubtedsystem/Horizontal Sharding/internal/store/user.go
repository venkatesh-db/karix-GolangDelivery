package store

import (
	"context"
	"database/sql"
	"errors"

	"github.com/example/horizontal-sharding/internal/shard"
	"modernc.org/sqlite"
	sqlite3 "modernc.org/sqlite/lib"
)

// User represents a row stored per shard.
type User struct {
	ID    string `json:"id"`
	Name  string `json:"name"`
	Email string `json:"email"`
}

const schemaStmt = `
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
`

// EnsureSchema creates the users table on each shard primary.
func EnsureSchema(ctx context.Context, r *shard.Router) error {
	return r.ForEachShard(func(sh *shard.Shard) error {
		_, err := sh.Primary.ExecContext(ctx, schemaStmt)
		return err
	})
}

// InsertUser writes to the owning shard's primary.
func InsertUser(ctx context.Context, r *shard.Router, u User) error {
	_, err := r.Exec(ctx, u.ID, `INSERT INTO users(id, name, email) VALUES(?, ?, ?)`, u.ID, u.Name, u.Email)
	var sqliteErr *sqlite.Error
	if errors.As(err, &sqliteErr) && sqliteErr.Code() == sqlite3.SQLITE_CONSTRAINT {
		return ErrConflict
	}
	return err
}

// GetUser reads from an available replica.
func GetUser(ctx context.Context, r *shard.Router, id string) (User, error) {
	rows, err := r.Query(ctx, id, `SELECT id, name, email FROM users WHERE id = ?`, id)
	if err != nil {
		return User{}, err
	}
	defer rows.Close()
	if rows.Next() {
		var u User
		if err := rows.Scan(&u.ID, &u.Name, &u.Email); err != nil {
			return User{}, err
		}
		return u, nil
	}
	if err := rows.Err(); err != nil {
		return User{}, err
	}
	return User{}, sql.ErrNoRows
}

// ErrConflict indicates a duplicate primary key attempt.
var ErrConflict = errors.New("user already exists")
