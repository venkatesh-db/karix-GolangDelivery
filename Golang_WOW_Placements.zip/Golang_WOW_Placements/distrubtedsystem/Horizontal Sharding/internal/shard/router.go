package shard

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"hash/crc32"
	"math/rand"
	"sync"
	"time"

	_ "modernc.org/sqlite"
)

// Shard holds live connections to a primary and optional replicas.
type Shard struct {
	Cfg      ShardConfig
	Primary  *sql.DB
	Replicas []*sql.DB
}

// Router deterministically maps keys to shard handles.
type Router struct {
	mu     sync.RWMutex
	shards []*Shard
}

// NewRouter opens SQLite connections for each configured shard.
func NewRouter(cfg Config) (*Router, error) {
	shards := make([]*Shard, len(cfg.Shards))
	for i, sc := range cfg.Shards {
		primary, err := openSQLite(sc.Primary)
		if err != nil {
			return nil, fmt.Errorf("shard %d primary: %w", sc.ID, err)
		}
		replicas := make([]*sql.DB, len(sc.Replicas))
		for j, dsn := range sc.Replicas {
			replicas[j], err = openSQLite(dsn)
			if err != nil {
				return nil, fmt.Errorf("shard %d replica %d: %w", sc.ID, j, err)
			}
		}
		shards[i] = &Shard{Cfg: sc, Primary: primary, Replicas: replicas}
	}
	return &Router{shards: shards}, nil
}

// ForEachShard invokes fn for every shard in a thread-safe manner.
func (r *Router) ForEachShard(fn func(*Shard) error) error {
	r.mu.RLock()
	defer r.mu.RUnlock()
	for _, sh := range r.shards {
		if err := fn(sh); err != nil {
			return err
		}
	}
	return nil
}

// Close releases every connection the router opened.
func (r *Router) Close() error {
	r.mu.Lock()
	defer r.mu.Unlock()
	var first error
	for _, sh := range r.shards {
		if sh.Primary != nil {
			if err := sh.Primary.Close(); err != nil && first == nil {
				first = err
			}
		}
		for _, db := range sh.Replicas {
			if db == nil {
				continue
			}
			if err := db.Close(); err != nil && first == nil {
				first = err
			}
		}
	}
	return first
}

// Exec writes through the primary shard that contains the provided key.
func (r *Router) Exec(ctx context.Context, key string, query string, args ...any) (sql.Result, error) {
	sh, err := r.shardForKey(key)
	if err != nil {
		return nil, err
	}
	return sh.Primary.ExecContext(ctx, query, args...)
}

// Query targets a replica when available, falling back to the primary.
func (r *Router) Query(ctx context.Context, key string, query string, args ...any) (*sql.Rows, error) {
	sh, err := r.shardForKey(key)
	if err != nil {
		return nil, err
	}
	db := sh.pickReplica()
	return db.QueryContext(ctx, query, args...)
}

// WithShard exposes the underlying *sql.DB so callers can run transactions.
func (r *Router) WithShard(key string, fn func(*sql.DB) error) error {
	sh, err := r.shardForKey(key)
	if err != nil {
		return err
	}
	return fn(sh.Primary)
}

func (r *Router) shardForKey(key string) (*Shard, error) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	if len(r.shards) == 0 {
		return nil, errors.New("shard router: no shards configured")
	}
	idx := crc32.ChecksumIEEE([]byte(key)) % uint32(len(r.shards))
	return r.shards[idx], nil
}

func (s *Shard) pickReplica() *sql.DB {
	if len(s.Replicas) == 0 {
		return s.Primary
	}
	return s.Replicas[rand.Intn(len(s.Replicas))]
}

func openSQLite(dsn string) (*sql.DB, error) {
	db, err := sql.Open("sqlite", dsn+"?_busy_timeout=10000&_journal_mode=WAL")
	if err != nil {
		return nil, err
	}
	db.SetMaxOpenConns(1) // serialized writer per process
	db.SetConnMaxIdleTime(time.Minute)
	db.SetConnMaxLifetime(5 * time.Minute)
	return db, nil
}
