package shard

import (
	"fmt"
	"io"
	"os"

	"gopkg.in/yaml.v3"
)

// Range captures an inclusive key interval assigned to a shard.
type Range struct {
	Min uint32 `yaml:"min"`
	Max uint32 `yaml:"max"`
}

// ShardConfig declares how to connect to the databases backing a shard.
type ShardConfig struct {
	ID       int      `yaml:"id"`
	KeyRange Range    `yaml:"key_range"`
	Primary  string   `yaml:"primary"`
	Replicas []string `yaml:"replicas"`
}

// Config is the top-level YAML representation.
type Config struct {
	Shards []ShardConfig `yaml:"shards"`
}

// LoadConfig reads a YAML file and performs basic validation.
func LoadConfig(path string) (Config, error) {
	f, err := os.Open(path)
	if err != nil {
		return Config{}, fmt.Errorf("open config: %w", err)
	}
	defer f.Close()
	return decodeConfig(f)
}

func decodeConfig(r io.Reader) (Config, error) {
	var cfg Config
	dec := yaml.NewDecoder(r)
	if err := dec.Decode(&cfg); err != nil {
		return Config{}, fmt.Errorf("decode config: %w", err)
	}
	if err := cfg.Validate(); err != nil {
		return Config{}, err
	}
	return cfg, nil
}

// Validate ensures shard definitions contain usable info.
func (c Config) Validate() error {
	if len(c.Shards) == 0 {
		return fmt.Errorf("at least one shard required")
	}
	for _, s := range c.Shards {
		if s.KeyRange.Min > s.KeyRange.Max {
			return fmt.Errorf("shard %d: min greater than max", s.ID)
		}
		if s.Primary == "" {
			return fmt.Errorf("shard %d: primary DSN missing", s.ID)
		}
	}
	return nil
}
