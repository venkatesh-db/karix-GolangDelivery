# Go Testing Examples Playground

Comprehensive examples across testing levels: unit, API (httptest), gRPC, DB integration (Testcontainers), Redis, Kafka/NATS, contract (Pact), E2E, WireMock, load (k6), chaos, synthetic monitoring, canary diff, shadow traffic replay, CI/CD, and security.

## Quick Start

```bash
# Ensure Go is installed (1.22+)
cd "./Golang WOW Placments/distrubtedsystem/endendtesting"

# Run unit tests
go test ./...

# Run integration tests (requires Docker)
DOCKER_HOST=${DOCKER_HOST:-unix:///var/run/docker.sock} go test ./integration/... -v

# Run k6 load test
k6 run ./load/k6_api_smoke.js
```

## Structure
- `pkg/` core packages used across examples
- `unit/` unit tests
- `api/` HTTP handlers + httptest
- `grpc/` gRPC service + tests
- `integration/db/` Postgres (Testcontainers)
- `integration/redis/` Redis (Testcontainers)
- `integration/kafka/` Kafka (Testcontainers)
- `integration/nats/` NATS (Testcontainers)
- `contract/pact/` Pact consumer/provider tests
- `e2e/` end-to-end workflow tests
- `wiremock/` WireMock stubs via Testcontainers
- `load/` k6 scripts
- `chaos/` toxiproxy fault injection
- `synthetic/` synthetic monitoring runner
- `canary/` diff tests comparing two versions
- `shadow/` shadow traffic replay
- `.github/workflows/` CI pipelines

Each folder contains minimal, runnable examples with commands.
