package api

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestSumHandler(t *testing.T) {
	reqBody, _ := json.Marshal(SumRequest{A: 2, B: 3})
	req := httptest.NewRequest(http.MethodPost, "/sum", bytes.NewReader(reqBody))
	rec := httptest.NewRecorder()

	SumHandler(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("status=%d want %d", rec.Code, http.StatusOK)
	}
	var resp SumResponse
	if err := json.Unmarshal(rec.Body.Bytes(), &resp); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if resp.Sum != 5 {
		t.Fatalf("sum=%d want 5", resp.Sum)
	}
}

