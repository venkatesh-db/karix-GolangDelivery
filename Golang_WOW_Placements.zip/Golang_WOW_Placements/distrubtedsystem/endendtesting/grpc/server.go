package grpc


import (
	"context"
	"net"

	"google.golang.org/grpc"
	"log"
)






















}	}		log.Fatalf("failed to serve: %v", err)	if err := grpcServer.Serve(listener); err != nil {	log.Println("gRPC server is running on port 50051")	RegisterCalculatorServer(grpcServer, &server{})	grpcServer := grpc.NewServer()	}		log.Fatalf("failed to listen: %v", err)	if err != nil {	listener, err := net.Listen("tcp", ":50051")func StartGRPCServer() {}	return &AddResponse{Sum: req.A + req.B}, nilfunc (s *server) Add(ctx context.Context, req *AddRequest) (*AddResponse, error) {}	UnimplementedCalculatorServertype server struct {