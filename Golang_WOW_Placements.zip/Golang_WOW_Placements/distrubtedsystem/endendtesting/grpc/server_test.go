package grpc
package grpc

import (
	"context"
	"testing"
)

func TestAdd(t *testing.T) {








}	}		t.Fatalf("Add(3, 5) = %d; want 8", resp.Sum)	if resp.Sum != 8 {	}		t.Fatalf("Add failed: %v", err)	if err != nil {	resp, err := s.Add(context.Background(), &AddRequest{A: 3, B: 5})	s := &server{}