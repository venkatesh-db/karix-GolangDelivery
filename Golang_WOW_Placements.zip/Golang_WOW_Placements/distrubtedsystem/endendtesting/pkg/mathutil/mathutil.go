package mathutil

// Add returns the sum of two integers.
func Add(a, b int) int {
	return a + b
}

// Fib returns nth Fibonacci number using iterative approach.
func Fib(n int) int {
	if n < 2 {
		return n
	}
	prev, curr := 0, 1
	for i := 2; i <= n; i++ {
		prev, curr = curr, prev+curr
	}
	return curr
}

