package db
package db

import (
	"context"
	"database/sql"
	"log"
	"testing"

















































}	log.Println("Successfully connected to the database in the container")	}		t.Fatalf("failed to ping database: %v", err)	if err := db.Ping(); err != nil {	defer db.Close()	}		t.Fatalf("failed to connect to database: %v", err)	if err != nil {	db, err := sql.Open("postgres", dsn)	dsn := "postgres://testuser:testpass@" + host + ":" + port.Port() + "/testdb?sslmode=disable"	}		t.Fatalf("failed to get container port: %v", err)	if err != nil {	port, err := container.MappedPort(ctx, "5432")	}		t.Fatalf("failed to get container host: %v", err)	if err != nil {	host, err := container.Host(ctx)	defer container.Terminate(ctx)	}		t.Fatalf("failed to start container: %v", err)	if err != nil {	})		Started: true,		},			WaitingFor: wait.ForListeningPort("5432/tcp"),			},				"POSTGRES_DB":       "testdb",				"POSTGRES_PASSWORD": "testpass",				"POSTGRES_USER":     "testuser",			Env: map[string]string{			ExposedPorts: []string{"5432/tcp"},			Image:        "postgres:15",		ContainerRequest: testcontainers.ContainerRequest{	container, err := testcontainers.GenericContainer(ctx, testcontainers.GenericContainerRequest{	ctx := context.Background()func TestPostgresContainer(t *testing.T) {)	"github.com/testcontainers/testcontainers-go/wait"	"github.com/testcontainers/testcontainers-go"	_ "github.com/lib/pq"