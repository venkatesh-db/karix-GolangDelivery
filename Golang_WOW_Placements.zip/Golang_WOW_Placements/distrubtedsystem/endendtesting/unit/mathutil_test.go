package unit

import (
	"testing"
	"example.com/testing-playground/pkg/mathutil"
)

func TestAdd(t *testing.T) {
	cases := []struct{
		name string
		a, b int
		want int
	}{
		{"simple", 1, 2, 3},
		{"zero", 0, 0, 0},
		{"negative", -2, 5, 3},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			got := mathutil.Add(c.a, c.b)
			if got != c.want {
				t.Fatalf("Add(%d,%d)=%d want %d", c.a, c.b, got, c.want)
			}
		})
	}
}

func TestFib(t *testing.T) {
	for i, want := range []int{0, 1, 1, 2, 3, 5, 8, 13} {
		if got := mathutil.Fib(i); got != want {
			t.Fatalf("Fib(%d)=%d want %d", i, got, want)
		}
	}
}

