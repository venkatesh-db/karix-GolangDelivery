# PostgreSQL Tenant + Monthly Partitioning with Go

Two-level declarative partitioning demo using `pgx`:
- Parent table `events` LIST-partitioned by `tenant_id`
- Subpartitions per tenant by RANGE(`created_at`) monthly
- Auto-create tenant partitions and monthly subpartitions
- Minimal migration, demo inserts, pre-create command, and test harness

## Requirements
- Go 1.21+
- PostgreSQL 12+ (subpartitioning available in recent versions)

## Configure Postgres
Create a database and set `DATABASE_URL`:

```sh
export DATABASE_URL="postgres://postgres:postgres@localhost:5432/partdemo?sslmode=disable"
```

## Run
```sh
cd "PostgreSQL Partitioning/partition-demo"
go mod tidy

# run demo inserts for tenant 42 across months
go run ./cmd/partition-demo demo

# pre-create next 6 months for tenant 42
go run ./cmd/partition-demo precreate -tenant 42 -months 6

# run test harness to assert partition counts (after demo)
go run ./cmd/partition-demo test
```

List created partitions:

```sql
\dt
```

Validate rows route to correct partitions:

```sql
SELECT tableoid::regclass AS partition, count(*)
FROM events
GROUP BY 1
ORDER BY 1;
```

## Production Notes
- Use two-level declarative partitioning: LIST by `tenant_id`, RANGE by `created_at` with bounds `[month_start, next_month_start)`.
- Create partitions inside the same transaction before first write for a period to avoid races.
- Keep parent indexes on filter columns (e.g., `type`); add partition-local indexes for heavy access paths.
- Avoid routing triggers; declarative partitioning routes automatically.
- Plan retention: detach/drop old month partitions, or move to archive.
- Pre-create upcoming N months during deploy to reduce write-time DDL.

## Files
- `sql/schema.sql`: DDL for parent list partition and example subpartition.
- `internal/db/partition.go`: Helpers for tenant partition and monthly subpartition.
- `internal/db/migrate.go`: Migration runner.
- `cmd/partition-demo/main.go`: CLI with `demo`, `precreate`, and `test` commands.
