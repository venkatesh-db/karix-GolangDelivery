-- Declarative partitioned table: monthly range partitions on created_at
-- Top-level LIST partitioning by tenant_id; subpartition by RANGE(created_at)
CREATE TABLE IF NOT EXISTS events (
    id            BIGSERIAL PRIMARY KEY,
    tenant_id     INTEGER NOT NULL,
    type          TEXT NOT NULL,
    payload       JSONB NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
) PARTITION BY LIST (tenant_id);

-- Parent indexes that propagate to partitions where applicable
CREATE INDEX IF NOT EXISTS idx_events_type ON events (type);

-- Example partition for current month (the app will create per-month partitions automatically)
-- Boundaries: [first_day_of_month, first_day_next_month)
-- Example: create a tenant partition and a current-month subpartition
DO $$
DECLARE
    t_id integer := 42;
    tenant_part_name text := format('events_t_%s', t_id);
    start_ts timestamptz := date_trunc('month', now());
    next_ts  timestamptz := (date_trunc('month', now()) + interval '1 month');
    month_part_name text := format('events_%s_%s', t_id, to_char(start_ts, 'YYYY_MM'));
BEGIN
    -- Create tenant list partition if missing
    IF NOT EXISTS (
        SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
        WHERE n.nspname = current_schema() AND c.relname = tenant_part_name
    ) THEN
        EXECUTE format(
            'CREATE TABLE %I PARTITION OF events FOR VALUES IN (%s) PARTITION BY RANGE (created_at);',
            tenant_part_name, t_id
        );
    END IF;

    -- Create month subpartition under tenant
    IF NOT EXISTS (
        SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
        WHERE n.nspname = current_schema() AND c.relname = month_part_name
    ) THEN
        EXECUTE format(
            'CREATE TABLE %I PARTITION OF %I FOR VALUES FROM (%L) TO (%L);',
            month_part_name, tenant_part_name, start_ts, next_ts
        );
    END IF;
END $$;