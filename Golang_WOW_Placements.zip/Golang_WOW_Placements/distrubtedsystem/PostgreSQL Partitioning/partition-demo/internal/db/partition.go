package db

import (
	"context"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
)

// EnsureMonthlyPartition creates a monthly partition for the given timestamp if missing.
// Partitions are named events_YYYY_MM, covering [month_start, next_month_start).
// EnsureTenantPartition ensures a LIST partition for the given tenant_id exists.
func EnsureTenantPartition(ctx context.Context, conn pgx.Tx, tenantID int) error {
	tenantPart := fmt.Sprintf("events_t_%d", tenantID)

	var exists bool
	if err := conn.QueryRow(ctx, `
		SELECT EXISTS (
			SELECT 1
			FROM pg_class c
			JOIN pg_namespace n ON n.oid = c.relnamespace
			WHERE n.nspname = current_schema() AND c.relname = $1
		)
	`, tenantPart).Scan(&exists); err != nil {
		return err
	}
	if exists {
		return nil
	}

	_, err := conn.Exec(ctx, fmt.Sprintf(
		"CREATE TABLE IF NOT EXISTS %s PARTITION OF events FOR VALUES IN ($1) PARTITION BY RANGE (created_at);",
		pgx.Identifier{tenantPart}.Sanitize(),
	), tenantID)
	return err
}

// EnsureMonthlySubpartition ensures a monthly RANGE subpartition exists under a tenant partition.
func EnsureMonthlySubpartition(ctx context.Context, conn pgx.Tx, tenantID int, ts time.Time) error {
	start := time.Date(ts.Year(), ts.Month(), 1, 0, 0, 0, 0, time.UTC)
	next := start.AddDate(0, 1, 0)
	parent := fmt.Sprintf("events_t_%d", tenantID)
	partName := fmt.Sprintf("events_%d_%04d_%02d", tenantID, start.Year(), int(start.Month()))

	var exists bool
	if err := conn.QueryRow(ctx, `
		SELECT EXISTS (
			SELECT 1
			FROM pg_class c
			JOIN pg_namespace n ON n.oid = c.relnamespace
			WHERE n.nspname = current_schema() AND c.relname = $1
		)
	`, partName).Scan(&exists); err != nil {
		return err
	}
	if exists {
		return nil
	}

	_, err := conn.Exec(ctx, fmt.Sprintf(
		"CREATE TABLE IF NOT EXISTS %s PARTITION OF %s FOR VALUES FROM ($1) TO ($2);",
		pgx.Identifier{partName}.Sanitize(), pgx.Identifier{parent}.Sanitize(),
	), start, next)
	return err
}
