package db

import (
	"context"
	"os"

	"github.com/jackc/pgx/v5/pgxpool"
)

// Migrate runs the schema.sql file to create parent table and current partition.
func Migrate(ctx context.Context, pool *pgxpool.Pool) error {
	b, err := os.ReadFile("sql/schema.sql")
	if err != nil {
		return err
	}
	_, err = pool.Exec(ctx, string(b))
	return err
}
