package db

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5/pgxpool"
)

// ReplicationStatus returns replication state and lag metrics.
// On primary, it queries pg_stat_replication; on standby, lag since last replay.
func ReplicationStatus(ctx context.Context, pool *pgxpool.Pool) (string, error) {
	// Try primary view first
	rows, err := pool.Query(ctx, `
		SELECT application_name, state, sync_state, sent_lsn, write_lsn, flush_lsn, replay_lsn
		FROM pg_stat_replication
	`)
	if err == nil {
		defer rows.Close()
		var out string
		for rows.Next() {
			var app, state, sync string
			var sent, write, flush, replay string
			if err := rows.Scan(&app, &state, &sync, &sent, &write, &flush, &replay); err != nil {
				return "", err
			}
			out += fmt.Sprintf("replica=%s state=%s sync=%s\n", app, state, sync)
		}
		if out != "" {
			return out, nil
		}
	}
	// Standby view: replay lag
	var lagSec *float64
	err = pool.QueryRow(ctx, `SELECT EXTRACT(EPOCH FROM now() - pg_last_xact_replay_timestamp())`).Scan(&lagSec)
	if err != nil {
		return "", err
	}
	if lagSec == nil {
		return "standby idle: no replay activity", nil
	}
	return fmt.Sprintf("standby lag=%.2fs", *lagSec), nil
}
