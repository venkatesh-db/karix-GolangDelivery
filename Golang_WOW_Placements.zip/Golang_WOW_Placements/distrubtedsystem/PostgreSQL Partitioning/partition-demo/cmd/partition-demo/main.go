package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"math/rand"
	"os"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/venkatesh/partition-demo/internal/db"
)

func main() {
	ctx := context.Background()
	dsn := os.Getenv("DATABASE_URL")
	if dsn == "" {
		log.Fatal("set DATABASE_URL, e.g. postgres://user:pass@localhost:5432/dbname?sslmode=disable")
	}

	pool, err := pgxpool.New(ctx, dsn)
	if err != nil {
		log.Fatalf("pool error: %v", err)
	}
	defer pool.Close()

	if err := db.Migrate(ctx, pool); err != nil {
		log.Fatalf("migration error: %v", err)
	}

	// Subcommands: demo, precreate, test
	cmd := "demo"
	if len(os.Args) > 1 {
		cmd = os.Args[1]
	}

	switch cmd {
	case "demo":
		runDemo(ctx, pool)
	case "precreate":
		runPrecreate(ctx, pool)
	case "test":
		runTest(ctx, pool)
	case "load":
		runLoad(ctx, pool)
	case "repl":
		runReplicationCheck(ctx, pool)
	default:
		log.Fatalf("unknown command: %s (use demo|precreate|test|load|repl)", cmd)
	}
}

func mustParseMonth(s string) time.Time {
	// Parse YYYY-MM-01 to month start in UTC
	t, err := time.Parse("2006-01-02", s)
	if err != nil {
		panic(err)
	}
	return time.Date(t.Year(), t.Month(), 1, 0, 0, 0, 0, time.UTC)
}

func runDemo(ctx context.Context, pool *pgxpool.Pool) {
	tx, err := pool.Begin(ctx)
	if err != nil {
		log.Fatal(err)
	}
	defer tx.Rollback(ctx)

	tenantID := 42
	if err := db.EnsureTenantPartition(ctx, tx, tenantID); err != nil {
		log.Fatalf("ensure tenant partition: %v", err)
	}

	months := []time.Time{
		mustParseMonth("2025-11-01"),
		mustParseMonth("2025-12-01"),
		mustParseMonth("2026-01-01"),
	}

	for _, m := range months {
		if err := db.EnsureMonthlySubpartition(ctx, tx, tenantID, m); err != nil {
			log.Fatalf("ensure month subpartition: %v", err)
		}
		for i := 0; i < 3; i++ {
			payload := map[string]any{"i": i, "seed": rand.Intn(1000)}
			b, _ := json.Marshal(payload)
			created := m.Add(time.Hour * time.Duration(i))
			_, err := tx.Exec(ctx, `
				INSERT INTO events (tenant_id, type, payload, created_at)
				VALUES ($1, $2, $3::jsonb, $4)
			`, tenantID, fmt.Sprintf("type-%d", i%2), string(b), created)
			if err != nil {
				log.Fatalf("insert error: %v", err)
			}
		}
	}
	if err := tx.Commit(ctx); err != nil {
		log.Fatal(err)
	}
	log.Println("Inserted demo rows into tenant/month subpartitions.")
}

func runPrecreate(ctx context.Context, pool *pgxpool.Pool) {
	fs := flag.NewFlagSet("precreate", flag.ExitOnError)
	tenantID := fs.Int("tenant", 42, "tenant id to precreate for")
	monthsAhead := fs.Int("months", 6, "number of future months to create")
	_ = fs.Parse(os.Args[2:])

	tx, err := pool.Begin(ctx)
	if err != nil {
		log.Fatal(err)
	}
	defer tx.Rollback(ctx)

	if err := db.EnsureTenantPartition(ctx, tx, *tenantID); err != nil {
		log.Fatalf("ensure tenant partition: %v", err)
	}
	start := time.Date(time.Now().Year(), time.Now().Month(), 1, 0, 0, 0, 0, time.UTC)
	for i := 0; i < *monthsAhead; i++ {
		m := start.AddDate(0, i, 0)
		if err := db.EnsureMonthlySubpartition(ctx, tx, *tenantID, m); err != nil {
			log.Fatalf("ensure month subpartition: %v", err)
		}
	}
	if err := tx.Commit(ctx); err != nil {
		log.Fatal(err)
	}
	log.Printf("Precreated %d future monthly subpartitions for tenant %d\n", *monthsAhead, *tenantID)
}

func runTest(ctx context.Context, pool *pgxpool.Pool) {
	// Simple assertions: partitions exist and counts per partition are non-zero after demo
	rows, err := pool.Query(ctx, `
		SELECT tableoid::regclass::text AS partition, count(*)
		FROM events
		GROUP BY 1
		ORDER BY 1
	`)
	if err != nil {
		log.Fatal(err)
	}
	defer rows.Close()

	total := 0
	for rows.Next() {
		var part string
		var cnt int
		if err := rows.Scan(&part, &cnt); err != nil {
			log.Fatal(err)
		}
		fmt.Printf("%s -> %d\n", part, cnt)
		total += cnt
	}
	if rows.Err() != nil {
		log.Fatal(rows.Err())
	}
	if total == 0 {
		log.Fatal("no rows found; run demo first or check inserts")
	}
	log.Printf("OK: total rows=%d\n", total)
}

// listTenants returns distinct tenant_ids observed in events.
func listTenants(ctx context.Context, tx pgx.Tx) []int {
	rows, err := tx.Query(ctx, `SELECT DISTINCT tenant_id FROM events`)
	if err != nil {
		log.Printf("list tenants error: %v", err)
		return nil
	}
	defer rows.Close()
	var out []int
	for rows.Next() {
		var t int
		if err := rows.Scan(&t); err != nil {
			log.Printf("scan tenant: %v", err)
			continue
		}
		out = append(out, t)
	}
	return out
}

// runLoad loads exactly 1,000,000 rows using CopyFrom for a tenant across a date range.
func runLoad(ctx context.Context, pool *pgxpool.Pool) {
	fs := flag.NewFlagSet("load", flag.ExitOnError)
	tenantID := fs.Int("tenant", 42, "tenant id to load for")
	count := fs.Int("count", 1000000, "rows to load (default 1,000,000)")
	startMonth := fs.String("start", time.Now().Format("2006-01-02"), "start month (YYYY-MM-01)")
	months := fs.Int("months", 3, "number of months to spread data across")
	batchSize := fs.Int("batch", 10000, "CopyFrom batch size")
	_ = fs.Parse(os.Args[2:])

	start := mustParseMonth(*startMonth)

	// Prepare partitions first
	tx, err := pool.Begin(ctx)
	if err != nil {
		log.Fatal(err)
	}
	if err := db.EnsureTenantPartition(ctx, tx, *tenantID); err != nil {
		log.Fatal(err)
	}
	for i := 0; i < *months; i++ {
		m := start.AddDate(0, i, 0)
		if err := db.EnsureMonthlySubpartition(ctx, tx, *tenantID, m); err != nil {
			log.Fatal(err)
		}
	}
	if err := tx.Commit(ctx); err != nil {
		log.Fatal(err)
	}

	// CopyFrom requires a connection
	conn, err := pool.Acquire(ctx)
	if err != nil {
		log.Fatal(err)
	}
	defer conn.Release()

	// Create a row source implementing pgx.CopyFromSource
	type row struct {
		tenant  int
		typ     string
		payload string
		created time.Time
	}
	makeRow := func(i int) row {
		m := start.AddDate(0, (i % *months), 0)
		created := m.Add(time.Minute * time.Duration(i%43200)) // spread across month
		return row{tenant: *tenantID, typ: fmt.Sprintf("type-%d", i%10), payload: fmt.Sprintf(`{"i":%d}`, i), created: created}
	}

	// Generator
	rowsGenerated := 0
	for rowsGenerated < *count {
		// Prepare batch slice
		end := rowsGenerated + *batchSize
		if end > *count {
			end = *count
		}
		batch := end - rowsGenerated

		// Build CopyFrom rows
		cfRows := make([][]any, 0, batch)
		for i := rowsGenerated; i < end; i++ {
			r := makeRow(i)
			cfRows = append(cfRows, []any{r.tenant, r.typ, r.payload, r.created})
		}

		// Use CopyFrom on events columns in insert order
		n, err := conn.Conn().CopyFrom(ctx,
			pgx.Identifier{"events"},
			[]string{"tenant_id", "type", "payload", "created_at"},
			pgx.CopyFromRows(cfRows),
		)
		if err != nil {
			log.Fatalf("copyfrom error: %v", err)
		}
		rowsGenerated += int(n)
		log.Printf("Loaded %d/%d rows\n", rowsGenerated, *count)
	}
	log.Printf("Completed loading %d rows for tenant %d across %d months\n", *count, *tenantID, *months)
}

func runReplicationCheck(ctx context.Context, pool *pgxpool.Pool) {
	status, err := db.ReplicationStatus(ctx, pool)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println(status)
}
