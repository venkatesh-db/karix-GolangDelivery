# Go Microservices Messaging: RabbitMQ + Kafka

This workspace contains two minimal, production-minded Go microservices demonstrating service-to-service communication using RabbitMQ (publisher) and Kafka (consumer).

## Services
- `order-service`: HTTP endpoint publishes `OrderCreated` events to RabbitMQ.
- `payment-service`: Kafka consumer reads `orders` topic messages and logs them.

## Prerequisites
- Go 1.22+
- Docker (for RabbitMQ and Kafka)

## Start brokers
```sh
docker compose up -d
```

## Run locally (without Docker)
```sh
cd "/Users/venkatesh/Golang WOW Placments/distrubtedsystem/distrubtedfaulttorrentkafka"
go run ./order-service
# In a second terminal
go run ./payment-service
```

Create an order:
```sh
curl -X POST http://localhost:8080/create-order -i
```

Check health/metrics:
```sh
curl -s localhost:8080/healthz
curl -s localhost:8080/readyz
curl -s localhost:8080/metrics | head
curl -s localhost:9099/metrics | head
```

## Run with Docker

Build images:
```sh
cd "/Users/venkatesh/Golang WOW Placments/distrubtedsystem/distrubtedfaulttorrentkafka"
docker build -t order-service:local -f order-service/Dockerfile .
docker build -t payment-service:local -f payment-service/Dockerfile .
```

Start brokers:
```sh
docker compose up -d
```

Run services on the compose network:
```sh
docker run --name order-service \
	--network distrubtedfaulttorrentkafka_default \
	-e RABBITMQ_URL="amqp://guest:guest@rabbitmq:5672/" \
	-e RABBITMQ_EXCHANGE="events" \
	-e RABBITMQ_EXCHANGE_TYPE="topic" \
	-e KAFKA_BROKERS="kafka:9092" \
	-e HTTP_PORT="8080" \
	-p 8080:8080 \
	order-service:local

docker run --name payment-service \
	--network distrubtedfaulttorrentkafka_default \
	-e KAFKA_BROKERS="kafka:9092" \
	-e KAFKA_GROUP_ID="payment-service" \
	-e KAFKA_TOPIC="orders" \
	-p 9099:9099 \
	payment-service:local
```

## OpenTelemetry (optional)
- OTLP HTTP exporter is enabled by default; if you run an OTEL collector on `http://localhost:4318`, spans will be exported. Otherwise services continue without exporting.

## Environment
Common env (defaults provided):
- `RABBITMQ_URL=amqp://guest:guest@localhost:5672/`
- `RABBITMQ_EXCHANGE=events`
- `RABBITMQ_EXCHANGE_TYPE=topic`
- `KAFKA_BROKERS=localhost:9092`
- `KAFKA_GROUP_ID=payment-service`
- `KAFKA_TOPIC=orders`
- `HTTP_PORT=8080`

## Run order-service
```sh
go run ./order-service
```

Create an order (publishes to RabbitMQ):
```sh
curl -X POST http://localhost:8080/create-order -i
```

## Run payment-service
Ensure a Kafka topic exists (Bitnami Kafka auto-creates on produce, but you may create explicitly):
```sh
# Optional: create topic using kafka-topics if available
```

```sh
go run ./payment-service
```

## Notes
- Logging via `zerolog` with `LOG_LEVEL` to control verbosity.
- Config via `envconfig` with validation; TLS placeholders for Kafka.
- RabbitMQ: exchange declared, publisher confirms, durable queue with DLX.
- Kafka: consumer group with basic retry/backoff; metrics exposed.
- Health: `/healthz` and `/readyz`; Metrics: `/metrics` on order-service and `:9099/metrics` for payment-service.

## Troubleshooting
- Ensure Docker is running and ports `5672`, `15672`, `9092`, `8080`, `9099` are free.
- If Kafka fails to start, run `docker compose logs kafka` to inspect.
- If RabbitMQ management UI is needed: open `http://localhost:15672` (guest/guest).
