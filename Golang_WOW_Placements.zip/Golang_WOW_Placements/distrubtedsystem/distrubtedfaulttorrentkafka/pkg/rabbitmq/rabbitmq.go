package rabbitmq

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	amqp "github.com/rabbitmq/amqp091-go"
)

type Client struct {
	conn     *amqp.Connection
	channel  *amqp.Channel
	exchange string
}

func New(url, exchange, exchangeType string) (*Client, error) {
	conn, err := amqp.Dial(url)
	if err != nil {
		return nil, fmt.Errorf("rabbitmq dial: %w", err)
	}
	ch, err := conn.Channel()
	if err != nil {
		conn.Close()
		return nil, fmt.Errorf("rabbitmq channel: %w", err)
	}
	if err := ch.ExchangeDeclare(exchange, exchangeType, true, false, false, false, nil); err != nil {
		ch.Close()
		conn.Close()
		return nil, fmt.Errorf("exchange declare: %w", err)
	}
	if err := ch.Confirm(false); err != nil {
		ch.Close()
		conn.Close()
		return nil, fmt.Errorf("enable confirms: %w", err)
	}
	return &Client{conn: conn, channel: ch, exchange: exchange}, nil
}

func (c *Client) PublishJSON(exchange, routingKey string, msg any) error {
	body, err := json.Marshal(msg)
	if err != nil {
		return fmt.Errorf("marshal: %w", err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := c.channel.PublishWithContext(ctx, exchange, routingKey, false, false, amqp.Publishing{
		ContentType:  "application/json",
		DeliveryMode: amqp.Persistent,
		Timestamp:    time.Now(),
		Body:         body,
	}); err != nil {
		return err
	}
	select {
	case <-c.channel.NotifyPublish(make(chan amqp.Confirmation, 1)):
		return nil
	case <-time.After(5 * time.Second):
		return fmt.Errorf("publish confirm timeout")
	}
}

func (c *Client) Close() {
	if c.channel != nil {
		_ = c.channel.Close()
	}
	if c.conn != nil {
		_ = c.conn.Close()
	}
}

// Declare durable queue with DLX and bind routing key.
func (c *Client) EnsureQueueWithDLX(queue, routingKey, dlx string) error {
	args := amqp.Table{
		"x-dead-letter-exchange": dlx,
	}
	if _, err := c.channel.QueueDeclare(queue, true, false, false, false, args); err != nil {
		return fmt.Errorf("queue declare: %w", err)
	}
	if err := c.channel.ExchangeDeclare(dlx, "topic", true, false, false, false, nil); err != nil {
		return fmt.Errorf("dlx declare: %w", err)
	}
	if err := c.channel.QueueBind(queue, routingKey, c.exchange, false, nil); err != nil {
		return fmt.Errorf("queue bind: %w", err)
	}
	return nil
}
