package log

import (
	"os"
	"time"

	"github.com/rs/zerolog"
)

var Logger zerolog.Logger

func Init(service string) {
	level := zerolog.InfoLevel
	if os.Getenv("LOG_LEVEL") != "" {
		if parsed, err := zerolog.ParseLevel(os.Getenv("LOG_LEVEL")); err == nil {
			level = parsed
		}
	}
	zerolog.DurationFieldInteger = true
	zerolog.TimeFieldFormat = time.RFC3339
	Logger = zerolog.New(os.Stdout).With().Timestamp().Str("service", service).Logger()
	zerolog.SetGlobalLevel(level)
}
