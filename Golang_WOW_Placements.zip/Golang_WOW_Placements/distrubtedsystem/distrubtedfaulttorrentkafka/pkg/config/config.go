package config

import (
	"fmt"

	"github.com/kelseyhightower/envconfig"
)

type RabbitMQ struct {
	URL          string `env:"RABBITMQ_URL" default:"amqp://guest:guest@localhost:5672/"`
	Exchange     string `env:"RABBITMQ_EXCHANGE" default:"events"`
	ExchangeType string `env:"RABBITMQ_EXCHANGE_TYPE" default:"topic"`
}

type Kafka struct {
	Brokers []string `env:"KAFKA_BROKERS" default:"localhost:9092"`
	GroupID string   `env:"KAFKA_GROUP_ID" default:"payment-service"`
	Topic   string   `env:"KAFKA_TOPIC" default:"orders"`
	// TLS/SASL placeholders (non-local)
	EnableTLS bool   `env:"KAFKA_ENABLE_TLS" default:"false"`
	CACert    string `env:"KAFKA_CA_CERT" default:""`
}

type HTTP struct {
	Port int `env:"HTTP_PORT" default:"8080"`
}

type Config struct {
	RabbitMQ RabbitMQ
	Kafka    Kafka
	HTTP     HTTP
}

func Load() (*Config, error) {
	var c Config
	if err := envconfig.Process("", &c); err != nil {
		return nil, fmt.Errorf("load config: %w", err)
	}
	if len(c.Kafka.Brokers) == 0 {
		return nil, fmt.Errorf("invalid config: KAFKA_BROKERS required")
	}
	if c.RabbitMQ.URL == "" || c.RabbitMQ.Exchange == "" {
		return nil, fmt.Errorf("invalid config: RABBITMQ_URL and RABBITMQ_EXCHANGE required")
	}
	return &c, nil
}
