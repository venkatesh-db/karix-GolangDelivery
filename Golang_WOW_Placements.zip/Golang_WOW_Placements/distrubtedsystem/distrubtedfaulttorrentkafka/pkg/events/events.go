package events

import "time"

type OrderCreated struct {
	ID        string    `json:"id"`
	Amount    float64   `json:"amount"`
	Currency  string    `json:"currency"`
	Customer  string    `json:"customer"`
	CreatedAt time.Time `json:"created_at"`
}

func (e OrderCreated) Topic() string      { return "orders" }
func (e OrderCreated) RoutingKey() string { return "order.created" }
