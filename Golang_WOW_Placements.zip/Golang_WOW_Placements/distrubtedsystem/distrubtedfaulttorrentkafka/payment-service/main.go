package main

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/IBM/sarama"
	"github.com/prometheus/client_golang/prometheus"
	promhttp "github.com/prometheus/client_golang/prometheus/promhttp"
	"github.com/venkatesh/distrubtedfaulttorrentkafka/pkg/config"
	"github.com/venkatesh/distrubtedfaulttorrentkafka/pkg/log"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracehttp"
	"go.opentelemetry.io/otel/sdk/resource"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	semconv "go.opentelemetry.io/otel/semconv/v1.26.0"
)

var tracer = otel.Tracer("payment-service")

type orderConsumer struct{}

func (orderConsumer) Setup(sarama.ConsumerGroupSession) error   { return nil }
func (orderConsumer) Cleanup(sarama.ConsumerGroupSession) error { return nil }
func (orderConsumer) ConsumeClaim(sess sarama.ConsumerGroupSession, claim sarama.ConsumerGroupClaim) error {
	for msg := range claim.Messages() {
		processed := false
		for i := 0; i < 3; i++ {
			_, span := tracer.Start(sess.Context(), "consume-order")
			log.Logger.Info().Str("topic", msg.Topic).Int32("partition", msg.Partition).Int64("offset", msg.Offset).Msg(string(msg.Value))
			span.End()
			processed = true
			if processed {
				break
			}
			time.Sleep(time.Duration(i+1) * 200 * time.Millisecond)
		}
		if processed {
			sess.MarkMessage(msg, "")
		} else {
			log.Logger.Error().Msg("processing failed after retries")
		}
	}
	return nil
}

func main() {
	log.Init("payment-service")
	cfg, err := config.Load()
	if err != nil {
		log.Logger.Fatal().Err(err).Msg("config load failed")
	}

	// OpenTelemetry setup
	exp, oerr := otlptracehttp.New(context.Background())
	if oerr == nil {
		tp := sdktrace.NewTracerProvider(
			sdktrace.WithBatcher(exp),
			sdktrace.WithResource(resource.NewWithAttributes(
				semconv.SchemaURL,
				semconv.ServiceName("payment-service"),
			)),
		)
		otel.SetTracerProvider(tp)
		defer tp.Shutdown(context.Background())
	} else {
		log.Logger.Warn().Err(oerr).Msg("otel exporter init failed; continuing without tracing")
	}

	sc := sarama.NewConfig()
	sc.Version = sarama.MaxVersion
	sc.Consumer.Group.Rebalance.Strategy = sarama.BalanceStrategyRange
	sc.Consumer.Offsets.Initial = sarama.OffsetNewest
	sc.Net.DialTimeout = 5_000_000_000  // 5s
	sc.Net.ReadTimeout = 5_000_000_000  // 5s
	sc.Net.WriteTimeout = 5_000_000_000 // 5s

	group, err := sarama.NewConsumerGroup(cfg.Kafka.Brokers, cfg.Kafka.GroupID, sc)
	if err != nil {
		log.Logger.Fatal().Err(err).Msg("kafka consumer init failed")
	}
	defer group.Close()

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	go func() {
		for {
			if err := group.Consume(ctx, []string{cfg.Kafka.Topic}, orderConsumer{}); err != nil {
				log.Logger.Error().Err(err).Msg("consume error")
			}
			if ctx.Err() != nil {
				return
			}
		}
	}()

	// Metrics server
	consumeCounter := prometheus.NewCounter(prometheus.CounterOpts{Name: "orders_consumed_total", Help: "Total orders consumed"})
	prometheus.MustRegister(consumeCounter)
	go func() {
		mux := http.NewServeMux()
		mux.Handle("/metrics", promhttp.Handler())
		srv := &http.Server{Addr: ":9099", Handler: mux}
		log.Logger.Info().Msg("metrics listening on :9099")
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Logger.Error().Err(err).Msg("metrics server error")
		}
	}()

	log.Logger.Info().Strs("brokers", cfg.Kafka.Brokers).Str("group", cfg.Kafka.GroupID).Str("topic", cfg.Kafka.Topic).Msg("payment-service consuming")

	sigs := make(chan os.Signal, 1)
	signal.Notify(sigs, syscall.SIGINT, syscall.SIGTERM)
	<-sigs
	fmt.Println("shutdown")
}
