package main

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/prometheus/client_golang/prometheus"
	promhttp "github.com/prometheus/client_golang/prometheus/promhttp"
	"github.com/venkatesh/distrubtedfaulttorrentkafka/pkg/config"
	"github.com/venkatesh/distrubtedfaulttorrentkafka/pkg/events"
	"github.com/venkatesh/distrubtedfaulttorrentkafka/pkg/log"
	"github.com/venkatesh/distrubtedfaulttorrentkafka/pkg/rabbitmq"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracehttp"
	"go.opentelemetry.io/otel/sdk/resource"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	semconv "go.opentelemetry.io/otel/semconv/v1.26.0"
)

var tracer = otel.Tracer("order-service")

func main() {
	log.Init("order-service")
	cfg, err := config.Load()
	if err != nil {
		log.Logger.Fatal().Err(err).Msg("config load failed")
	}

	// OpenTelemetry setup (OTLP HTTP to collector if available)
	ctx := context.Background()
	exp, oerr := otlptracehttp.New(ctx)
	if oerr == nil {
		tp := sdktrace.NewTracerProvider(
			sdktrace.WithBatcher(exp),
			sdktrace.WithResource(resource.NewWithAttributes(
				semconv.SchemaURL,
				semconv.ServiceName("order-service"),
			)),
		)
		otel.SetTracerProvider(tp)
		defer tp.Shutdown(context.Background())
	} else {
		log.Logger.Warn().Err(oerr).Msg("otel exporter init failed; continuing without tracing")
	}

	rmq, err := rabbitmq.New(cfg.RabbitMQ.URL, cfg.RabbitMQ.Exchange, cfg.RabbitMQ.ExchangeType)
	if err != nil {
		log.Logger.Fatal().Err(err).Msg("rabbitmq init failed")
	}
	defer rmq.Close()

	// Ensure durable queue with DLX and bind
	_ = rmq.EnsureQueueWithDLX("orders.q", events.OrderCreated{}.RoutingKey(), "events.dlx")

	// Metrics
	publishCounter := prometheus.NewCounter(prometheus.CounterOpts{Name: "orders_published_total", Help: "Total orders published"})
	prometheus.MustRegister(publishCounter)

	http.HandleFunc("/create-order", func(w http.ResponseWriter, r *http.Request) {
		_, span := tracer.Start(r.Context(), "create-order")
		defer span.End()
		e := events.OrderCreated{
			ID:        time.Now().Format("20060102150405"),
			Amount:    99.95,
			Currency:  "USD",
			Customer:  "cust_123",
			CreatedAt: time.Now().UTC(),
		}
		if err := rmq.PublishJSON(cfg.RabbitMQ.Exchange, e.RoutingKey(), e); err != nil {
			log.Logger.Error().Err(err).Msg("publish failed")
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
		publishCounter.Inc()
		w.WriteHeader(http.StatusAccepted)
	})

	// Health/readiness
	ready := true
	http.HandleFunc("/healthz", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(http.StatusOK) })
	http.HandleFunc("/readyz", func(w http.ResponseWriter, r *http.Request) {
		if ready {
			w.WriteHeader(http.StatusOK)
		} else {
			w.WriteHeader(http.StatusServiceUnavailable)
		}
	})
	http.Handle("/metrics", promhttp.Handler())

	srv := &http.Server{Addr: ":" + fmt.Sprintf("%d", cfg.HTTP.Port), Handler: nil}
	log.Logger.Info().Int("port", cfg.HTTP.Port).Msg("order-service listening")
	go func() {
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Logger.Error().Err(err).Msg("server error")
		}
	}()
	sigs := make(chan os.Signal, 1)
	signal.Notify(sigs, syscall.SIGINT, syscall.SIGTERM)
	<-sigs
	ready = false
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_ = srv.Shutdown(ctx)
}
