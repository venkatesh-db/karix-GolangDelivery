package main

import "cobracalling/cmd"

func main() {
	cmd.Execute()
}
