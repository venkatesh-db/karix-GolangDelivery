package main

import (
	"log"
	"microservices-microservicescommunication/shared/db"
	"microservices-microservicescommunication/shared/kafka"
)

func main() {
	consumer, err := kafka.NewConsumer("localhost:9092", "transactions-group")
	if err != nil {
		log.Fatalf("Failed to create Kafka consumer: %v", err)
	}
	dbConn, err := db.Connect("postgresql://root@localhost:26257/fintech?sslmode=disable")
	if err != nil {
		log.Fatalf("Failed to connect to CockroachDB: %v", err)
	}
	topic := "transactions"

	err = consumer.ConsumeMessages(topic, func(message []byte) {
		log.Printf("Consumed message: %s", message)
		err := db.InsertTransaction(dbConn, message)
		if err != nil {
			log.Printf("Failed to insert transaction: %v", err)
		}
	})
	if err != nil {
		log.Fatalf("Failed to consume messages: %v", err)
	}
}
