package db

import (
	"context"
	"encoding/json"

	"github.com/jackc/pgx/v5"
)

type Transaction struct {
	TransactionID int     `json:"transaction_id"`
	Amount        float64 `json:"amount"`
	Status        string  `json:"status"`
}

func Connect(connString string) (*pgx.Conn, error) {
	return pgx.Connect(context.Background(), connString)
}

func InsertTransaction(conn *pgx.Conn, message []byte) error {
	var txn Transaction
	err := json.Unmarshal(message, &txn)
	if err != nil {
		return err
	}

	_, err = conn.Exec(context.Background(), `
		INSERT INTO transactions (id, amount, status)
		VALUES ($1, $2, $3)`, txn.TransactionID, txn.Amount, txn.Status)
	return err
}
