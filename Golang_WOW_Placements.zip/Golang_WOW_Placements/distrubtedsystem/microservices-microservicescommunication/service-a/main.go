package main

import (
	"log"
	"microservices-microservicescommunication/shared/kafka"
)

func main() {
	producer, err := kafka.NewProducer("localhost:9092")
	if err != nil {
		log.Fatalf("Failed to create Kafka producer: %v", err)
	}
	topic := "transactions"
	message := `{"transaction_id": 1, "amount": 100.0, "status": "pending"}`

	err = producer.ProduceMessage(topic, []byte(message))
	if err != nil {
		log.Fatalf("Failed to produce message: %v", err)
	}

	log.Println("Message produced successfully!")
}
