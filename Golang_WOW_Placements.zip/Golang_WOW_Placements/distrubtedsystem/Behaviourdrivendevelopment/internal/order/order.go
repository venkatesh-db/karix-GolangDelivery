package order

import (
	"context"
	"errors"
	"fmt"
)

var (
	// ErrMissingSKU indicates that an order SKU has not been provided.
	ErrMissingSKU = errors.New("sku cannot be empty")
	// ErrInvalidQuantity indicates that the requested quantity is not valid.
	ErrInvalidQuantity = errors.New("quantity must be positive")
	// ErrInvalidAmount indicates that the monetary value on the order is invalid.
	ErrInvalidAmount = errors.New("amount must be positive")
	// ErrMissingCurrency indicates that the currency code was not set.
	ErrMissingCurrency = errors.New("currency cannot be empty")
)

// Inventory represents the minimal behavior required from an inventory subsystem.
type Inventory interface {
	Reserve(ctx context.Context, sku string, quantity int) error
	Release(ctx context.Context, sku string, quantity int) error
}

// PaymentGateway captures the behavior of an external payment processor.
type PaymentGateway interface {
	Charge(ctx context.Context, request ChargeRequest) (ChargeReceipt, error)
}

// ChargeRequest represents what we need to send to a payment processor.
type ChargeRequest struct {
	AmountCents int
	Currency    string
	Reference   string
}

// ChargeReceipt is what the payment processor sends back for a successful charge.
type ChargeReceipt struct {
	AuthorizationCode string
	AmountCents       int
	Currency          string
}

// Order captures the required information to place an order.
type Order struct {
	SKU         string
	Quantity    int
	AmountCents int
	Currency    string
}

// OrderReceipt is what we return to callers when the order succeeds.
type OrderReceipt struct {
	OrderID string
	Charge  ChargeReceipt
}

// Validate performs small domain-level checks on the order payload.
func (o Order) Validate() error {
	if o.SKU == "" {
		return ErrMissingSKU
	}
	if o.Quantity <= 0 {
		return ErrInvalidQuantity
	}
	if o.AmountCents <= 0 {
		return ErrInvalidAmount
	}
	if o.Currency == "" {
		return ErrMissingCurrency
	}
	return nil
}

// OrderService orchestrates the flow between inventory reservations and payments.
type OrderService struct {
	inventory Inventory
	payment   PaymentGateway
}

// NewOrderService wires the dependencies together.
func NewOrderService(inventory Inventory, payment PaymentGateway) *OrderService {
	return &OrderService{inventory: inventory, payment: payment}
}

// PlaceOrder coordinates a reservation and payment charge to produce an order receipt.
func (s *OrderService) PlaceOrder(ctx context.Context, orderID string, order Order) (OrderReceipt, error) {
	if err := order.Validate(); err != nil {
		return OrderReceipt{}, err
	}

	if err := s.inventory.Reserve(ctx, order.SKU, order.Quantity); err != nil {
		return OrderReceipt{}, fmt.Errorf("reserve inventory: %w", err)
	}

	charge, err := s.payment.Charge(ctx, ChargeRequest{
		AmountCents: order.AmountCents,
		Currency:    order.Currency,
		Reference:   orderID,
	})
	if err != nil {
		_ = s.inventory.Release(ctx, order.SKU, order.Quantity)
		return OrderReceipt{}, fmt.Errorf("charge payment: %w", err)
	}

	return OrderReceipt{
		OrderID: orderID,
		Charge:  charge,
	}, nil
}
