package order_test

import (
	"context"
	"errors"

	"behaviourdrivendevelopment/internal/order"
	mockorder "behaviourdrivendevelopment/internal/order/mocks"

	"github.com/golang/mock/gomock"
	. "github.com/onsi/ginkgo/v2"
	. "github.com/onsi/gomega"
)

var _ = Describe("OrderService", func() {
	const orderID = "order-123"

	var (
		ctrl      *gomock.Controller
		inventory *mockorder.MockInventory
		payment   *mockorder.MockPaymentGateway
		service   *order.OrderService
		ctx       context.Context
		payload   order.Order
	)

	BeforeEach(func() {
		ctrl = gomock.NewController(GinkgoT())
		inventory = mockorder.NewMockInventory(ctrl)
		payment = mockorder.NewMockPaymentGateway(ctrl)
		service = order.NewOrderService(inventory, payment)
		ctx = context.Background()
		payload = order.Order{
			SKU:         "widget-01",
			Quantity:    2,
			AmountCents: 2599,
			Currency:    "USD",
		}
	})

	AfterEach(func() {
		ctrl.Finish()
	})

	When("inventory and payment succeed", func() {
		It("returns a populated receipt", func() {
			gomock.InOrder(
				inventory.EXPECT().Reserve(ctx, payload.SKU, payload.Quantity).Return(nil),
				payment.EXPECT().Charge(ctx, gomock.AssignableToTypeOf(order.ChargeRequest{})).
					DoAndReturn(func(_ context.Context, req order.ChargeRequest) (order.ChargeReceipt, error) {
						Expect(req.AmountCents).To(Equal(payload.AmountCents))
						Expect(req.Reference).To(Equal(orderID))
						return order.ChargeReceipt{
							AuthorizationCode: "AUTH-456",
							AmountCents:       req.AmountCents,
							Currency:          req.Currency,
						}, nil
					}),
			)

			receipt, err := service.PlaceOrder(ctx, orderID, payload)
			Expect(err).NotTo(HaveOccurred())
			Expect(receipt.OrderID).To(Equal(orderID))
			Expect(receipt.Charge.AuthorizationCode).To(Equal("AUTH-456"))
			Expect(receipt.Charge.AmountCents).To(Equal(payload.AmountCents))
		})
	})

	When("inventory cannot reserve items", func() {
		It("fails fast before charging the customer", func() {
			expectedErr := errors.New("inventory down")
			inventory.EXPECT().Reserve(ctx, payload.SKU, payload.Quantity).Return(expectedErr)

			receipt, err := service.PlaceOrder(ctx, orderID, payload)
			Expect(err).To(MatchError(ContainSubstring("reserve inventory")))
			Expect(errors.Is(err, expectedErr)).To(BeTrue())
			Expect(receipt).To(Equal(order.OrderReceipt{}))
		})
	})

	When("payment fails", func() {
		It("releases inventory and surfaces the failure", func() {
			expectedErr := errors.New("card declined")

			gomock.InOrder(
				inventory.EXPECT().Reserve(ctx, payload.SKU, payload.Quantity).Return(nil),
				payment.EXPECT().Charge(ctx, gomock.AssignableToTypeOf(order.ChargeRequest{})).
					Return(order.ChargeReceipt{}, expectedErr),
				inventory.EXPECT().Release(ctx, payload.SKU, payload.Quantity).Return(nil),
			)

			_, err := service.PlaceOrder(ctx, orderID, payload)
			Expect(err).To(MatchError(ContainSubstring("charge payment")))
		})
	})

	Describe("payload validation", func() {
		DescribeTable("rejects invalid payloads",
			func(modifier func(*order.Order), expected error) {
				modifier(&payload)
				_, err := service.PlaceOrder(ctx, orderID, payload)
				Expect(err).To(Equal(expected))
			},
			Entry("missing sku", func(o *order.Order) { o.SKU = "" }, order.ErrMissingSKU),
			Entry("zero quantity", func(o *order.Order) { o.Quantity = 0 }, order.ErrInvalidQuantity),
			Entry("negative amount", func(o *order.Order) { o.AmountCents = -5 }, order.ErrInvalidAmount),
			Entry("missing currency", func(o *order.Order) { o.Currency = "" }, order.ErrMissingCurrency),
		)
	})
})
