# Behaviour Driven Development with Ginkgo and GoMock

This minimal Go module showcases how to write Behavior-Driven Development (BDD) style tests with [Ginkgo v2](https://onsi.github.io/ginkgo/) and integrate [GoMock](https://github.com/golang/mock) to isolate dependencies.

## Layout

- `internal/order/order.go` – production code that models an order workflow and defines the interfaces we mock.
- `internal/order/mocks` – generated mocks for `Inventory` and `PaymentGateway` interfaces.
- `internal/order/order_test.go` – BDD-focused Ginkgo specs that demonstrate success, failure, and validation scenarios.
- `internal/order/suite_test.go` – Ginkgo bootstrap file.

## Running the specs

```bash
cd /Users/venkatesh/Golang\ WOW\ Placments/distrubtedsystem/Behaviourdrivendevelopment
go test ./...
```

Running `go test` automatically executes the Ginkgo specs because they are regular `*_test.go` files.

## Regenerating mocks

If you change the interfaces in `order.go`, regenerate the mocks:

```bash
go run github.com/golang/mock/mockgen \
  -destination internal/order/mocks/mock_dependencies.go \
  -package mocks \
  behaviourdrivendevelopment/internal/order \
  Inventory,PaymentGateway
```

> Tip: add the command to a `go:generate` directive or a Makefile for repeatability in larger projects.

## Highlights

- **BDD focus** – specs use `Describe/When/It` blocks and `DescribeTable` for validation edge cases.
- **Realistic orchestration** – the `OrderService` validates payloads, reserves inventory, charges payments, and compensates on failure.
- **Mocks for isolation** – GoMock expectations ensure every interaction is asserted, showcasing both happy and unhappy paths.

Use this repo as a starting point to bring BDD + mocking discipline into production-grade Go services.
