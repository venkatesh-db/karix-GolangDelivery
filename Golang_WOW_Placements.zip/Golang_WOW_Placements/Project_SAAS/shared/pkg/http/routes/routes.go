package routes

import (
	"net/http"

	"github.com/go-chi/chi/v5"
	"go.uber.org/zap"

	"project_saas/shared/pkg/config"
)

// ExampleHandler is a placeholder for an HTTP handler.
func ExampleHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Hello from routes!"))
}

// Register sets up the routes for the service.
func Register(r chi.Router, cfg config.ServiceConfig, log *zap.Logger) {
	r.Get("/example", ExampleHandler)
}
