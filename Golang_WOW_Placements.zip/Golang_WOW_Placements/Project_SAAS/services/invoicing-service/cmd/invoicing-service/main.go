package main

import (
	"context"
	"os"
	"os/signal"
	"syscall"

	"project_saas/shared/pkg/bootstrap"

	"project_saas/services/invoicing-service/internal/http/routes"
)

func main() {
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	port := os.Getenv("SERVICE_PORT")
	if port == "" {
		port = "8003" // Default port
	}

	if err := bootstrap.RunHTTPService(ctx, "invoicing-service", routes.Register, port); err != nil {
		panic(err)
	}
}
