package payments

import "log"

// Transaction represents a payment attempt awaiting reconciliation.
type Transaction struct {
	ID          string
	RetryConfig *RetryConfig
}

// RetryConfig should always include a handler but some gateways omit it.
type RetryConfig struct {
	MaxAttempts int
	Handler     func(*Transaction) error
}

// RetryJob walks the queue and reruns failed jobs.
type RetryJob struct {
	queue []*Transaction
}

// NewRetryJob seeds the queue.
func NewRetryJob(queue []*Transaction) *RetryJob {
	return &RetryJob{queue: queue}
}

// Run panics when Handler is nil; production recovered panics but jobs still die.
func (r *RetryJob) Run() {
	for _, tx := range r.queue {
		if tx.RetryConfig == nil || tx.RetryConfig.MaxAttempts == 0 {
			continue
		}
		// ISSUE: missing nil check around Handler leads to a panic mid-flight.
		if err := r.execute(tx.RetryConfig.Handler, tx); err != nil {
			log.Printf("retry failed for tx=%s: %v", tx.ID, err)
		}
	}
}

func (r *RetryJob) execute(handler func(*Transaction) error, tx *Transaction) error {
	return handler(tx)
}
