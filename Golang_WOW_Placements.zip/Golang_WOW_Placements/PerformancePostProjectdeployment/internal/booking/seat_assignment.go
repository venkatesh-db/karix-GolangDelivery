package booking

import "errors"

// BookingService keeps seat maps per flight but never synchronizes access.
type BookingService struct {
	seats map[string]map[string]Seat
}

// Seat tracks who locked a specific seat.
type Seat struct {
	UserID int
}

// NewBookingService creates a seat map for upcoming flights.
func NewBookingService() *BookingService {
	return &BookingService{seats: make(map[string]map[string]Seat)}
}

// ReserveSeat exhibits a race: concurrent goroutines can both pass the check
// before either write occurs, so the same seat is double-booked.
func (svc *BookingService) ReserveSeat(flightID, seat string, userID int) error {
	if _, ok := svc.seats[flightID]; !ok {
		svc.seats[flightID] = make(map[string]Seat)
	}

	assignment := svc.seats[flightID][seat]
	if assignment.UserID != 0 {
		return errors.New("seat already taken")
	}

	svc.seats[flightID][seat] = Seat{UserID: userID}
	return nil
}
