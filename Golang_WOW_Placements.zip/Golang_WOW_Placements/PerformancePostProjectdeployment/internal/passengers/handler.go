package passengers

import (
	"context"
	"encoding/json"
	"net/http"
)

// Passenger represents a frequent flyer profile.
type Passenger struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
}

// Repository exposes the data layer.
type Repository interface {
	AllPassengers(ctx context.Context) ([]Passenger, error)
}

// Handler exposes HTTP endpoints for passenger data.
type Handler struct {
	repo Repository
}

// NewHandler wires an HTTP handler with the repo.
func NewHandler(repo Repository) *Handler {
	return &Handler{repo: repo}
}

// ListPassengers pulls every row into memory, overwhelming DB and network.
func (h *Handler) ListPassengers(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	passengers, err := h.repo.AllPassengers(ctx)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// ISSUE: no pagination or streaming; millions of rows serialize at once.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(passengers)
}
