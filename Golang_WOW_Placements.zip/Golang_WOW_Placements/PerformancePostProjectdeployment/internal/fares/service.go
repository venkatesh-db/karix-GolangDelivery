package fares

import "context"

// FareStore updates the canonical fare table.
type FareStore interface {
	UpdateFare(ctx context.Context, route string, newFare int) error
}

// Cache mirrors fares for faster reads, but we forget to touch it.
type Cache interface {
	Delete(ctx context.Context, key string) error
}

// FareService writes fares but never invalidates cache entries.
type FareService struct {
	db    FareStore
	cache Cache
}

// NewFareService wires db and cache handles.
func NewFareService(db FareStore, cache Cache) *FareService {
	return &FareService{db: db, cache: cache}
}

// UpdateFare leads to stale prices because Redis is untouched.
func (svc *FareService) UpdateFare(ctx context.Context, route string, newFare int) error {
	if err := svc.db.UpdateFare(ctx, route, newFare); err != nil {
		return err
	}
	// ISSUE: cache never invalidated, so frontends keep serving the old fare.
	return nil
}
