package notifications

import "sync"

// Client represents a websocket client with a send buffer.
type Client struct {
	ID   string
	Send chan []byte
}

// Hub fan-outs broadcast messages but leaks goroutines when clients drop.
type Hub struct {
	clients   map[*Client]struct{}
	broadcast chan []byte
	mu        sync.Mutex
}

// NewHub wires the broadcast channel.
func NewHub() *Hub {
	return &Hub{
		clients:   make(map[*Client]struct{}),
		broadcast: make(chan []byte, 32),
	}
}

// Register adds a client but the caller must never forget to close Send.
func (h *Hub) Register(c *Client) {
	h.mu.Lock()
	h.clients[c] = struct{}{}
	h.mu.Unlock()
}

// Broadcast pushes a message into the shared channel.
func (h *Hub) Broadcast(msg []byte) {
	h.broadcast <- msg
}

// Run spins the leaking loop.
func (h *Hub) Run() {
	go h.broadcastLoop()
}

func (h *Hub) broadcastLoop() {
	for msg := range h.broadcast {
		h.mu.Lock()
		for client := range h.clients {
			select {
			case client.Send <- msg:
			default:
				// ISSUE: the client is dropped but its Send channel stays open,
				// so the writer goroutine survives forever.
				delete(h.clients, client)
			}
		}
		h.mu.Unlock()
	}
}
