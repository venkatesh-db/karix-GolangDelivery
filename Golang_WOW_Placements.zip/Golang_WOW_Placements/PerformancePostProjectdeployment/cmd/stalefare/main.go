package main

import (
	"context"
	"fmt"

	"performancepostprojectdeployment/internal/fares"
)

type stubStore struct{}

func (stubStore) UpdateFare(context.Context, string, int) error { return nil }

type recordingCache struct {
	deletes int
}

func (rc *recordingCache) Delete(context.Context, string) error {
	rc.deletes++
	return nil
}

func main() {
	cache := &recordingCache{}
	svc := fares.NewFareService(stubStore{}, cache)
	_ = svc.UpdateFare(context.Background(), "BLR-DEL", 8200)

	fmt.Printf("cache invalidations=%d\n", cache.deletes)
}
