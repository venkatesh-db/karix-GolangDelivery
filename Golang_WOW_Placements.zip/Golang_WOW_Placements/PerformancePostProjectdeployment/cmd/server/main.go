package main

import (
	"context"
	"log"
	"net/http"
	"time"

	"performancepostprojectdeployment/internal/booking"
	"performancepostprojectdeployment/internal/fares"
	"performancepostprojectdeployment/internal/notifications"
	"performancepostprojectdeployment/internal/passengers"
	"performancepostprojectdeployment/internal/payments"
)

func main() {
	bookingSvc := booking.NewBookingService()
	go simulateSeatRace(bookingSvc)

	hub := notifications.NewHub()
	hub.Run()
	hub.Register(&notifications.Client{ID: "ops-console", Send: make(chan []byte, 1)})
	hub.Broadcast([]byte("initial broadcast"))

	retryJob := payments.NewRetryJob([]*payments.Transaction{
		{ID: "TX123", RetryConfig: &payments.RetryConfig{MaxAttempts: 3}},
	})
	go safeRun(retryJob)

	passengerHandler := passengers.NewHandler(&staticPassengerRepo{})
	http.HandleFunc("/passengers", passengerHandler.ListPassengers)

	fareSvc := fares.NewFareService(&noopFareStore{}, &noopCache{})
	if err := fareSvc.UpdateFare(context.Background(), "BLR-DEL", 7500); err != nil {
		log.Printf("fare update failed: %v", err)
	}

	log.Println("server listening on :8080 with intentional deployment issues")
	log.Fatal(http.ListenAndServe(":8080", nil))
}

func simulateSeatRace(svc *booking.BookingService) {
	for i := 0; i < 2; i++ {
		go func(user int) {
			for {
				_ = svc.ReserveSeat("AI-202", "12A", user)
				time.Sleep(10 * time.Millisecond)
			}
		}(i + 1)
	}
}

func safeRun(job *payments.RetryJob) {
	defer func() {
		if r := recover(); r != nil {
			log.Printf("panic recovered in retry job: %v", r)
		}
	}()
	job.Run()
}

type staticPassengerRepo struct{}

func (r *staticPassengerRepo) AllPassengers(ctx context.Context) ([]passengers.Passenger, error) {
	const size = 1_000_000
	result := make([]passengers.Passenger, 0, size)
	for i := 0; i < size; i++ {
		result = append(result, passengers.Passenger{ID: i + 1, Name: "Passenger"})
	}
	return result, nil
}

type noopFareStore struct{}

func (noopFareStore) UpdateFare(ctx context.Context, route string, newFare int) error {
	return nil
}

type noopCache struct{}

func (noopCache) Delete(ctx context.Context, key string) error { return nil }
