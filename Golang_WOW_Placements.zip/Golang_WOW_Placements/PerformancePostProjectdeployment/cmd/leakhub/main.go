package main

import (
	"fmt"
	"time"

	"performancepostprojectdeployment/internal/notifications"
)

func main() {
	hub := notifications.NewHub()
	hub.Run()

	done := make(chan struct{})
	client := &notifications.Client{ID: "slow", Send: make(chan []byte, 1)}
	go func() {
		for range client.Send {
			time.Sleep(10 * time.Millisecond)
		}
		close(done)
	}()

	hub.Register(client)
	hub.Broadcast([]byte("first"))
	hub.Broadcast([]byte("second"))

	select {
	case <-done:
		fmt.Println("writer goroutine exited")
	case <-time.After(200 * time.Millisecond):
		fmt.Println("writer goroutine leaked: send channel never closed")
	}
}
