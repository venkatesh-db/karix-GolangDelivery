#!/usr/bin/env zsh
set -euo pipefail

repo_root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$repo_root"

print_section() {
  echo "\n==== $1 ===="
}

# 1) Seat race
print_section "Seat Race (double booking)"
mkdir -p "$repo_root/logs/race" "$repo_root/logs/panic" "$repo_root/logs/passengers" "$repo_root/logs/leakhub" "$repo_root/logs/stalefare"

if go run -race ./cmd/server > "$repo_root/logs/race/run.log" 2>&1 & then
  pid=$!
  sleep 5
  kill $pid || true
  wait $pid 2>/dev/null || true
  if grep -q "WARNING: DATA RACE" "$repo_root/logs/race/run.log"; then
    echo "Detected data race in seat assignment"
    grep -n "seat_assignment.go" "$repo_root/logs/race/run.log" | head -n 2 || true
  else
    echo "Race not detected (try increasing runtime)"
  fi
else
  echo "Failed to start server with -race"
fi

# 2) Payment retry panic
print_section "Payment Retry Panic"
if go run ./cmd/server > "$repo_root/logs/panic/run.log" 2>&1 & then
  pid=$!
  sleep 1
  kill $pid || true
  wait $pid 2>/dev/null || true
  grep -n "panic recovered in retry job" "$repo_root/logs/panic/run.log" || echo "Panic log not found"
else
  echo "Failed to start server"
fi

# 3) Runaway passenger export
print_section "Passenger Export (oversized payload)"
if go run ./cmd/server > "$repo_root/logs/passengers/server.log" 2>&1 & then
  pid=$!
  sleep 1
  size=$(curl -s -o "$repo_root/logs/passengers/response.json" -w 'downloaded_bytes=%{size_download}\n' http://localhost:8080/passengers || echo 0)
  echo "Payload size bytes=$size"
  kill $pid || true
  wait $pid 2>/dev/null || true
else
  echo "Failed to start server for passengers endpoint"
fi

# 4) Notification hub leak
print_section "Notification Hub Leak"
output=$(go run ./cmd/leakhub 2>&1 || true)
echo "$output" | tail -n 1 | tee "$repo_root/logs/leakhub/run.log" >/dev/null

# 5) Stale fare cache
print_section "Stale Fare Cache"
output=$(go run ./cmd/stalefare 2>&1 || true)
echo "$output" | tail -n 1 | tee "$repo_root/logs/stalefare/run.log" >/dev/null

echo "\nAll demos executed. Logs saved under $repo_root/logs/*"