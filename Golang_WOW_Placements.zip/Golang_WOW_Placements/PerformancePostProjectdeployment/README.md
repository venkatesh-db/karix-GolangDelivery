# 50 Cr Airlines Post-Deployment Issues (Go Simulation)

This minimal Go workspace models five realistic post-deployment failures that often surface once a large-scale airline platform reaches production. Each issue has concrete code you can run or inspect to reproduce the behavior.

## Project Layout

```
.
├── cmd/server/main.go                 # Wires all issue scenarios together
├── internal/booking/seat_assignment.go # Race during seat reservation
├── internal/notifications/hub.go       # WebSocket hub leaks goroutines
├── internal/payments/retry.go          # Panic from nil retry handler
├── internal/passengers/handler.go      # Unbounded passenger export
├── internal/fares/service.go           # Stale fare cache
└── go.mod
```

## Simulated Production Failures

1. **Double Booked Seats (`internal/booking/seat_assignment.go`)**  
   `ReserveSeat` never locks the seat map. Concurrent goroutines in `simulateSeatRace` hit the same seat and intermittently overwrite each other.

2. **Leaking Notification Hub (`internal/notifications/hub.go`)**  
   The broadcast loop drops slow clients without closing their `Send` channels. The goroutines that flush those channels stay alive forever, slowly exhausting memory.

3. **Payment Retry Panic (`internal/payments/retry.go`)**  
   A subset of gateway integrations enqueue transactions without a `RetryConfig.Handler`. The retry worker blindly invokes `nil`, triggering sporadic panics recovered in `safeRun` but still skipping retries.

4. **Runaway Passenger Export (`internal/passengers/handler.go`)**  
   `ListPassengers` loads and serializes the entire passenger table (one million fake rows via `staticPassengerRepo`). Reporting dashboards that call this endpoint overwhelm both the DB and the API pod.

5. **Stale Fare Cache (`internal/fares/service.go`)**  
   `UpdateFare` writes to the primary store but never invalidates Redis. Front-end callers continue to read old fares until a separate TTL evicts the entry, causing pricing disputes.

## Reproducing Every Issue

All commands assume you are in the workspace root.

1. **Seat race (double booking)**  
   ```sh
   go run -race ./cmd/server
   ```
   Stop after a few seconds (`Ctrl+C`). The race detector logs warnings such as `seat_assignment.go:24` proving two goroutines write the same seat concurrently.

2. **Payment retry panic**  
   ```sh
   go run ./cmd/server
   ```
   On startup the worker prints `panic recovered in retry job: runtime error: invalid memory address or nil pointer dereference` because a transaction lacks a handler.

3. **Runaway passenger export**  
   With the server from step 2 running, burst the passengers endpoint:
   ```sh
   curl -s -o /tmp/passengers.json -w 'downloaded_bytes=%{size_download}\n' http://localhost:8080/passengers
   ```
   Expected output: `downloaded_bytes=32888898`, showing ~33 MB serialized in one response. Stop the server afterward.

4. **Leaking notification hub**  
   ```sh
   go run ./cmd/leakhub
   ```
   The helper program drops a slow client; because `Send` is never closed you see `writer goroutine leaked: send channel never closed`. Log saved to `logs/leakhub/run.log`.

5. **Stale fare cache**  
   ```sh
   go run ./cmd/stalefare
   ```
   `cache invalidations=0` proves `FareService.UpdateFare` touches the database but never deletes cache entries. Log saved to `logs/stalefare/run.log`.

### Run all and collect logs

```sh
chmod +x scripts/run_all_issues.sh
./scripts/run_all_issues.sh
```

Logs are saved under `logs/`:
- `logs/race/run.log` – race detector output
- `logs/panic/run.log` – payment panic recovery
- `logs/passengers/server.log` – server log; `logs/passengers/response.json` – payload
- `logs/leakhub/run.log` – leak demo output
- `logs/stalefare/run.log` – stale cache demo output

Each repro stays within ~20 lines of code per issue so you can scan, run, and discuss mitigations (locks, lifecycle hooks, pagination, cache invalidation, and defensive config validation) before implementing fixes.
