# Testing Benchmarks Go Project

This repository demonstrates comprehensive testing techniques for Go services, including:

- Test-Driven Development (TDD) for business logic
- Table-driven unit tests and subtests
- Benchmark tests for hot paths
- HTTP handler testing via `httptest`
- Manual interface mocking
- Mock generation with GoMock

## Project Layout

```
cmd/server              # Minimal HTTP server wiring
pkg/models              # Domain models and validation helpers
pkg/repository          # Repository interfaces + in-memory implementation
pkg/service             # Business logic, unit tests, benchmarks, mocks
pkg/handlers            # HTTP handler + tests
pkg/mocks               # Manual mock + GoMock generated mocks
```

## Getting Started

```bash
# Run unit tests, HTTP tests, manual mocks, and GoMock suites
go test ./...

# Run only benchmarks
go test ./pkg/service -bench . -run Benchmark

# Start the demo HTTP server
cd cmd/server
go run .
```

## Benchmark Performance

To measure allocation counts and timings for the hottest paths run:

```bash
go test ./pkg/service -bench . -benchmem
```

Sample output on an Apple M1 Pro:

```
BenchmarkUserService_CreateUser-8   	223218	  5501 ns/op	6669 B/op	78 allocs/op
BenchmarkHashPassword-8           	7806591	   150.5 ns/op	 128 B/op	 2 allocs/op
```

## GoMock Workflow

1. Install the tool (already done in `go.mod`):
   ```bash
   go install github.com/golang/mock/mockgen@latest
   ```
2. Regenerate mocks when interfaces change:
   ```bash
   mockgen -destination=pkg/mocks/mock_user_repository.go -package=mocks testing-benchmarks/pkg/repository UserRepository
   ```

## Highlights

- `pkg/service/user_service_test.go`: TDD-style unit tests covering validation, CRUD, and helpers.
- `pkg/service/user_service_benchmark_test.go`: Benchmarks for user creation and password hashing.
- `pkg/handlers/user_handler_test.go`: Full HTTP coverage using `httptest` recorders.
- `pkg/mocks/manual_user_repository.go`: Hand-written mock pattern for small projects.
- `pkg/service/user_service_manual_mock_test.go`: Manual mock usage example.
- `pkg/service/user_service_gomock_test.go`: Demonstrates GoMock expectations and assertions.

This structure can be used as a reference project for coaching teams on Go testing best practices.
