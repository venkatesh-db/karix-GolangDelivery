package handlers

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strconv"
	"testing"

	"testing-benchmarks/pkg/repository"
	"testing-benchmarks/pkg/service"
)

func setupTestServer() (*http.ServeMux, *service.UserService) {
	repo := repository.NewInMemoryUserRepository()
	userService := service.NewUserService(repo)
	handler := NewUserHandler(userService)

	mux := http.NewServeMux()
	handler.RegisterRoutes(mux)

	return mux, userService
}

func TestUserHandler_CreateUser(t *testing.T) {
	mux, _ := setupTestServer()

	payload := map[string]string{
		"username": "john",
		"email":    "john@example.com",
		"password": "password123",
	}
	body, _ := json.Marshal(payload)

	req := httptest.NewRequest(http.MethodPost, "/users", bytes.NewReader(body))
	rec := httptest.NewRecorder()

	mux.ServeHTTP(rec, req)

	if rec.Code != http.StatusCreated {
		t.Fatalf("expected status 201, got %d", rec.Code)
	}
}

func TestUserHandler_GetUser(t *testing.T) {
	mux, svc := setupTestServer()

	created, err := svc.CreateUser("john", "john@example.com", "password123")
	if err != nil {
		t.Fatalf("setup failed: %v", err)
	}

	req := httptest.NewRequest(http.MethodGet, "/users/"+strconv.Itoa(created.ID), nil)
	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("expected status 200, got %d", rec.Code)
	}

	req = httptest.NewRequest(http.MethodGet, "/users/999", nil)
	rec = httptest.NewRecorder()
	mux.ServeHTTP(rec, req)

	if rec.Code != http.StatusNotFound {
		t.Fatalf("expected status 404 for missing user, got %d", rec.Code)
	}
}

func TestUserHandler_ListUsers(t *testing.T) {
	mux, svc := setupTestServer()

	_, _ = svc.CreateUser("john", "john@example.com", "password123")

	req := httptest.NewRequest(http.MethodGet, "/users", nil)
	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("expected status 200, got %d", rec.Code)
	}
}
