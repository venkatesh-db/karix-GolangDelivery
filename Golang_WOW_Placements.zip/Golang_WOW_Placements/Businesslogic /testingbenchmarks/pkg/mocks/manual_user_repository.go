package mocks

import (
	"testing-benchmarks/pkg/models"
	"testing-benchmarks/pkg/repository"
)

// ManualUserRepositoryMock is a hand-written mock implementation used for teaching manual mocking.
type ManualUserRepositoryMock struct {
	CreateFunc     func(user *models.User) error
	GetByIDFunc    func(id int) (*models.User, error)
	GetByEmailFunc func(email string) (*models.User, error)
	UpdateFunc     func(user *models.User) error
	DeleteFunc     func(id int) error
	ListFunc       func() ([]*models.User, error)
}

var _ repository.UserRepository = (*ManualUserRepositoryMock)(nil)

func (m *ManualUserRepositoryMock) Create(user *models.User) error {
	if m.CreateFunc != nil {
		return m.CreateFunc(user)
	}
	return nil
}

func (m *ManualUserRepositoryMock) GetByID(id int) (*models.User, error) {
	if m.GetByIDFunc != nil {
		return m.GetByIDFunc(id)
	}
	return nil, repository.ErrUserNotFound
}

func (m *ManualUserRepositoryMock) GetByEmail(email string) (*models.User, error) {
	if m.GetByEmailFunc != nil {
		return m.GetByEmailFunc(email)
	}
	return nil, repository.ErrUserNotFound
}

func (m *ManualUserRepositoryMock) Update(user *models.User) error {
	if m.UpdateFunc != nil {
		return m.UpdateFunc(user)
	}
	return nil
}

func (m *ManualUserRepositoryMock) Delete(id int) error {
	if m.DeleteFunc != nil {
		return m.DeleteFunc(id)
	}
	return nil
}

func (m *ManualUserRepositoryMock) List() ([]*models.User, error) {
	if m.ListFunc != nil {
		return m.ListFunc()
	}
	return []*models.User{}, nil
}
