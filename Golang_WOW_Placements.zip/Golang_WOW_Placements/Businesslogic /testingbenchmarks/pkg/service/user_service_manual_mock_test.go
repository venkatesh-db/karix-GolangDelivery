package service

import (
	"testing"

	"testing-benchmarks/pkg/mocks"
	"testing-benchmarks/pkg/models"
)

func TestUserService_CreateUser_ManualMock(t *testing.T) {
	mockRepo := &mocks.ManualUserRepositoryMock{}
	called := false
	mockRepo.CreateFunc = func(user *models.User) error {
		called = true
		if user.Password == "password123" {
			t.Fatalf("expected password to be hashed before persisting")
		}
		return nil
	}

	svc := NewUserService(mockRepo)

	_, err := svc.CreateUser("john", "john@example.com", "password123")
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}

	if !called {
		t.Fatalf("expected Create to be called on repository")
	}
}
