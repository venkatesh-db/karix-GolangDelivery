package service

import (
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"testing-benchmarks/pkg/models"
	"testing-benchmarks/pkg/repository"
)

var (
	ErrInvalidInput = errors.New("invalid input data")
)

// UserService provides business logic for user operations
type UserService struct {
	repo repository.UserRepository
}

// NewUserService creates a new user service
func NewUserService(repo repository.UserRepository) *UserService {
	return &UserService{
		repo: repo,
	}
}

// CreateUser creates a new user with validation
func (s *UserService) CreateUser(username, email, password string) (*models.User, error) {
	// Validate input
	if err := models.ValidateUsername(username); err != nil {
		return nil, err
	}

	if err := models.ValidateEmail(email); err != nil {
		return nil, err
	}

	if err := models.ValidatePassword(password); err != nil {
		return nil, err
	}

	// Hash password
	hashedPassword := HashPassword(password)

	user := &models.User{
		Username: username,
		Email:    email,
		Password: hashedPassword,
	}

	if err := s.repo.Create(user); err != nil {
		return nil, err
	}

	return user, nil
}

// GetUser retrieves a user by ID
func (s *UserService) GetUser(id int) (*models.User, error) {
	return s.repo.GetByID(id)
}

// GetUserByEmail retrieves a user by email
func (s *UserService) GetUserByEmail(email string) (*models.User, error) {
	if err := models.ValidateEmail(email); err != nil {
		return nil, err
	}
	return s.repo.GetByEmail(email)
}

// UpdateUser updates user information
func (s *UserService) UpdateUser(id int, username, email string) (*models.User, error) {
	user, err := s.repo.GetByID(id)
	if err != nil {
		return nil, err
	}

	if username != "" {
		if err := models.ValidateUsername(username); err != nil {
			return nil, err
		}
		user.Username = username
	}

	if email != "" {
		if err := models.ValidateEmail(email); err != nil {
			return nil, err
		}
		user.Email = email
	}

	if err := s.repo.Update(user); err != nil {
		return nil, err
	}

	return user, nil
}

// DeleteUser removes a user
func (s *UserService) DeleteUser(id int) error {
	return s.repo.Delete(id)
}

// ListUsers returns all users
func (s *UserService) ListUsers() ([]*models.User, error) {
	return s.repo.List()
}

// HashPassword hashes a password using SHA-256
func HashPassword(password string) string {
	hash := sha256.Sum256([]byte(password))
	return hex.EncodeToString(hash[:])
}

// VerifyPassword checks if a password matches the hash
func VerifyPassword(password, hashedPassword string) bool {
	return HashPassword(password) == hashedPassword
}
