package service

import (
	"testing"

	"github.com/golang/mock/gomock"

	"testing-benchmarks/pkg/mocks"
	"testing-benchmarks/pkg/models"
)

func TestUserService_CreateUser_GoMock(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	mockRepo := mocks.NewMockUserRepository(ctrl)
	svc := NewUserService(mockRepo)

	mockRepo.EXPECT().Create(gomock.Any()).DoAndReturn(func(user *models.User) error {
		if user.Password == "password123" {
			t.Fatalf("expected password to be hashed before persisting")
		}
		return nil
	})

	_, err := svc.CreateUser("john", "john@example.com", "password123")
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}
}

func TestUserService_DeleteUser_GoMock(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	mockRepo := mocks.NewMockUserRepository(ctrl)
	svc := NewUserService(mockRepo)

	mockRepo.EXPECT().Delete(1).Return(nil)

	if err := svc.DeleteUser(1); err != nil {
		t.Fatalf("expected no error, got %v", err)
	}
}
