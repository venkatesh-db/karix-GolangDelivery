package service

import (
	"errors"
	"testing"

	"testing-benchmarks/pkg/repository"
)

func newTestService() *UserService {
	return NewUserService(repository.NewInMemoryUserRepository())
}

func TestUserService_CreateUser(t *testing.T) {
	t.Run("valid user", func(t *testing.T) {
		service := newTestService()
		user, err := service.CreateUser("john", "john@example.com", "password123")
		if err != nil {
			t.Fatalf("expected no error, got %v", err)
		}

		if user.ID == 0 {
			t.Fatalf("expected user ID to be set")
		}
	})

	t.Run("duplicate email", func(t *testing.T) {
		service := newTestService()
		_, err := service.CreateUser("john", "john@example.com", "password123")
		if err != nil {
			t.Fatalf("setup failed: %v", err)
		}

		_, err = service.CreateUser("john2", "john@example.com", "password321")
		if !errors.Is(err, repository.ErrUserAlreadyExists) {
			t.Fatalf("expected ErrUserAlreadyExists, got %v", err)
		}
	})

	t.Run("invalid email", func(t *testing.T) {
		service := newTestService()
		_, err := service.CreateUser("john", "invalid-email", "password123")
		if err == nil {
			t.Fatalf("expected error for invalid email")
		}
	})
}

func TestUserService_GetUser(t *testing.T) {
	service := newTestService()

	created, err := service.CreateUser("john", "john@example.com", "password123")
	if err != nil {
		t.Fatalf("setup failed: %v", err)
	}

	t.Run("existing user", func(t *testing.T) {
		user, err := service.GetUser(created.ID)
		if err != nil {
			t.Fatalf("expected no error, got %v", err)
		}

		if user.Username != "john" {
			t.Fatalf("expected username 'john', got %s", user.Username)
		}
	})

	t.Run("non-existent user", func(t *testing.T) {
		_, err := service.GetUser(999)
		if err == nil {
			t.Fatalf("expected error for non-existent user")
		}
	})
}

func TestUserService_UpdateUser(t *testing.T) {
	service := newTestService()

	created, err := service.CreateUser("john", "john@example.com", "password123")
	if err != nil {
		t.Fatalf("setup failed: %v", err)
	}

	updated, err := service.UpdateUser(created.ID, "johnny", "johnny@example.com")
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}

	if updated.Username != "johnny" {
		t.Fatalf("expected username 'johnny', got %s", updated.Username)
	}

	if updated.Email != "johnny@example.com" {
		t.Fatalf("expected email 'johnny@example.com', got %s", updated.Email)
	}
}

func TestHashPassword(t *testing.T) {
	password := "password123"
	hashed := HashPassword(password)
	if len(hashed) == 0 {
		t.Fatalf("expected hashed password")
	}

	if !VerifyPassword(password, hashed) {
		t.Fatalf("expected password to verify")
	}

	if VerifyPassword("wrong", hashed) {
		t.Fatalf("expected verification to fail for wrong password")
	}
}
