package service

import (
	"fmt"
	"testing"

	"testing-benchmarks/pkg/repository"
)

func BenchmarkUserService_CreateUser(b *testing.B) {
	for i := 0; i < b.N; i++ {
		repo := repository.NewInMemoryUserRepository()
		service := NewUserService(repo)
		_, err := service.CreateUser(
			fmt.Sprintf("user-%d", i),
			fmt.Sprintf("user-%d@example.com", i),
			"password123",
		)
		if err != nil {
			b.Fatalf("unexpected error: %v", err)
		}
	}
}

func BenchmarkHashPassword(b *testing.B) {
	for i := 0; i < b.N; i++ {
		_ = HashPassword("password123")
	}
}
