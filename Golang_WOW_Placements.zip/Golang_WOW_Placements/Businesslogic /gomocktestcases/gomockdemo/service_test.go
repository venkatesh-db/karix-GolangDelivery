package gomockdemo_test

import (
	"testing"

	"gomockdemo"
	"gomockdemo/mocks"

	"github.com/golang/mock/gomock"
)

func TestWelcome(t *testing.T) {

	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	mockRepo := mocks.NewMockUserRepo(ctrl)

	// EXPECT: service will call GetName(1)
	mockRepo.EXPECT().GetName(2).Return("Venkatesh1")

	svc := gomockdemo.UserService{Repo: mockRepo}

	result := svc.Welcome(2)

	if result != "Hello Venkatesh1" {
		t.Fatalf("expected Hello Venkatesh, got %s", result)
	}
}
