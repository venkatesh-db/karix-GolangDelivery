package gomockdemo

type UserRepo interface {
	GetName(id int) string
}

type UserService struct {
	Repo UserRepo
}

func (s *UserService) Welcome(id int) string {
	return "Hello " + s.Repo.GetName(id)
}

/*

mockgen -source=service.go -destination=mocks/mock_userrepo.go -package=mocks

*/
