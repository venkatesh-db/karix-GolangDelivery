
package main

import ( 
	   "fmt"
       "log"
	   "gorm.io/driver/mysql"
       "gorm.io/gorm"
	)

	


func main() {
	
}
