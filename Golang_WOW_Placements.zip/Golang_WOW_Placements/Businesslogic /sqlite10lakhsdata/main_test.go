package main

import (
	"context"
	"database/sql"
	"io"
	"log"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestSqliteDSN(t *testing.T) {
	path := filepath.Join(t.TempDir(), "bench.db")
	dsn := sqliteDSN(path)
	if !strings.HasPrefix(dsn, "file:") {
		t.Fatalf("expected file: prefix, got %s", dsn)
	}
	if !strings.Contains(dsn, path) {
		t.Fatalf("dsn missing path: %s", dsn)
	}
}

func TestApplyOptimPragmas(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	db, cleanup := openTempDB(t)
	defer cleanup()

	applyOptimPragmas(ctx, db)

	var mode string
	if err := db.QueryRowContext(ctx, "PRAGMA journal_mode").Scan(&mode); err != nil {
		t.Fatalf("fetch journal_mode: %v", err)
	}
	if !strings.EqualFold(mode, "wal") {
		t.Fatalf("journal_mode not WAL: %s", mode)
	}
}

func TestRunOptimized(t *testing.T) {

	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	reset := muteLogs(t)
	defer reset()
	db, cleanup := openTempDB(t)
	defer cleanup()

	if err := runOptimized(ctx, db, 200, 50, false, false); err != nil {
		t.Fatalf("runOptimized failed: %v", err)
	}
	
}

func TestRunUnoptimized(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	reset := muteLogs(t)
	defer reset()
	db, cleanup := openTempDB(t)
	defer cleanup()

	if err := runUnoptimized(ctx, db, 120, false); err != nil {
		t.Fatalf("runUnoptimized failed: %v", err)
	}
}

func BenchmarkInsertPaths(b *testing.B) {
	cases := []struct {
		name string
		run  func(context.Context, *sql.DB) error
	}{
		{
			name: "Optimized",
			run: func(ctx context.Context, db *sql.DB) error {
				return runOptimized(ctx, db, 300, 75, false, false)
			},
		},
		{
			name: "Unoptimized",
			run: func(ctx context.Context, db *sql.DB) error {
				return runUnoptimized(ctx, db, 150, false)
			},
		},
	}

	for _, tc := range cases {
		b.Run(tc.name, func(b *testing.B) {
			reset := muteLogs(b)
			defer reset()
			for i := 0; i < b.N; i++ {
				db, cleanup := openTempDB(b)
				ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
				if err := tc.run(ctx, db); err != nil {
					cancel()
					cleanup()
					b.Fatalf("%s failed: %v", tc.name, err)
				}
				cancel()
				cleanup()
			}
		})
	}
}

func openTempDB(tb testing.TB) (*sql.DB, func()) {
	tb.Helper()
	path := filepath.Join(tb.TempDir(), "temp.db")
	db, err := sql.Open("sqlite", sqliteDSN(path))
	if err != nil {
		tb.Fatalf("open temp db: %v", err)
	}
	db.SetMaxOpenConns(1)
	db.SetMaxIdleConns(1)
	db.SetConnMaxLifetime(0)
	cleanup := func() { _ = db.Close() }
	return db, cleanup
}

func muteLogs(tb testing.TB) func() {
	tb.Helper()
	prevWriter := log.Writer()
	prevFlags := log.Flags()
	prevPrefix := log.Prefix()
	log.SetOutput(io.Discard)
	return func() {
		log.SetOutput(prevWriter)
		log.SetFlags(prevFlags)
		log.SetPrefix(prevPrefix)
	}
}
