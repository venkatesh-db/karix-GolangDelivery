package jamonbatch

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gin-gonic/gin"
)

type User struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
	Age  int    `json:"age"`
}

func GetUSer(w http.ResponseWriter, r *http.Request) {

	smiles := User{ID: 1, Name: "Jamon", Age: 25}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(smiles)

}

func TestPing(t *testing.T) {

	http.HandleFunc("/user", GetUSer)
	http.ListenAndServe(":8080", nil)

	w := httptest.NewRecorder()
	req, _ := http.NewRequest("GET", "/ping", nil)

	GetUSer(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("Expected status code %d but got %d", http.StatusOK, w.Code)
	}

	expectedBody := `{"id":1,"name":"Jamon","age":25}`

	if strings.TrimSpace(w.Body.String()) != expectedBody {
		t.Fatalf("Expected %s, got %s", expectedBody, w.Body.String())
	}

}

func BenchmarkPing(b *testing.B) {

	r := gin.Default()

	// FIX: Register route
	r.GET("/ping", func(c *gin.Context) {
		c.String(200, "pong")
	})

	w := httptest.NewRecorder()

	req, _ := http.NewRequest("GET", "/ping", nil)

	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		r.ServeHTTP(w, req)
	}

}
