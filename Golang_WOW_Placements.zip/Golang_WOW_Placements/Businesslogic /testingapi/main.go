package main

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

type User struct {
	ID    int    `json:"id"`
	Name  string `json:"name"`
	Email string `json:"email"`
}

var users []User
var nextID = 1

/*

1️⃣ Test GET endpoint

http://localhost:8080/ping

2️⃣ Create User (POST)

curl -X POST http://localhost:8080/users \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Venkatesh",
    "email": "venky@example.com",
    "active": true
  }'

3️⃣ Get all users
  http://localhost:8080/users

*/

func main() {

	r := gin.Default()

	// 1️⃣ Test GET endpoint
	r.GET("/ping", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{
			"message": "pong",
		})
	})

	// 2️⃣ Create User (POST)
	r.POST("/users", func(c *gin.Context) {
		var u User
		if err := c.BindJSON(&u); err != nil {
			c.JSON(400, gin.H{"error": err.Error()})
			return
		}

		u.ID = nextID
		nextID++
		users = append(users, u)

		c.JSON(200, u)
	})

	// 3️⃣ Get all users
	r.GET("/users", func(c *gin.Context) {
		c.JSON(200, users)
	})

	// Start server
	r.Run(":8080")
}
