package main

import (
	"log"

	"github.com/nats-io/nats.go"
)

func main() {

	nc, err := nats.Connect(nats.DefaultURL)
	if err != nil {
		log.Fatal(err)
	}
	defer nc.Close()

	js, err := nc.JetStream()
	if err != nil {
		log.Fatal(err)
	}

	_, err = js.Subscribe(
		"like.*",
		func(m *nats.Msg) {
			log.Printf("📩 Received: %s", string(m.Data))
			m.Ack()
		},
		nats.Durable("LIKE_SERVICE"),
		nats.ManualAck(),
	)
	if err != nil {
		log.Fatal(err)
	}

	log.Println("🎧 Listening for JetStream messages...")
	select {}
}
