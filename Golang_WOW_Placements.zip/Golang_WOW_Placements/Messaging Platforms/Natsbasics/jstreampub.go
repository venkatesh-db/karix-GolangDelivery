package main

import (
	"log"

	"github.com/nats-io/nats.go"
)

/*

stop current nats


venkatesh@venkateshs-MacBook-Pro ~ % docker run -d \
  --name nats-js \
  -p 4222:4222 \
  -p 8222:8222 \
  nats:2.12 \
  -js

Unable to find image 'nats:2.12' locally
2.12: Pulling from library/nats
Digest: sha256:e9e68e69c92f47ddf72e97d395e2cb214dd2722dddfa72c72bff1ea78ab3844f
Status: Downloaded newer image for nats:2.12
48d9a95022cdf52cec608eb78fde9f6f113f040ba077292fe1f1a254b3d4bff6

*/

func main() {

	nc, err := nats.Connect(nats.DefaultURL)
	if err != nil {
		log.Fatal(err)
	}
	defer nc.Close()

	js, err := nc.JetStream()
	if err != nil {
		log.Fatal(err)
	}

	// Create stream ONLY if it doesn't exist
	_, err = js.AddStream(&nats.StreamConfig{
		Name:     "INSTAGRAM",
		Subjects: []string{"like.*"},
		Storage:  nats.FileStorage,
	})
	if err != nil && err != nats.ErrStreamNameAlreadyInUse {
		log.Fatal(err)
	}

	_, err = js.Publish("like.post", []byte("InstagramID=u look like james bond"))
	if err != nil {
		log.Fatal(err)
	}

	log.Println("✅ Published message to JetStream")
}
