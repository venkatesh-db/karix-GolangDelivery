package main

import (
	"encoding/json"
	"fmt"
	"log"
	"math/rand"
	"sync"
	"time"

	"github.com/nats-io/nats.go"
)

type PaymentEvent struct {
	EventID   string  `json:"event_id"`
	UserID    string  `json:"user_id"`
	Amount    float64 `json:"amount"`
	Currency  string  `json:"currency"`
	Timestamp string  `json:"timestamp"`
}

func main() {
	// Connect to NATS JetStream
	nc, err := nats.Connect(nats.DefaultURL)
	if err != nil {
		log.Fatalf("Error connecting to NATS: %v", err)
	}
	defer nc.Close()

	js, err := nc.JetStream()
	if err != nil {
		log.Fatalf("Error connecting to JetStream: %v", err)
	}

	// Create a stream
	streamName := "PAYMENT_EVENTS"
	subject := "payments"
	_, err = js.AddStream(&nats.StreamConfig{
		Name:     streamName,
		Subjects: []string{subject},
	})
	if err != nil {
		log.Printf("Stream might already exist: %v", err)
	}

	// Publish 50 lakh payment events concurrently
	numEvents := 5000000
	log.Printf("Publishing %d payment events...", numEvents)

	wg := sync.WaitGroup{}
	workerCount := 10
	eventsPerWorker := numEvents / workerCount

	for w := 0; w < workerCount; w++ {
		wg.Add(1)
		go func(workerID int) {
			defer wg.Done()
			for i := 0; i < eventsPerWorker; i++ {
				event := PaymentEvent{
					EventID:   generateID(),
					UserID:    generateID(),
					Amount:    rand.Float64() * 10000,
					Currency:  "INR",
					Timestamp: time.Now().Format(time.RFC3339),
				}
				publishEvent(js, subject, event)
			}
			log.Printf("Worker %d finished publishing.", workerID)
		}(w)
	}

	wg.Wait()
	log.Println("Finished publishing all events.")
}

func publishEvent(js nats.JetStreamContext, subject string, event PaymentEvent) {
	data, err := json.Marshal(event)
	if err != nil {
		log.Printf("Error marshalling event: %v", err)
		return
	}

	_, err = js.Publish(subject, data)
	if err != nil {
		log.Printf("Error publishing event: %v", err)
	}
}

func generateID() string {
	return fmt.Sprintf("%d", rand.Int63())
}
