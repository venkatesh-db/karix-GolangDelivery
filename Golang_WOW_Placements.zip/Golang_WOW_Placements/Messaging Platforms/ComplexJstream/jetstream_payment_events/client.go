package main

import (
	"encoding/json"
	"fmt"
	"log"
	"math/rand"
	"sync"
	"time"

	"github.com/nats-io/nats.go"
)

type PaymentEvent struct {
	EventID   string  `json:"event_id"`
	UserID    string  `json:"user_id"`
	Amount    float64 `json:"amount"`
	Currency  string  `json:"currency"`
	Timestamp string  `json:"timestamp"`
}

func main() {
	// Connect to NATS JetStream
	nc, err := nats.Connect(nats.DefaultURL)
	if err != nil {
		log.Fatalf("Error connecting to NATS: %v", err)
	}
	defer nc.Close()

	js, err := nc.JetStream()
	if err != nil {
		log.Fatalf("Error connecting to JetStream: %v", err)
	}

	subject := "payments"
	numEvents := 5000000
	workerCount := 10
	eventsPerWorker := numEvents / workerCount

	log.Printf("Starting to publish %d events using %d workers...", numEvents, workerCount)

	wg := sync.WaitGroup{}

	for w := 0; w < workerCount; w++ {
		wg.Add(1)
		go func(workerID int) {
			defer wg.Done()
			log.Printf("Worker %d started publishing %d events.", workerID, eventsPerWorker)
			for i := 0; i < eventsPerWorker; i++ {
				event := PaymentEvent{
					EventID:   generateID(),
					UserID:    generateID(),
					Amount:    rand.Float64() * 10000,
					Currency:  "INR",
					Timestamp: time.Now().Format(time.RFC3339),
				}
				publishEvent(js, subject, event, workerID, i)
			}
			log.Printf("Worker %d finished publishing.", workerID)
		}(w)
	}

	wg.Wait()
	log.Println("Finished publishing all events.")
}

func publishEvent(js nats.JetStreamContext, subject string, event PaymentEvent, workerID, eventIndex int) {
	data, err := json.Marshal(event)
	if err != nil {
		log.Printf("Worker %d: Error marshalling event %d: %v", workerID, eventIndex, err)
		return
	}

	_, err = js.Publish(subject, data)
	if err != nil {
		log.Printf("Worker %d: Error publishing event %d: %v", workerID, eventIndex, err)
	} else {
		log.Printf("Worker %d: Successfully published event %d", workerID, eventIndex)
	}
}

func generateID() string {
	return fmt.Sprintf("%d", rand.Int63())
}
